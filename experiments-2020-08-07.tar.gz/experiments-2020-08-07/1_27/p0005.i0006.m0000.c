#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 105], float B[restrict 97], float C[restrict 205], float D[restrict 205], float E[restrict 227]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 31; i1 <= 54; i1+=1) {
    for (int i2 = 51; i2 <= 82; i2+=1) {
      for (int i3 = 22; i3 <= 29; i3+=1) {
          A[2 * i3 - 12] = ((112 * B[1 * i3 + 8]) * (106 + A[1 * i2 + 14]) + (C[1 * i1 - 14] - 5 * D[1 * i1 + 14])) - (((((((C[1 * i3 - 14] + E[1 * i3 + 14]) + D[1 * i2 + 8]) - A[2 * i3 - 14] * 106) - (112 + E[2 * i1 + 12])) - (106 + 106)) - (5 - D[1 * i2 - 12] * 5) * ((5 - C[1 * i3 + 14]) * (106 * C[2 * i1 - 8]))) - ((D[1 * i3 - 12] + (B[1 * i3 - 12] - 112)) - (112 + A[1 * i3 - 12])));
      }
    }
  }
  for (int i4 = 16; i4 <= 27; i4+=1) {
    for (int i2 = 51; i2 <= 82; i2+=1) {
      for (int i3 = 22; i3 <= 29; i3+=1) {
          C[1 * i3 + 14] = (((C[2 * i4 - 8] * C[1 * i2 - 8] - A[1 * i2 - 8] * 5) - ((112 * D[1 * i4 - 8]) * A[1 * i4 - 12] - A[1 * i4 + 8])) + (106 + (5 + (C[1 * i3 + 14] * B[1 * i2 + 12] + ((E[2 * i4 - 12] - 112 * 5) + (A[1 * i4 + 14] + 106 * 112)))))) * (((E[1 * i4 - 8] - B[1 * i3 + 8]) * A[1 * i2 + 8]) * (((112 - 106) - (E[1 * i3 - 14] * E[2 * i2 - 12] - (A[1 * i4 - 8] - B[1 * i2 - 14]))) * E[1 * i3 - 12]));
      }
    }
  }
  for (int i1 = 31; i1 <= 54; i1+=1) {
    for (int i5 = 86; i5 <= 106; i5+=1) {
      for (int i4 = 16; i4 <= 27; i4+=1) {
          D[1 * i4 - 12] = (112 - ((E[1 * i1 - 14] - ((A[1 * i4 - 8] + B[2 * i1 - 12]) - 5)) - (A[1 * i4 + 8] - D[2 * i5 - 8]))) + ((106 * 5 - D[1 * i5 - 8]) - (E[1 * i5 - 14] * E[2 * i5 + 14] + (5 - (E[1 * i1 - 12] + A[1 * i4 - 14])))) * (((D[1 * i1 - 12] + 5) - (B[1 * i1 - 12] - E[1 * i5 + 14])) * D[1 * i5 + 12] + ((D[1 * i4 - 8] - (D[2 * i4 - 8] + ((112 + 5) - (5 + B[1 * i4 + 12])))) + C[2 * i4 - 8] * 106));
      }
    }
  }
  for (int i6 = 60; i6 <= 96; i6+=1) {
    for (int i3 = 22; i3 <= 29; i3+=1) {
      for (int i4 = 16; i4 <= 27; i4+=1) {
          D[2 * i6 - 12] = (5 * ((106 * (112 - D[1 * i3 - 8])) * (((106 - 112) + (D[1 * i3 + 8] - D[2 * i6 - 14])) - (C[1 * i6 + 8] + ((C[1 * i6 + 8] + B[1 * i3 - 8]) - 106)) * (B[1 * i3 - 8] * B[2 * i3 + 8])))) * ((D[2 * i3 + 12] * ((A[1 * i6 + 8] - A[2 * i3 - 14]) * E[2 * i3 + 12])) * 106) + (((B[1 * i4 - 12] * C[2 * i6 + 12] + (C[2 * i3 - 8] - C[1 * i6 - 12])) + (C[2 * i3 - 12] - (E[1 * i6 - 12] + B[1 * i3 + 12]))) - (5 + C[1 * i3 + 8]));
      }
    }
  }
  for (int i3 = 22; i3 <= 29; i3+=1) {
    for (int i1 = 31; i1 <= 54; i1+=1) {
      for (int i4 = 16; i4 <= 27; i4+=1) {
          C[1 * i4 + 12] = (106 * E[1 * i3 - 14] + (C[2 * i3 - 14] - (((C[2 * i3 - 12] - 106) - (B[1 * i4 + 12] - 112) * (C[1 * i4 + 14] * B[1 * i3 - 12])) - (B[1 * i1 + 14] - D[2 * i1 + 8]) * (112 + 112)))) * ((106 - D[1 * i4 + 8]) * (((E[1 * i3 - 14] + E[1 * i4 + 12]) + (((E[1 * i1 + 14] + D[1 * i1 + 14] * D[1 * i3 + 12]) - (106 + D[1 * i1 + 8] * C[2 * i4 - 14])) - D[1 * i1 + 8] * E[1 * i4 - 12])) * (A[1 * i4 + 14] - (D[1 * i1 + 8] - C[1 * i3 + 8]))));
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

