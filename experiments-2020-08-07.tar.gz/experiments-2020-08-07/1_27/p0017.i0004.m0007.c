#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 160], float B[restrict 128], float C[restrict 204], float D[restrict 190], float E[restrict 174]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i2 = 60; i2 <= 60; i2+=1) {
    for (int i1 = 77; i1 <= 82; i1+=1) {
      for (int i3 = 37; i3 <= 75; i3+=1) {
          A[2 * i2 + 5] = ((((B[1 * i2 + 5] + C[2 * i3 - 5]) - C[2 * i2 - 7]) + C[2 * i2 + 9]) - B[2 * i2 - 7] * A[2 * i3 + 9]) * (((C[2 * i1 - 5] + 111) - (D[2 * i1 + 5] * E[2 * i3 - 5] + 56)) + (((A[1 * i2 - 7] + E[2 * i3 - 5]) + C[2 * i3 - 9]) * (A[1 * i2 - 9] * (A[2 * i1 - 5] * 56)) - (((E[1 * i1 - 7] + E[2 * i1 - 9]) * C[2 * i2 - 7] - ((E[1 * i1 - 9] - A[2 * i2 - 9]) + (B[2 * i2 + 7] - C[2 * i3 + 7]) * ((D[2 * i1 - 9] + C[1 * i1 + 5]) - C[2 * i1 - 9]))) + C[2 * i1 - 7])));
      }
    }
  }
  for (int i4 = 19; i4 <= 40; i4+=1) {
    for (int i5 = 13; i5 <= 32; i5+=1) {
      for (int i2 = 60; i2 <= 60; i2+=1) {
          D[2 * i4 + 9] = (C[2 * i5 - 7] + A[1 * i4 + 7]) + (((111 - (B[2 * i4 - 5] + E[2 * i4 + 9])) * ((C[2 * i4 + 7] - 19 * 19) * (111 + D[2 * i5 + 9])) - (19 * (E[2 * i5 + 7] - A[2 * i2 - 5])) * B[2 * i5 + 7]) - (((D[2 * i4 - 9] - 19 * A[1 * i5 - 7]) - (C[1 * i5 + 5] * E[2 * i2 + 5] + 56)) - B[2 * i4 + 7] * (56 * (111 * 56 - (A[2 * i5 + 9] + D[1 * i2 - 5])))) * (C[1 * i2 - 7] + 111));
      }
    }
  }
  for (int i4 = 19; i4 <= 40; i4+=1) {
    for (int i5 = 13; i5 <= 32; i5+=1) {
      for (int i2 = 60; i2 <= 60; i2+=1) {
          E[2 * i4 - 5] = ((((A[1 * i2 + 5] + (19 - E[2 * i4 - 5])) - C[2 * i5 + 9]) - 19 * 56) + ((D[1 * i4 - 5] - E[2 * i4 + 5]) * ((111 * C[2 * i5 - 9] + D[2 * i2 - 5]) + D[1 * i4 + 5] * ((B[2 * i4 + 5] - 56) + E[1 * i5 - 7])) + (C[2 * i2 - 9] - C[2 * i4 - 9]))) * ((C[2 * i5 - 9] - D[2 * i5 + 7]) + D[2 * i5 - 5]) - D[2 * i2 - 7] * (((E[1 * i4 - 5] + 19) + (D[2 * i4 + 7] - 19)) + C[1 * i2 + 5] * (19 + A[2 * i2 - 7]));
      }
    }
  }
  for (int i1 = 77; i1 <= 82; i1+=1) {
    for (int i4 = 19; i4 <= 40; i4+=1) {
      for (int i6 = 94; i6 <= 99; i6+=1) {
          E[2 * i1 + 9] = (E[2 * i1 + 7] + ((C[2 * i4 + 9] - (E[1 * i6 + 5] + 19 * E[1 * i1 - 7])) + ((E[2 * i1 - 9] + 56) + (C[2 * i4 + 9] + (C[2 * i1 - 7] - 111)) * (19 - E[2 * i4 - 7])))) * (((((D[2 * i1 - 9] + (56 - C[1 * i4 - 9])) + C[2 * i1 - 5]) - (19 + (D[1 * i1 + 7] - 111))) - C[2 * i1 + 7]) * ((E[2 * i1 + 9] * C[2 * i6 + 5] + ((19 + (B[2 * i4 - 5] + D[2 * i4 + 7])) + 111)) + 111 * D[2 * i6 - 9]));
      }
    }
  }
  for (int i5 = 13; i5 <= 32; i5+=1) {
    for (int i3 = 37; i3 <= 75; i3+=1) {
      for (int i2 = 60; i2 <= 60; i2+=1) {
          B[1 * i2 + 7] = (((((D[2 * i3 + 9] + D[2 * i5 + 9]) - 111) * A[2 * i5 + 9]) * ((E[2 * i5 + 9] - A[1 * i5 + 5]) + E[1 * i5 + 7] * D[2 * i3 + 7]) - C[2 * i2 - 5]) + (A[1 * i5 - 9] + ((((56 - B[2 * i2 + 7]) + 56 * 111) + (D[2 * i5 + 7] + (D[2 * i2 - 9] - B[1 * i5 + 5]))) + ((111 + C[2 * i2 - 7]) - 111)))) + (((E[1 * i3 - 7] * C[2 * i3 + 9]) * (E[1 * i3 + 7] + 111)) * (C[2 * i2 - 5] * B[1 * i5 + 9]) - (A[2 * i5 + 5] - 56));
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

