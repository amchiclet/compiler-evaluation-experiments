#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 238], float B[restrict 234], float C[restrict 230], float D[restrict 220], float E[restrict 238]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 20; i1 <= 113; i1+=1) {
    for (int i2 = 47; i2 <= 48; i2+=1) {
      for (int i3 = 90; i3 <= 111; i3+=1) {
          A[2 * i2 + 11] = 118 * ((118 - (B[2 * i2 + 11] + C[2 * i2 - 2])) * (((B[2 * i2 - 11] * 101) * (101 - (((101 * 101 - ((D[2 * i2 - 7] + B[2 * i2 - 11]) - A[2 * i3 - 2])) + E[2 * i2 - 11] * 118) - 118)) + 118) + ((118 + (E[2 * i3 + 2] + E[2 * i1 + 2])) - C[2 * i3 + 7]) * ((A[2 * i1 - 7] - 101 * A[2 * i2 + 11]) * (93 * D[2 * i2 + 7] + E[2 * i1 - 2]) - (B[2 * i3 + 2] - B[2 * i2 - 7]))));
      }
    }
  }
  for (int i1 = 20; i1 <= 113; i1+=1) {
    for (int i4 = 38; i4 <= 47; i4+=1) {
      for (int i2 = 47; i2 <= 48; i2+=1) {
          E[2 * i4 + 7] = ((101 - (A[2 * i2 - 11] + (101 + 101))) + ((A[2 * i4 + 11] - D[2 * i1 - 7]) * ((E[2 * i1 + 7] * (93 - 93)) * A[2 * i2 - 7] + ((118 + B[2 * i2 - 11]) - E[2 * i1 + 11])) - E[2 * i1 + 2])) * ((A[2 * i4 - 7] - A[2 * i4 + 2]) + (118 - A[2 * i1 + 11])) + (((A[2 * i2 - 2] + B[2 * i1 + 7]) - A[2 * i4 - 7]) * (93 * 101) - (B[2 * i4 - 7] - (D[2 * i4 + 11] + E[2 * i2 - 2] * B[2 * i4 - 2])) * D[2 * i2 - 11]);
      }
    }
  }
  for (int i5 = 18; i5 <= 60; i5+=1) {
    for (int i3 = 90; i3 <= 111; i3+=1) {
      for (int i6 = 13; i6 <= 95; i6+=1) {
          C[2 * i5 + 11] = ((((C[2 * i6 + 11] + 118) + D[2 * i5 + 11]) - ((101 - E[2 * i5 + 2]) - (101 - 118))) + (93 + B[2 * i3 + 2])) - ((B[2 * i5 - 11] * ((E[2 * i3 - 2] * D[2 * i6 + 2] - B[2 * i3 + 11]) - (93 * E[2 * i5 - 7] - A[2 * i3 - 11])) - ((B[2 * i6 - 11] * (A[2 * i5 + 7] + (93 - 118)) - 118 * A[2 * i6 - 11]) - (118 - (D[2 * i6 - 7] - 101)))) - (B[2 * i6 - 2] * A[2 * i6 + 11]) * 93);
      }
    }
  }
  for (int i6 = 13; i6 <= 95; i6+=1) {
    for (int i5 = 18; i5 <= 60; i5+=1) {
      for (int i2 = 47; i2 <= 48; i2+=1) {
          C[2 * i5 + 7] = (93 * (B[2 * i6 + 7] + E[2 * i5 + 7])) * (C[2 * i2 + 11] - (C[2 * i2 - 2] - B[2 * i2 - 11]) * C[2 * i5 + 11]) + (((A[2 * i6 + 11] * ((B[2 * i2 - 11] + B[2 * i5 + 11]) - (C[2 * i2 + 2] - D[2 * i2 + 11]))) * 118 + (A[2 * i2 - 11] * (101 * E[2 * i2 + 7]) + ((C[2 * i2 - 2] - E[2 * i6 + 2]) + D[2 * i5 - 2]) * 101)) + (101 + ((E[2 * i5 + 2] + ((118 + A[2 * i6 + 11]) + (A[2 * i2 - 7] + 118))) * E[2 * i2 + 11]) * A[2 * i5 - 7]));
      }
    }
  }
  for (int i5 = 18; i5 <= 60; i5+=1) {
    for (int i6 = 13; i6 <= 95; i6+=1) {
      for (int i2 = 47; i2 <= 48; i2+=1) {
          D[2 * i5 - 2] = (118 * 93 - (101 - 101)) * D[2 * i6 - 11] - ((B[2 * i2 - 2] - ((D[2 * i5 + 7] + 93) + (B[2 * i6 + 7] + 118))) - (D[2 * i2 + 11] * (C[2 * i6 - 2] + C[2 * i5 + 2]) - ((101 * D[2 * i2 - 11] + ((A[2 * i2 - 2] + 118) - 118) * ((D[2 * i6 - 11] + 101) * ((118 + B[2 * i2 - 11]) * 101))) - E[2 * i2 + 7] * 93) * (B[2 * i2 - 2] * 118))) * D[2 * i2 - 2];
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

