#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 220], float B[restrict 218], float C[restrict 197], float D[restrict 228], float E[restrict 208]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 59; i1 <= 62; i1+=1) {
    for (int i2 = 75; i2 <= 104; i2+=1) {
      for (int i3 = 86; i3 <= 97; i3+=1) {
          A[1 * i3 - 9] = ((70 * B[2 * i3 + 0]) * (45 + A[2 * i2 + 11]) + (C[1 * i1 - 11] - 29 * D[1 * i1 + 11])) - (((((((C[2 * i3 - 11] + E[2 * i3 + 11]) + D[1 * i2 + 0]) - A[1 * i3 - 11] * 45) - (70 + E[1 * i1 + 9])) - (45 + 45)) - (29 - D[1 * i2 - 9] * 29) * ((29 - C[1 * i3 + 11]) * (45 * C[1 * i1 - 0]))) - ((D[1 * i3 - 9] + (B[1 * i3 - 9] - 70)) - (70 + A[1 * i3 - 9])));
      }
    }
  }
  for (int i4 = 17; i4 <= 19; i4+=1) {
    for (int i2 = 75; i2 <= 104; i2+=1) {
      for (int i3 = 86; i3 <= 97; i3+=1) {
          C[1 * i3 + 11] = (((C[1 * i4 - 0] * C[1 * i2 - 0] - A[1 * i2 - 0] * 29) - ((70 * D[1 * i4 - 0]) * A[1 * i4 - 9] - A[2 * i4 + 0])) + (45 + (29 + (C[1 * i3 + 11] * B[2 * i2 + 9] + ((E[1 * i4 - 9] - 70 * 29) + (A[2 * i4 + 11] + 45 * 70)))))) * (((E[1 * i4 - 0] - B[1 * i3 + 0]) * A[2 * i2 + 0]) * (((70 - 45) - (E[2 * i3 - 11] * E[1 * i2 - 9] - (A[2 * i4 - 0] - B[1 * i2 - 11]))) * E[1 * i3 - 9]));
      }
    }
  }
  for (int i1 = 59; i1 <= 62; i1+=1) {
    for (int i4 = 17; i4 <= 19; i4+=1) {
      for (int i5 = 94; i5 <= 109; i5+=1) {
          D[1 * i4 - 9] = (70 - ((E[2 * i1 - 11] - ((A[1 * i4 - 0] + B[1 * i1 - 9]) - 29)) - (A[2 * i4 + 0] - D[1 * i5 - 0]))) + ((45 * 29 - D[2 * i5 - 0]) - (E[2 * i5 - 11] * E[1 * i5 + 11] + (29 - (E[2 * i1 - 9] + A[2 * i4 - 11])))) * (((D[1 * i1 - 9] + 29) - (B[1 * i1 - 9] - E[1 * i5 + 11])) * D[2 * i5 + 9] + ((D[2 * i4 - 0] - (D[1 * i4 - 0] + ((70 + 29) - (29 + B[1 * i4 + 9])))) + C[1 * i4 - 0] * 45));
      }
    }
  }
  for (int i6 = 57; i6 <= 98; i6+=1) {
    for (int i3 = 86; i3 <= 97; i3+=1) {
      for (int i4 = 17; i4 <= 19; i4+=1) {
          D[1 * i6 - 9] = (29 * ((45 * (70 - D[2 * i3 - 0])) * (((45 - 70) + (D[2 * i3 + 0] - D[1 * i6 - 11])) - (C[2 * i6 + 0] + ((C[1 * i6 + 0] + B[1 * i3 - 0]) - 45)) * (B[2 * i3 - 0] * B[1 * i3 + 0])))) * ((D[1 * i3 + 9] * ((A[1 * i6 + 0] - A[1 * i3 - 11]) * E[1 * i3 + 9])) * 45) + (((B[2 * i4 - 9] * C[1 * i6 + 9] + (C[1 * i3 - 0] - C[2 * i6 - 9])) + (C[1 * i3 - 9] - (E[1 * i6 - 9] + B[1 * i3 + 9]))) - (29 + C[1 * i3 + 0]));
      }
    }
  }
  for (int i3 = 86; i3 <= 97; i3+=1) {
    for (int i1 = 59; i1 <= 62; i1+=1) {
      for (int i4 = 17; i4 <= 19; i4+=1) {
          C[2 * i4 + 9] = (45 * E[2 * i3 - 11] + (C[1 * i3 - 11] - (((C[1 * i3 - 9] - 45) - (B[1 * i4 + 9] - 70) * (C[1 * i4 + 11] * B[1 * i3 - 9])) - (B[1 * i1 + 11] - D[1 * i1 + 0]) * (70 + 70)))) * ((45 - D[1 * i4 + 0]) * (((E[2 * i3 - 11] + E[1 * i4 + 9]) + (((E[2 * i1 + 11] + D[2 * i1 + 11] * D[2 * i3 + 9]) - (45 + D[1 * i1 + 0] * C[1 * i4 - 11])) - D[2 * i1 + 0] * E[1 * i4 - 9])) * (A[2 * i4 + 11] - (D[2 * i1 + 0] - C[2 * i3 + 0]))));
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

