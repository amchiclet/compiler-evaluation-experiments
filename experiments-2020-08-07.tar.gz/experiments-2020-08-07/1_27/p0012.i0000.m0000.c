#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 220], float B[restrict 222], float C[restrict 252], float D[restrict 252], float E[restrict 232]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 26; i1 <= 90; i1+=1) {
    for (int i2 = 27; i2 <= 100; i2+=1) {
      for (int i3 = 13; i3 <= 92; i3+=1) {
          A[1 * i2 + 15] = 111 * ((111 - (B[1 * i2 + 15] + C[1 * i2 - 12])) * (((B[2 * i2 - 15] * 57) * (57 - (((57 * 57 - ((D[2 * i2 - 5] + B[1 * i2 - 15]) - A[2 * i3 - 12])) + E[1 * i2 - 15] * 111) - 111)) + 111) + ((111 + (E[2 * i3 + 12] + E[1 * i1 + 12])) - C[1 * i3 + 5]) * ((A[1 * i1 - 5] - 57 * A[1 * i2 + 15]) * (71 * D[1 * i2 + 5] + E[1 * i1 - 12]) - (B[1 * i3 + 12] - B[1 * i2 - 5]))));
      }
    }
  }
  for (int i1 = 26; i1 <= 90; i1+=1) {
    for (int i4 = 53; i4 <= 88; i4+=1) {
      for (int i2 = 27; i2 <= 100; i2+=1) {
          E[1 * i4 + 5] = ((57 - (A[1 * i2 - 15] + (57 + 57))) + ((A[1 * i4 + 15] - D[1 * i1 - 5]) * ((E[1 * i1 + 5] * (71 - 71)) * A[1 * i2 - 5] + ((111 + B[2 * i2 - 15]) - E[1 * i1 + 15])) - E[1 * i1 + 12])) * ((A[1 * i4 - 5] - A[1 * i4 + 12]) + (111 - A[2 * i1 + 15])) + (((A[2 * i2 - 12] + B[1 * i1 + 5]) - A[2 * i4 - 5]) * (71 * 57) - (B[2 * i4 - 5] - (D[2 * i4 + 15] + E[2 * i2 - 12] * B[2 * i4 - 12])) * D[1 * i2 - 15]);
      }
    }
  }
  for (int i5 = 16; i5 <= 118; i5+=1) {
    for (int i3 = 13; i3 <= 92; i3+=1) {
      for (int i6 = 91; i6 <= 102; i6+=1) {
          C[1 * i5 + 15] = ((((C[1 * i6 + 15] + 111) + D[2 * i5 + 15]) - ((57 - E[1 * i5 + 12]) - (57 - 111))) + (71 + B[1 * i3 + 12])) - ((B[2 * i5 - 15] * ((E[1 * i3 - 12] * D[1 * i6 + 12] - B[2 * i3 + 15]) - (71 * E[2 * i5 - 5] - A[2 * i3 - 15])) - ((B[1 * i6 - 15] * (A[1 * i5 + 5] + (71 - 111)) - 111 * A[2 * i6 - 15]) - (111 - (D[1 * i6 - 5] - 57)))) - (B[1 * i6 - 12] * A[1 * i6 + 15]) * 71);
      }
    }
  }
  for (int i6 = 91; i6 <= 102; i6+=1) {
    for (int i5 = 16; i5 <= 118; i5+=1) {
      for (int i2 = 27; i2 <= 100; i2+=1) {
          C[1 * i5 + 5] = (71 * (B[2 * i6 + 5] + E[1 * i5 + 5])) * (C[1 * i2 + 15] - (C[1 * i2 - 12] - B[1 * i2 - 15]) * C[2 * i5 + 15]) + (((A[2 * i6 + 15] * ((B[1 * i2 - 15] + B[1 * i5 + 15]) - (C[2 * i2 + 12] - D[1 * i2 + 15]))) * 111 + (A[1 * i2 - 15] * (57 * E[1 * i2 + 5]) + ((C[2 * i2 - 12] - E[1 * i6 + 12]) + D[1 * i5 - 12]) * 57)) + (57 + ((E[1 * i5 + 12] + ((111 + A[1 * i6 + 15]) + (A[1 * i2 - 5] + 111))) * E[1 * i2 + 15]) * A[1 * i5 - 5]));
      }
    }
  }
  for (int i5 = 16; i5 <= 118; i5+=1) {
    for (int i6 = 91; i6 <= 102; i6+=1) {
      for (int i2 = 27; i2 <= 100; i2+=1) {
          D[1 * i5 - 12] = (111 * 71 - (57 - 57)) * D[2 * i6 - 15] - ((B[1 * i2 - 12] - ((D[2 * i5 + 5] + 71) + (B[1 * i6 + 5] + 111))) - (D[1 * i2 + 15] * (C[2 * i6 - 12] + C[1 * i5 + 12]) - ((57 * D[2 * i2 - 15] + ((A[1 * i2 - 12] + 111) - 111) * ((D[2 * i6 - 15] + 57) * ((111 + B[1 * i2 - 15]) * 57))) - E[2 * i2 + 5] * 71) * (B[1 * i2 - 12] * 111))) * D[2 * i2 - 12];
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

