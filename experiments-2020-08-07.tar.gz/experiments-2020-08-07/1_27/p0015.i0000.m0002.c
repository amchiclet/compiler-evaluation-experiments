#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 249], float B[restrict 237], float C[restrict 240], float D[restrict 249], float E[restrict 240]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 10; i1 <= 119; i1+=1) {
    for (int i2 = 113; i2 <= 213; i2+=1) {
      for (int i3 = 31; i3 <= 44; i3+=1) {
          A[1 * i2 + 4] = (((B[1 * i2 + 10] - 84) * (25 + (C[2 * i1 + 1] - 25)) + A[1 * i2 - 1]) - (((25 - D[2 * i1 - 1]) - B[1 * i1 - 1]) + (25 + D[1 * i2 + 4]))) - (((99 * 84 - (D[1 * i3 - 10] + A[2 * i1 - 4])) + ((25 * A[1 * i3 + 1] - A[2 * i1 + 10]) + D[1 * i3 - 1] * 84) * C[1 * i3 - 10]) - ((B[2 * i3 - 1] * D[1 * i1 - 10] + 84 * 25) - (84 + D[1 * i3 - 4] * B[1 * i1 + 10])));
      }
    }
  }
  for (int i3 = 31; i3 <= 44; i3+=1) {
    for (int i2 = 113; i2 <= 213; i2+=1) {
      for (int i4 = 14; i4 <= 53; i4+=1) {
          B[1 * i2 + 10] = ((((((D[1 * i4 - 1] + 84) + C[1 * i4 + 4]) - A[1 * i3 - 4]) - D[1 * i4 - 4]) + 25) - 84) * (((25 + (25 + (25 + C[1 * i4 + 4]))) + 84) + (((A[1 * i4 - 1] - 99) * ((D[1 * i4 - 10] * A[1 * i3 - 1]) * 25) - E[1 * i3 + 10]) + (D[1 * i3 - 10] + (25 - ((D[1 * i3 + 10] - 84) + A[1 * i3 - 1] * 25)) * (A[2 * i4 + 1] + 25)))) + (84 + E[1 * i2 + 10]);
      }
    }
  }
  for (int i4 = 14; i4 <= 53; i4+=1) {
    for (int i1 = 10; i1 <= 119; i1+=1) {
      for (int i5 = 14; i5 <= 84; i5+=1) {
          D[2 * i4 - 1] = (((B[1 * i5 - 4] - 99) * (C[1 * i5 - 4] - ((25 + A[1 * i5 - 10]) - C[2 * i4 - 4])) + (((D[1 * i5 - 10] - 25) - 99) - A[2 * i5 - 1])) - (D[1 * i1 - 4] - C[2 * i4 - 10])) + ((C[1 * i4 + 4] - ((99 + D[1 * i4 + 4]) + 84 * (E[2 * i4 + 1] + D[2 * i1 + 10] * 99))) - ((A[2 * i5 + 1] * D[1 * i5 - 1] - B[1 * i1 + 10]) - 99)) * ((D[1 * i5 - 10] + (C[2 * i1 - 1] - B[1 * i5 - 1])) - (C[2 * i4 - 1] - 84));
      }
    }
  }
  for (int i4 = 14; i4 <= 53; i4+=1) {
    for (int i1 = 10; i1 <= 119; i1+=1) {
      for (int i3 = 31; i3 <= 44; i3+=1) {
          E[2 * i3 + 10] = ((A[1 * i3 - 1] * (B[1 * i4 - 1] - 99)) * (((D[1 * i1 + 10] + (E[2 * i3 - 4] + 99)) + (25 * 99 + C[1 * i1 + 10])) + (25 * ((B[1 * i3 + 10] + E[1 * i3 - 10]) + E[2 * i1 + 1])) * ((84 + (99 - (D[1 * i4 + 10] * E[1 * i4 + 4] + 25))) - (((B[1 * i3 - 4] + D[1 * i4 - 10]) + 99) + 84)))) * ((E[1 * i3 + 10] - B[2 * i3 - 4]) + ((25 - E[2 * i1 + 1]) + 84 * E[2 * i3 - 4]));
      }
    }
  }
  for (int i5 = 14; i5 <= 84; i5+=1) {
    for (int i3 = 31; i3 <= 44; i3+=1) {
      for (int i6 = 111; i6 <= 113; i6+=1) {
          C[1 * i6 - 10] = ((C[2 * i6 + 1] * C[2 * i5 + 1] + ((B[1 * i5 + 10] * ((A[1 * i5 + 4] + B[1 * i3 + 1]) * D[1 * i6 - 10]) + D[1 * i5 - 4] * (84 + D[1 * i5 + 1])) + A[1 * i3 + 1])) - (B[1 * i3 + 10] * B[1 * i6 + 10] + 25)) + ((E[1 * i5 + 4] + B[1 * i6 - 10]) * ((E[2 * i3 - 4] - 84) * B[2 * i6 + 10] - (C[2 * i3 - 4] - 99))) * (25 * C[2 * i6 + 1] + ((B[1 * i5 + 10] - (D[1 * i3 - 4] + 25)) - (B[2 * i3 + 1] + (C[1 * i6 - 1] + B[1 * i3 + 10]))));
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

