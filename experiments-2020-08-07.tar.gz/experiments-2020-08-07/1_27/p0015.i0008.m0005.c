#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 231], float B[restrict 231], float C[restrict 234], float D[restrict 231], float E[restrict 234]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 19; i1 <= 112; i1+=1) {
    for (int i2 = 47; i2 <= 101; i2+=1) {
      for (int i3 = 16; i3 <= 58; i3+=1) {
          A[2 * i2 + 3] = (((B[1 * i2 + 6] - 45) * (82 + (C[2 * i1 + 9] - 82)) + A[1 * i2 - 9]) - (((82 - D[2 * i1 - 9]) - B[1 * i1 - 9]) + (82 + D[1 * i2 + 3]))) - (((0 * 45 - (D[1 * i3 - 6] + A[2 * i1 - 3])) + ((82 * A[2 * i3 + 9] - A[2 * i1 + 6]) + D[2 * i3 - 9] * 45) * C[1 * i3 - 6]) - ((B[2 * i3 - 9] * D[1 * i1 - 6] + 45 * 82) - (45 + D[1 * i3 - 3] * B[1 * i1 + 6])));
      }
    }
  }
  for (int i3 = 16; i3 <= 58; i3+=1) {
    for (int i2 = 47; i2 <= 101; i2+=1) {
      for (int i4 = 75; i4 <= 84; i4+=1) {
          B[2 * i2 + 6] = ((((((D[2 * i4 - 9] + 45) + C[1 * i4 + 3]) - A[2 * i3 - 3]) - D[2 * i4 - 3]) + 82) - 45) * (((82 + (82 + (82 + C[2 * i4 + 3]))) + 45) + (((A[1 * i4 - 9] - 0) * ((D[2 * i4 - 6] * A[1 * i3 - 9]) * 82) - E[1 * i3 + 6]) + (D[1 * i3 - 6] + (82 - ((D[2 * i3 + 6] - 45) + A[1 * i3 - 9] * 82)) * (A[2 * i4 + 9] + 82)))) + (45 + E[2 * i2 + 6]);
      }
    }
  }
  for (int i4 = 75; i4 <= 84; i4+=1) {
    for (int i1 = 19; i1 <= 112; i1+=1) {
      for (int i5 = 52; i5 <= 72; i5+=1) {
          D[2 * i4 - 9] = (((B[2 * i5 - 3] - 0) * (C[1 * i5 - 3] - ((82 + A[1 * i5 - 6]) - C[2 * i4 - 3])) + (((D[1 * i5 - 6] - 82) - 0) - A[2 * i5 - 9])) - (D[2 * i1 - 3] - C[2 * i4 - 6])) + ((C[2 * i4 + 3] - ((0 + D[1 * i4 + 3]) + 45 * (E[2 * i4 + 9] + D[2 * i1 + 6] * 0))) - ((A[2 * i5 + 9] * D[1 * i5 - 9] - B[2 * i1 + 6]) - 0)) * ((D[1 * i5 - 6] + (C[2 * i1 - 9] - B[2 * i5 - 9])) - (C[2 * i4 - 9] - 45));
      }
    }
  }
  for (int i4 = 75; i4 <= 84; i4+=1) {
    for (int i1 = 19; i1 <= 112; i1+=1) {
      for (int i3 = 16; i3 <= 58; i3+=1) {
          E[2 * i3 + 6] = ((A[1 * i3 - 9] * (B[2 * i4 - 9] - 0)) * (((D[1 * i1 + 6] + (E[2 * i3 - 3] + 0)) + (82 * 0 + C[2 * i1 + 6])) + (82 * ((B[1 * i3 + 6] + E[2 * i3 - 6]) + E[2 * i1 + 9])) * ((45 + (0 - (D[1 * i4 + 6] * E[2 * i4 + 3] + 82))) - (((B[2 * i3 - 3] + D[2 * i4 - 6]) + 0) + 45)))) * ((E[2 * i3 + 6] - B[2 * i3 - 3]) + ((82 - E[2 * i1 + 9]) + 45 * E[2 * i3 - 3]));
      }
    }
  }
  for (int i5 = 52; i5 <= 72; i5+=1) {
    for (int i6 = 88; i6 <= 107; i6+=1) {
      for (int i3 = 16; i3 <= 58; i3+=1) {
          C[2 * i6 - 6] = ((C[2 * i6 + 9] * C[2 * i5 + 9] + ((B[2 * i5 + 6] * ((A[2 * i5 + 3] + B[2 * i3 + 9]) * D[1 * i6 - 6]) + D[2 * i5 - 3] * (45 + D[2 * i5 + 9])) + A[2 * i3 + 9])) - (B[2 * i3 + 6] * B[1 * i6 + 6] + 82)) + ((E[1 * i5 + 3] + B[2 * i6 - 6]) * ((E[2 * i3 - 3] - 45) * B[2 * i6 + 6] - (C[2 * i3 - 3] - 0))) * (82 * C[2 * i6 + 9] + ((B[2 * i5 + 6] - (D[1 * i3 - 3] + 82)) - (B[2 * i3 + 9] + (C[2 * i6 - 9] + B[1 * i3 + 6]))));
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

