#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 216], float B[restrict 245], float C[restrict 179], float D[restrict 200], float E[restrict 245]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 33; i1 <= 98; i1+=1) {
    for (int i2 = 67; i2 <= 69; i2+=1) {
      for (int i3 = 58; i3 <= 114; i3+=1) {
          A[2 * i2 + 13] = 124 * ((124 - (B[2 * i2 + 13] + C[1 * i2 - 16])) * (((B[2 * i2 - 13] * 102) * (102 - (((102 * 102 - ((D[2 * i2 - 9] + B[2 * i2 - 13]) - A[2 * i3 - 16])) + E[2 * i2 - 13] * 124) - 124)) + 124) + ((124 + (E[2 * i3 + 16] + E[2 * i1 + 16])) - C[1 * i3 + 9]) * ((A[2 * i1 - 9] - 102 * A[2 * i2 + 13]) * (98 * D[2 * i2 + 9] + E[1 * i1 - 16]) - (B[2 * i3 + 16] - B[2 * i2 - 9]))));
      }
    }
  }
  for (int i4 = 62; i4 <= 93; i4+=1) {
    for (int i1 = 33; i1 <= 98; i1+=1) {
      for (int i2 = 67; i2 <= 69; i2+=1) {
          E[2 * i4 + 9] = ((102 - (A[1 * i2 - 13] + (102 + 102))) + ((A[2 * i4 + 13] - D[2 * i1 - 9]) * ((E[1 * i1 + 9] * (98 - 98)) * A[2 * i2 - 9] + ((124 + B[2 * i2 - 13]) - E[1 * i1 + 13])) - E[1 * i1 + 16])) * ((A[1 * i4 - 9] - A[2 * i4 + 16]) + (124 - A[2 * i1 + 13])) + (((A[2 * i2 - 16] + B[2 * i1 + 9]) - A[2 * i4 - 9]) * (98 * 102) - (B[2 * i4 - 9] - (D[2 * i4 + 13] + E[2 * i2 - 16] * B[2 * i4 - 16])) * D[1 * i2 - 13]);
      }
    }
  }
  for (int i5 = 38; i5 <= 67; i5+=1) {
    for (int i3 = 58; i3 <= 114; i3+=1) {
      for (int i6 = 79; i6 <= 97; i6+=1) {
          C[2 * i5 + 13] = ((((C[1 * i6 + 13] + 124) + D[2 * i5 + 13]) - ((102 - E[1 * i5 + 16]) - (102 - 124))) + (98 + B[2 * i3 + 16])) - ((B[2 * i5 - 13] * ((E[2 * i3 - 16] * D[1 * i6 + 16] - B[2 * i3 + 13]) - (98 * E[2 * i5 - 9] - A[2 * i3 - 13])) - ((B[1 * i6 - 13] * (A[1 * i5 + 9] + (98 - 124)) - 124 * A[2 * i6 - 13]) - (124 - (D[2 * i6 - 9] - 102)))) - (B[1 * i6 - 16] * A[2 * i6 + 13]) * 98);
      }
    }
  }
  for (int i5 = 38; i5 <= 67; i5+=1) {
    for (int i6 = 79; i6 <= 97; i6+=1) {
      for (int i2 = 67; i2 <= 69; i2+=1) {
          C[1 * i5 + 9] = (98 * (B[2 * i6 + 9] + E[2 * i5 + 9])) * (C[1 * i2 + 13] - (C[2 * i2 - 16] - B[1 * i2 - 13]) * C[2 * i5 + 13]) + (((A[2 * i6 + 13] * ((B[2 * i2 - 13] + B[2 * i5 + 13]) - (C[2 * i2 + 16] - D[1 * i2 + 13]))) * 124 + (A[1 * i2 - 13] * (102 * E[1 * i2 + 9]) + ((C[2 * i2 - 16] - E[1 * i6 + 16]) + D[1 * i5 - 16]) * 102)) + (102 + ((E[1 * i5 + 16] + ((124 + A[2 * i6 + 13]) + (A[1 * i2 - 9] + 124))) * E[1 * i2 + 13]) * A[2 * i5 - 9]));
      }
    }
  }
  for (int i5 = 38; i5 <= 67; i5+=1) {
    for (int i6 = 79; i6 <= 97; i6+=1) {
      for (int i2 = 67; i2 <= 69; i2+=1) {
          D[2 * i5 - 16] = (124 * 98 - (102 - 102)) * D[2 * i6 - 13] - ((B[2 * i2 - 16] - ((D[2 * i5 + 9] + 98) + (B[2 * i6 + 9] + 124))) - (D[2 * i2 + 13] * (C[2 * i6 - 16] + C[2 * i5 + 16]) - ((102 * D[2 * i2 - 13] + ((A[1 * i2 - 16] + 124) - 124) * ((D[2 * i6 - 13] + 102) * ((124 + B[1 * i2 - 13]) * 102))) - E[2 * i2 + 9] * 98) * (B[1 * i2 - 16] * 124))) * D[2 * i2 - 16];
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

