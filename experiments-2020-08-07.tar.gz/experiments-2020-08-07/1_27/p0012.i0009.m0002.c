#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 240], float B[restrict 243], float C[restrict 245], float D[restrict 241], float E[restrict 246]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i2 = 63; i2 <= 88; i2+=1) {
    for (int i1 = 6; i1 <= 40; i1+=1) {
      for (int i3 = 13; i3 <= 39; i3+=1) {
          A[2 * i2 + 0] = 32 * ((32 - (B[2 * i2 + 0] + C[1 * i2 - 2])) * (((B[1 * i2 - 0] * 30) * (30 - (((30 * 30 - ((D[1 * i2 - 3] + B[2 * i2 - 0]) - A[1 * i3 - 2])) + E[2 * i2 - 0] * 32) - 32)) + 32) + ((32 + (E[1 * i3 + 2] + E[2 * i1 + 2])) - C[1 * i3 + 3]) * ((A[2 * i1 - 3] - 30 * A[2 * i2 + 0]) * (33 * D[2 * i2 + 3] + E[1 * i1 - 2]) - (B[2 * i3 + 2] - B[2 * i2 - 3]))));
      }
    }
  }
  for (int i1 = 6; i1 <= 40; i1+=1) {
    for (int i4 = 4; i4 <= 118; i4+=1) {
      for (int i2 = 63; i2 <= 88; i2+=1) {
          E[2 * i4 + 3] = ((30 - (A[1 * i2 - 0] + (30 + 30))) + ((A[2 * i4 + 0] - D[2 * i1 - 3]) * ((E[1 * i1 + 3] * (33 - 33)) * A[2 * i2 - 3] + ((32 + B[1 * i2 - 0]) - E[1 * i1 + 0])) - E[1 * i1 + 2])) * ((A[1 * i4 - 3] - A[2 * i4 + 2]) + (32 - A[1 * i1 + 0])) + (((A[1 * i2 - 2] + B[2 * i1 + 3]) - A[1 * i4 - 3]) * (33 * 30) - (B[1 * i4 - 3] - (D[1 * i4 + 0] + E[1 * i2 - 2] * B[1 * i4 - 2])) * D[1 * i2 - 0]);
      }
    }
  }
  for (int i5 = 18; i5 <= 121; i5+=1) {
    for (int i3 = 13; i3 <= 39; i3+=1) {
      for (int i6 = 23; i6 <= 87; i6+=1) {
          C[2 * i5 + 0] = ((((C[1 * i6 + 0] + 32) + D[1 * i5 + 0]) - ((30 - E[1 * i5 + 2]) - (30 - 32))) + (33 + B[2 * i3 + 2])) - ((B[1 * i5 - 0] * ((E[2 * i3 - 2] * D[1 * i6 + 2] - B[1 * i3 + 0]) - (33 * E[1 * i5 - 3] - A[1 * i3 - 0])) - ((B[1 * i6 - 0] * (A[1 * i5 + 3] + (33 - 32)) - 32 * A[1 * i6 - 0]) - (32 - (D[2 * i6 - 3] - 30)))) - (B[1 * i6 - 2] * A[2 * i6 + 0]) * 33);
      }
    }
  }
  for (int i6 = 23; i6 <= 87; i6+=1) {
    for (int i5 = 18; i5 <= 121; i5+=1) {
      for (int i2 = 63; i2 <= 88; i2+=1) {
          C[1 * i5 + 3] = (33 * (B[1 * i6 + 3] + E[2 * i5 + 3])) * (C[1 * i2 + 0] - (C[2 * i2 - 2] - B[1 * i2 - 0]) * C[1 * i5 + 0]) + (((A[1 * i6 + 0] * ((B[2 * i2 - 0] + B[2 * i5 + 0]) - (C[1 * i2 + 2] - D[1 * i2 + 0]))) * 32 + (A[1 * i2 - 0] * (30 * E[1 * i2 + 3]) + ((C[1 * i2 - 2] - E[1 * i6 + 2]) + D[1 * i5 - 2]) * 30)) + (30 + ((E[1 * i5 + 2] + ((32 + A[2 * i6 + 0]) + (A[1 * i2 - 3] + 32))) * E[1 * i2 + 0]) * A[2 * i5 - 3]));
      }
    }
  }
  for (int i5 = 18; i5 <= 121; i5+=1) {
    for (int i6 = 23; i6 <= 87; i6+=1) {
      for (int i2 = 63; i2 <= 88; i2+=1) {
          D[2 * i5 - 2] = (32 * 33 - (30 - 30)) * D[1 * i6 - 0] - ((B[2 * i2 - 2] - ((D[1 * i5 + 3] + 33) + (B[2 * i6 + 3] + 32))) - (D[2 * i2 + 0] * (C[1 * i6 - 2] + C[2 * i5 + 2]) - ((30 * D[1 * i2 - 0] + ((A[1 * i2 - 2] + 32) - 32) * ((D[1 * i6 - 0] + 30) * ((32 + B[1 * i2 - 0]) * 30))) - E[1 * i2 + 3] * 33) * (B[1 * i2 - 2] * 32))) * D[1 * i2 - 2];
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

