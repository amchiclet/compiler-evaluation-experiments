#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 218], float B[restrict 215], float C[restrict 196], float D[restrict 247], float E[restrict 244]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 68; i1 <= 69; i1+=1) {
    for (int i2 = 51; i2 <= 103; i2+=1) {
      for (int i3 = 26; i3 <= 70; i3+=1) {
          A[2 * i3 - 8] = ((107 * B[2 * i3 + 11]) * (4 + A[2 * i2 + 5]) + (C[2 * i1 - 5] - 122 * D[2 * i1 + 5])) - (((((((C[2 * i3 - 5] + E[2 * i3 + 5]) + D[2 * i2 + 11]) - A[2 * i3 - 5] * 4) - (107 + E[2 * i1 + 8])) - (4 + 4)) - (122 - D[2 * i2 - 8] * 122) * ((122 - C[2 * i3 + 5]) * (4 * C[2 * i1 - 11]))) - ((D[2 * i3 - 8] + (B[2 * i3 - 8] - 107)) - (107 + A[2 * i3 - 8])));
      }
    }
  }
  for (int i4 = 49; i4 <= 66; i4+=1) {
    for (int i2 = 51; i2 <= 103; i2+=1) {
      for (int i3 = 26; i3 <= 70; i3+=1) {
          C[2 * i3 + 5] = (((C[2 * i4 - 11] * C[2 * i2 - 11] - A[2 * i2 - 11] * 122) - ((107 * D[2 * i4 - 11]) * A[2 * i4 - 8] - A[2 * i4 + 11])) + (4 + (122 + (C[2 * i3 + 5] * B[2 * i2 + 8] + ((E[2 * i4 - 8] - 107 * 122) + (A[2 * i4 + 5] + 4 * 107)))))) * (((E[2 * i4 - 11] - B[2 * i3 + 11]) * A[2 * i2 + 11]) * (((107 - 4) - (E[2 * i3 - 5] * E[2 * i2 - 8] - (A[2 * i4 - 11] - B[2 * i2 - 5]))) * E[2 * i3 - 8]));
      }
    }
  }
  for (int i1 = 68; i1 <= 69; i1+=1) {
    for (int i5 = 28; i5 <= 119; i5+=1) {
      for (int i4 = 49; i4 <= 66; i4+=1) {
          D[2 * i4 - 8] = (107 - ((E[2 * i1 - 5] - ((A[2 * i4 - 11] + B[2 * i1 - 8]) - 122)) - (A[2 * i4 + 11] - D[2 * i5 - 11]))) + ((4 * 122 - D[2 * i5 - 11]) - (E[2 * i5 - 5] * E[2 * i5 + 5] + (122 - (E[2 * i1 - 8] + A[2 * i4 - 5])))) * (((D[2 * i1 - 8] + 122) - (B[2 * i1 - 8] - E[2 * i5 + 5])) * D[2 * i5 + 8] + ((D[2 * i4 - 11] - (D[2 * i4 - 11] + ((107 + 122) - (122 + B[2 * i4 + 8])))) + C[2 * i4 - 11] * 4));
      }
    }
  }
  for (int i6 = 6; i6 <= 56; i6+=1) {
    for (int i3 = 26; i3 <= 70; i3+=1) {
      for (int i4 = 49; i4 <= 66; i4+=1) {
          D[2 * i6 - 8] = (122 * ((4 * (107 - D[2 * i3 - 11])) * (((4 - 107) + (D[2 * i3 + 11] - D[2 * i6 - 5])) - (C[2 * i6 + 11] + ((C[2 * i6 + 11] + B[2 * i3 - 11]) - 4)) * (B[2 * i3 - 11] * B[2 * i3 + 11])))) * ((D[2 * i3 + 8] * ((A[2 * i6 + 11] - A[2 * i3 - 5]) * E[2 * i3 + 8])) * 4) + (((B[2 * i4 - 8] * C[2 * i6 + 8] + (C[2 * i3 - 11] - C[2 * i6 - 8])) + (C[2 * i3 - 8] - (E[2 * i6 - 8] + B[2 * i3 + 8]))) - (122 + C[2 * i3 + 11]));
      }
    }
  }
  for (int i3 = 26; i3 <= 70; i3+=1) {
    for (int i1 = 68; i1 <= 69; i1+=1) {
      for (int i4 = 49; i4 <= 66; i4+=1) {
          C[2 * i4 + 8] = (4 * E[2 * i3 - 5] + (C[2 * i3 - 5] - (((C[2 * i3 - 8] - 4) - (B[2 * i4 + 8] - 107) * (C[2 * i4 + 5] * B[2 * i3 - 8])) - (B[2 * i1 + 5] - D[2 * i1 + 11]) * (107 + 107)))) * ((4 - D[2 * i4 + 11]) * (((E[2 * i3 - 5] + E[2 * i4 + 8]) + (((E[2 * i1 + 5] + D[2 * i1 + 5] * D[2 * i3 + 8]) - (4 + D[2 * i1 + 11] * C[2 * i4 - 5])) - D[2 * i1 + 11] * E[2 * i4 - 8])) * (A[2 * i4 + 5] - (D[2 * i1 + 11] - C[2 * i3 + 11]))));
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

