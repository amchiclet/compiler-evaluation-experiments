#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 243], float B[restrict 256], float C[restrict 247], float D[restrict 256], float E[restrict 256]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 53; i1 <= 54; i1+=1) {
    for (int i2 = 21; i2 <= 69; i2+=1) {
      for (int i3 = 68; i3 <= 90; i3+=1) {
          A[2 * i2 + 2] = (((B[2 * i2 + 11] + C[2 * i3 - 2]) + B[2 * i2 + 11] * (D[2 * i3 - 2] - E[2 * i3 + 2])) + (C[2 * i1 - 11] - 120)) * (E[2 * i1 + 2] + (E[2 * i1 + 2] + 110)) - (D[2 * i1 - 6] * (E[2 * i2 - 6] * E[2 * i2 - 11])) * (((122 + A[2 * i2 + 11]) * (E[2 * i3 - 11] - (((122 - 110) - 120) - (B[2 * i2 + 2] + ((C[2 * i1 - 11] - E[2 * i3 + 6]) + 120))))) * (110 * (122 - (B[2 * i1 + 2] - (D[2 * i2 + 2] - B[2 * i3 - 2])))));
      }
    }
  }
  for (int i3 = 68; i3 <= 90; i3+=1) {
    for (int i5 = 61; i5 <= 82; i5+=1) {
      for (int i4 = 11; i4 <= 24; i4+=1) {
          B[2 * i4 + 6] = (((E[2 * i4 - 2] * B[2 * i5 + 11]) * ((E[2 * i4 - 2] - A[2 * i4 + 11]) * 122) - (110 * 120 - B[2 * i4 + 11])) - (120 - D[2 * i4 + 6])) * ((120 + B[2 * i4 + 11]) * ((A[2 * i4 + 6] + (B[2 * i4 - 11] - 110)) * (((D[2 * i4 - 6] - 120) - E[2 * i3 + 6]) * ((122 * 120 - ((110 - B[2 * i5 + 6]) - C[2 * i5 - 11])) + (110 + A[2 * i3 - 2]) * ((120 + 110) + 110)))));
      }
    }
  }
  for (int i1 = 53; i1 <= 54; i1+=1) {
    for (int i4 = 11; i4 <= 24; i4+=1) {
      for (int i2 = 21; i2 <= 69; i2+=1) {
          E[2 * i1 + 6] = (C[2 * i2 + 6] + A[2 * i1 - 11]) - (((D[2 * i1 + 6] + ((110 + E[2 * i1 + 11]) + 122)) + ((B[2 * i2 - 2] - B[2 * i4 - 6] * B[2 * i1 + 6]) + (120 - ((122 + D[2 * i4 - 6]) + E[2 * i4 - 6])))) * (E[2 * i4 - 11] * E[2 * i1 + 6] + (A[2 * i4 - 6] - (E[2 * i2 - 2] - (E[2 * i4 - 6] - E[2 * i1 + 2])))) - ((B[2 * i1 + 6] * 120 + (120 - 122) * (D[2 * i4 - 2] + (110 - D[2 * i2 - 2]))) + (E[2 * i4 + 6] - B[2 * i4 - 11])));
      }
    }
  }
  for (int i6 = 85; i6 <= 122; i6+=1) {
    for (int i3 = 68; i3 <= 90; i3+=1) {
      for (int i1 = 53; i1 <= 54; i1+=1) {
          A[2 * i1 - 6] = (((122 + B[2 * i6 + 11]) * D[2 * i3 - 2] - B[2 * i6 - 11]) + ((E[2 * i3 - 11] + (((A[2 * i1 - 11] + (C[2 * i6 - 11] + 122)) + 120) + 110 * (A[2 * i1 + 2] + C[2 * i1 - 6]))) + D[2 * i1 + 2] * 120)) - ((122 * 110 + (122 - C[2 * i6 + 2])) + ((B[2 * i1 + 11] * ((E[2 * i3 - 2] * C[2 * i1 - 6]) * C[2 * i3 - 6])) * (122 - B[2 * i1 - 6]) + ((B[2 * i6 + 6] - C[2 * i6 - 6]) + (120 - A[2 * i1 - 6]))));
      }
    }
  }
  for (int i6 = 85; i6 <= 122; i6+=1) {
    for (int i2 = 21; i2 <= 69; i2+=1) {
      for (int i5 = 61; i5 <= 82; i5+=1) {
          E[2 * i5 + 11] = ((B[2 * i2 + 6] + (122 - (D[2 * i5 - 6] * E[2 * i5 - 11]) * C[2 * i6 - 6])) * (((A[2 * i6 - 6] + 120) - (120 + D[2 * i6 + 6])) - C[2 * i5 - 6])) * (((D[2 * i5 + 11] + (120 - D[2 * i6 + 2])) * (((110 + 122) + (((A[2 * i2 - 6] * 122) * E[2 * i6 + 11] + A[2 * i5 - 2]) + (110 - C[2 * i2 - 2]))) - ((E[2 * i2 - 2] - (120 + 122)) + A[2 * i2 - 6]))) * (A[2 * i6 - 2] - (E[2 * i6 + 6] - D[2 * i6 + 11])));
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

