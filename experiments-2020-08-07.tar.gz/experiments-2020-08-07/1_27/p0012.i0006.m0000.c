#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 250], float B[restrict 241], float C[restrict 231], float D[restrict 235], float E[restrict 250]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 79; i1 <= 237; i1+=1) {
    for (int i2 = 68; i2 <= 88; i2+=1) {
      for (int i3 = 68; i3 <= 108; i3+=1) {
          A[1 * i2 + 12] = 106 * ((106 - (B[1 * i2 + 12] + C[1 * i2 - 7])) * (((B[1 * i2 - 12] * 0) * (0 - (((0 * 0 - ((D[1 * i2 - 3] + B[1 * i2 - 12]) - A[1 * i3 - 7])) + E[1 * i2 - 12] * 106) - 106)) + 106) + ((106 + (E[1 * i3 + 7] + E[1 * i1 + 7])) - C[1 * i3 + 3]) * ((A[1 * i1 - 3] - 0 * A[1 * i2 + 12]) * (2 * D[1 * i2 + 3] + E[1 * i1 - 7]) - (B[1 * i3 + 7] - B[1 * i2 - 3]))));
      }
    }
  }
  for (int i1 = 79; i1 <= 237; i1+=1) {
    for (int i4 = 49; i4 <= 125; i4+=1) {
      for (int i2 = 68; i2 <= 88; i2+=1) {
          E[1 * i4 + 3] = ((0 - (A[1 * i2 - 12] + (0 + 0))) + ((A[1 * i4 + 12] - D[1 * i1 - 3]) * ((E[1 * i1 + 3] * (2 - 2)) * A[1 * i2 - 3] + ((106 + B[1 * i2 - 12]) - E[1 * i1 + 12])) - E[1 * i1 + 7])) * ((A[1 * i4 - 3] - A[1 * i4 + 7]) + (106 - A[1 * i1 + 12])) + (((A[1 * i2 - 7] + B[1 * i1 + 3]) - A[1 * i4 - 3]) * (2 * 0) - (B[1 * i4 - 3] - (D[1 * i4 + 12] + E[1 * i2 - 7] * B[1 * i4 - 7])) * D[1 * i2 - 12]);
      }
    }
  }
  for (int i5 = 55; i5 <= 128; i5+=1) {
    for (int i3 = 68; i3 <= 108; i3+=1) {
      for (int i6 = 122; i6 <= 218; i6+=1) {
          C[1 * i5 + 12] = ((((C[1 * i6 + 12] + 106) + D[1 * i5 + 12]) - ((0 - E[1 * i5 + 7]) - (0 - 106))) + (2 + B[1 * i3 + 7])) - ((B[1 * i5 - 12] * ((E[1 * i3 - 7] * D[1 * i6 + 7] - B[1 * i3 + 12]) - (2 * E[1 * i5 - 3] - A[1 * i3 - 12])) - ((B[1 * i6 - 12] * (A[1 * i5 + 3] + (2 - 106)) - 106 * A[1 * i6 - 12]) - (106 - (D[1 * i6 - 3] - 0)))) - (B[1 * i6 - 7] * A[1 * i6 + 12]) * 2);
      }
    }
  }
  for (int i6 = 122; i6 <= 218; i6+=1) {
    for (int i5 = 55; i5 <= 128; i5+=1) {
      for (int i2 = 68; i2 <= 88; i2+=1) {
          C[1 * i5 + 3] = (2 * (B[1 * i6 + 3] + E[1 * i5 + 3])) * (C[1 * i2 + 12] - (C[1 * i2 - 7] - B[1 * i2 - 12]) * C[1 * i5 + 12]) + (((A[1 * i6 + 12] * ((B[1 * i2 - 12] + B[1 * i5 + 12]) - (C[1 * i2 + 7] - D[1 * i2 + 12]))) * 106 + (A[1 * i2 - 12] * (0 * E[1 * i2 + 3]) + ((C[1 * i2 - 7] - E[1 * i6 + 7]) + D[1 * i5 - 7]) * 0)) + (0 + ((E[1 * i5 + 7] + ((106 + A[1 * i6 + 12]) + (A[1 * i2 - 3] + 106))) * E[1 * i2 + 12]) * A[1 * i5 - 3]));
      }
    }
  }
  for (int i5 = 55; i5 <= 128; i5+=1) {
    for (int i6 = 122; i6 <= 218; i6+=1) {
      for (int i2 = 68; i2 <= 88; i2+=1) {
          D[1 * i5 - 7] = (106 * 2 - (0 - 0)) * D[1 * i6 - 12] - ((B[1 * i2 - 7] - ((D[1 * i5 + 3] + 2) + (B[1 * i6 + 3] + 106))) - (D[1 * i2 + 12] * (C[1 * i6 - 7] + C[1 * i5 + 7]) - ((0 * D[1 * i2 - 12] + ((A[1 * i2 - 7] + 106) - 106) * ((D[1 * i6 - 12] + 0) * ((106 + B[1 * i2 - 12]) * 0))) - E[1 * i2 + 3] * 2) * (B[1 * i2 - 7] * 106))) * D[1 * i2 - 7];
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

