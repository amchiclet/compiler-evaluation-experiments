#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 236], float B[restrict 240], float C[restrict 243], float D[restrict 236], float E[restrict 239]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 22; i1 <= 116; i1+=1) {
    for (int i2 = 23; i2 <= 100; i2+=1) {
      for (int i3 = 45; i3 <= 61; i3+=1) {
          A[2 * i2 + 5] = (((B[2 * i2 + 3] - 63) * (72 + (C[2 * i1 + 6] - 72)) + A[2 * i2 - 6]) - (((72 - D[2 * i1 - 6]) - B[2 * i1 - 6]) + (72 + D[2 * i2 + 5]))) - (((81 * 63 - (D[2 * i3 - 3] + A[2 * i1 - 5])) + ((72 * A[2 * i3 + 6] - A[2 * i1 + 3]) + D[2 * i3 - 6] * 63) * C[2 * i3 - 3]) - ((B[2 * i3 - 6] * D[2 * i1 - 3] + 63 * 72) - (63 + D[2 * i3 - 5] * B[2 * i1 + 3])));
      }
    }
  }
  for (int i3 = 45; i3 <= 61; i3+=1) {
    for (int i2 = 23; i2 <= 100; i2+=1) {
      for (int i4 = 36; i4 <= 83; i4+=1) {
          B[2 * i2 + 3] = ((((((D[2 * i4 - 6] + 63) + C[2 * i4 + 5]) - A[2 * i3 - 5]) - D[2 * i4 - 5]) + 72) - 63) * (((72 + (72 + (72 + C[2 * i4 + 5]))) + 63) + (((A[2 * i4 - 6] - 81) * ((D[2 * i4 - 3] * A[2 * i3 - 6]) * 72) - E[2 * i3 + 3]) + (D[2 * i3 - 3] + (72 - ((D[2 * i3 + 3] - 63) + A[2 * i3 - 6] * 72)) * (A[2 * i4 + 6] + 72)))) + (63 + E[2 * i2 + 3]);
      }
    }
  }
  for (int i4 = 36; i4 <= 83; i4+=1) {
    for (int i1 = 22; i1 <= 116; i1+=1) {
      for (int i5 = 35; i5 <= 61; i5+=1) {
          D[2 * i4 - 6] = (((B[2 * i5 - 5] - 81) * (C[2 * i5 - 5] - ((72 + A[2 * i5 - 3]) - C[2 * i4 - 5])) + (((D[2 * i5 - 3] - 72) - 81) - A[2 * i5 - 6])) - (D[2 * i1 - 5] - C[2 * i4 - 3])) + ((C[2 * i4 + 5] - ((81 + D[2 * i4 + 5]) + 63 * (E[2 * i4 + 6] + D[2 * i1 + 3] * 81))) - ((A[2 * i5 + 6] * D[2 * i5 - 6] - B[2 * i1 + 3]) - 81)) * ((D[2 * i5 - 3] + (C[2 * i1 - 6] - B[2 * i5 - 6])) - (C[2 * i4 - 6] - 63));
      }
    }
  }
  for (int i4 = 36; i4 <= 83; i4+=1) {
    for (int i1 = 22; i1 <= 116; i1+=1) {
      for (int i3 = 45; i3 <= 61; i3+=1) {
          E[2 * i3 + 3] = ((A[2 * i3 - 6] * (B[2 * i4 - 6] - 81)) * (((D[2 * i1 + 3] + (E[2 * i3 - 5] + 81)) + (72 * 81 + C[2 * i1 + 3])) + (72 * ((B[2 * i3 + 3] + E[2 * i3 - 3]) + E[2 * i1 + 6])) * ((63 + (81 - (D[2 * i4 + 3] * E[2 * i4 + 5] + 72))) - (((B[2 * i3 - 5] + D[2 * i4 - 3]) + 81) + 63)))) * ((E[2 * i3 + 3] - B[2 * i3 - 5]) + ((72 - E[2 * i1 + 6]) + 63 * E[2 * i3 - 5]));
      }
    }
  }
  for (int i6 = 86; i6 <= 118; i6+=1) {
    for (int i5 = 35; i5 <= 61; i5+=1) {
      for (int i3 = 45; i3 <= 61; i3+=1) {
          C[2 * i6 - 3] = ((C[2 * i6 + 6] * C[2 * i5 + 6] + ((B[2 * i5 + 3] * ((A[2 * i5 + 5] + B[2 * i3 + 6]) * D[2 * i6 - 3]) + D[2 * i5 - 5] * (63 + D[2 * i5 + 6])) + A[2 * i3 + 6])) - (B[2 * i3 + 3] * B[2 * i6 + 3] + 72)) + ((E[2 * i5 + 5] + B[2 * i6 - 3]) * ((E[2 * i3 - 5] - 63) * B[2 * i6 + 3] - (C[2 * i3 - 5] - 81))) * (72 * C[2 * i6 + 6] + ((B[2 * i5 + 3] - (D[2 * i3 - 5] + 72)) - (B[2 * i3 + 6] + (C[2 * i6 - 6] + B[2 * i3 + 3]))));
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

