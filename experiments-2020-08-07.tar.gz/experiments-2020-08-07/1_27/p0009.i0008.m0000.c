#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 245], float B[restrict 242], float C[restrict 196], float D[restrict 255], float E[restrict 252]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 67; i1 <= 104; i1+=1) {
    for (int i2 = 17; i2 <= 89; i2+=1) {
      for (int i3 = 80; i3 <= 87; i3+=1) {
          A[1 * i2 + 11] = (((B[2 * i2 + 13] + C[1 * i3 - 11]) + B[1 * i2 + 13] * (D[1 * i3 - 11] - E[2 * i3 + 11])) + (C[1 * i1 - 13] - 6)) * (E[2 * i1 + 11] + (E[1 * i1 + 11] + 15)) - (D[2 * i1 - 16] * (E[1 * i2 - 16] * E[1 * i2 - 13])) * (((31 + A[1 * i2 + 13]) * (E[2 * i3 - 13] - (((31 - 15) - 6) - (B[1 * i2 + 11] + ((C[2 * i1 - 13] - E[1 * i3 + 16]) + 6))))) * (15 * (31 - (B[2 * i1 + 11] - (D[1 * i2 + 11] - B[2 * i3 - 11])))));
      }
    }
  }
  for (int i4 = 62; i4 <= 114; i4+=1) {
    for (int i3 = 80; i3 <= 87; i3+=1) {
      for (int i5 = 16; i5 <= 36; i5+=1) {
          B[1 * i4 + 16] = (((E[2 * i4 - 11] * B[2 * i5 + 13]) * ((E[1 * i4 - 11] - A[1 * i4 + 13]) * 31) - (15 * 6 - B[2 * i4 + 13])) - (6 - D[1 * i4 + 16])) * ((6 + B[1 * i4 + 13]) * ((A[2 * i4 + 16] + (B[1 * i4 - 13] - 15)) * (((D[2 * i4 - 16] - 6) - E[1 * i3 + 16]) * ((31 * 6 - ((15 - B[2 * i5 + 16]) - C[1 * i5 - 13])) + (15 + A[1 * i3 - 11]) * ((6 + 15) + 15)))));
      }
    }
  }
  for (int i1 = 67; i1 <= 104; i1+=1) {
    for (int i4 = 62; i4 <= 114; i4+=1) {
      for (int i2 = 17; i2 <= 89; i2+=1) {
          E[2 * i1 + 16] = (C[1 * i2 + 16] + A[1 * i1 - 13]) - (((D[1 * i1 + 16] + ((15 + E[1 * i1 + 13]) + 31)) + ((B[2 * i2 - 11] - B[1 * i4 - 16] * B[1 * i1 + 16]) + (6 - ((31 + D[1 * i4 - 16]) + E[1 * i4 - 16])))) * (E[1 * i4 - 13] * E[1 * i1 + 16] + (A[1 * i4 - 16] - (E[1 * i2 - 11] - (E[2 * i4 - 16] - E[1 * i1 + 11])))) - ((B[1 * i1 + 16] * 6 + (6 - 31) * (D[1 * i4 - 11] + (15 - D[1 * i2 - 11]))) + (E[1 * i4 + 16] - B[1 * i4 - 13])));
      }
    }
  }
  for (int i1 = 67; i1 <= 104; i1+=1) {
    for (int i6 = 110; i6 <= 119; i6+=1) {
      for (int i3 = 80; i3 <= 87; i3+=1) {
          A[1 * i1 - 16] = (((31 + B[1 * i6 + 13]) * D[2 * i3 - 11] - B[2 * i6 - 13]) + ((E[1 * i3 - 13] + (((A[1 * i1 - 13] + (C[1 * i6 - 13] + 31)) + 6) + 15 * (A[1 * i1 + 11] + C[1 * i1 - 16]))) + D[2 * i1 + 11] * 6)) - ((31 * 15 + (31 - C[1 * i6 + 11])) + ((B[2 * i1 + 13] * ((E[1 * i3 - 11] * C[1 * i1 - 16]) * C[2 * i3 - 16])) * (31 - B[1 * i1 - 16]) + ((B[1 * i6 + 16] - C[1 * i6 - 16]) + (6 - A[2 * i1 - 16]))));
      }
    }
  }
  for (int i6 = 110; i6 <= 119; i6+=1) {
    for (int i2 = 17; i2 <= 89; i2+=1) {
      for (int i5 = 16; i5 <= 36; i5+=1) {
          E[1 * i5 + 13] = ((B[2 * i2 + 16] + (31 - (D[1 * i5 - 16] * E[1 * i5 - 13]) * C[1 * i6 - 16])) * (((A[1 * i6 - 16] + 6) - (6 + D[2 * i6 + 16])) - C[1 * i5 - 16])) * (((D[1 * i5 + 13] + (6 - D[1 * i6 + 11])) * (((15 + 31) + (((A[1 * i2 - 16] * 31) * E[2 * i6 + 13] + A[1 * i5 - 11]) + (15 - C[1 * i2 - 11]))) - ((E[1 * i2 - 11] - (6 + 31)) + A[1 * i2 - 16]))) * (A[1 * i6 - 11] - (E[1 * i6 + 16] - D[2 * i6 + 13])));
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

