#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 236], float B[restrict 230], float C[restrict 216], float D[restrict 236], float E[restrict 216]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 13; i1 <= 38; i1+=1) {
    for (int i2 = 99; i2 <= 101; i2+=1) {
      for (int i3 = 84; i3 <= 101; i3+=1) {
          A[1 * i2 + 11] = 107 * ((107 - (B[1 * i2 + 11] + C[1 * i2 - 13])) * (((B[2 * i2 - 11] * 37) * (37 - (((37 * 37 - ((D[2 * i2 - 5] + B[1 * i2 - 11]) - A[2 * i3 - 13])) + E[1 * i2 - 11] * 107) - 107)) + 107) + ((107 + (E[2 * i3 + 13] + E[1 * i1 + 13])) - C[1 * i3 + 5]) * ((A[1 * i1 - 5] - 37 * A[1 * i2 + 11]) * (59 * D[1 * i2 + 5] + E[1 * i1 - 13]) - (B[1 * i3 + 13] - B[1 * i2 - 5]))));
      }
    }
  }
  for (int i1 = 13; i1 <= 38; i1+=1) {
    for (int i4 = 36; i4 <= 112; i4+=1) {
      for (int i2 = 99; i2 <= 101; i2+=1) {
          E[1 * i4 + 5] = ((37 - (A[1 * i2 - 11] + (37 + 37))) + ((A[1 * i4 + 11] - D[1 * i1 - 5]) * ((E[1 * i1 + 5] * (59 - 59)) * A[1 * i2 - 5] + ((107 + B[2 * i2 - 11]) - E[1 * i1 + 11])) - E[1 * i1 + 13])) * ((A[1 * i4 - 5] - A[1 * i4 + 13]) + (107 - A[2 * i1 + 11])) + (((A[2 * i2 - 13] + B[1 * i1 + 5]) - A[2 * i4 - 5]) * (59 * 37) - (B[2 * i4 - 5] - (D[2 * i4 + 11] + E[2 * i2 - 13] * B[2 * i4 - 13])) * D[1 * i2 - 11]);
      }
    }
  }
  for (int i3 = 84; i3 <= 101; i3+=1) {
    for (int i5 = 62; i5 <= 100; i5+=1) {
      for (int i6 = 101; i6 <= 112; i6+=1) {
          C[1 * i5 + 11] = ((((C[1 * i6 + 11] + 107) + D[2 * i5 + 11]) - ((37 - E[1 * i5 + 13]) - (37 - 107))) + (59 + B[1 * i3 + 13])) - ((B[2 * i5 - 11] * ((E[1 * i3 - 13] * D[1 * i6 + 13] - B[2 * i3 + 11]) - (59 * E[2 * i5 - 5] - A[2 * i3 - 11])) - ((B[1 * i6 - 11] * (A[1 * i5 + 5] + (59 - 107)) - 107 * A[2 * i6 - 11]) - (107 - (D[1 * i6 - 5] - 37)))) - (B[1 * i6 - 13] * A[1 * i6 + 11]) * 59);
      }
    }
  }
  for (int i6 = 101; i6 <= 112; i6+=1) {
    for (int i5 = 62; i5 <= 100; i5+=1) {
      for (int i2 = 99; i2 <= 101; i2+=1) {
          C[1 * i5 + 5] = (59 * (B[2 * i6 + 5] + E[1 * i5 + 5])) * (C[1 * i2 + 11] - (C[1 * i2 - 13] - B[1 * i2 - 11]) * C[2 * i5 + 11]) + (((A[2 * i6 + 11] * ((B[1 * i2 - 11] + B[1 * i5 + 11]) - (C[2 * i2 + 13] - D[1 * i2 + 11]))) * 107 + (A[1 * i2 - 11] * (37 * E[1 * i2 + 5]) + ((C[2 * i2 - 13] - E[1 * i6 + 13]) + D[1 * i5 - 13]) * 37)) + (37 + ((E[1 * i5 + 13] + ((107 + A[1 * i6 + 11]) + (A[1 * i2 - 5] + 107))) * E[1 * i2 + 11]) * A[1 * i5 - 5]));
      }
    }
  }
  for (int i6 = 101; i6 <= 112; i6+=1) {
    for (int i2 = 99; i2 <= 101; i2+=1) {
      for (int i5 = 62; i5 <= 100; i5+=1) {
          D[1 * i5 - 13] = (107 * 59 - (37 - 37)) * D[2 * i6 - 11] - ((B[1 * i2 - 13] - ((D[2 * i5 + 5] + 59) + (B[1 * i6 + 5] + 107))) - (D[1 * i2 + 11] * (C[2 * i6 - 13] + C[1 * i5 + 13]) - ((37 * D[2 * i2 - 11] + ((A[1 * i2 - 13] + 107) - 107) * ((D[2 * i6 - 11] + 37) * ((107 + B[1 * i2 - 11]) * 37))) - E[2 * i2 + 5] * 59) * (B[1 * i2 - 13] * 107))) * D[2 * i2 - 13];
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

