#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 230], float B[restrict 242], float C[restrict 232], float D[restrict 232], float E[restrict 242]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 36; i1 <= 96; i1+=1) {
    for (int i2 = 90; i2 <= 91; i2+=1) {
      for (int i3 = 18; i3 <= 118; i3+=1) {
          A[1 * i2 + 8] = (((B[2 * i2 + 5] - 67) * (49 + (C[1 * i1 + 7] - 49)) + A[2 * i2 - 7]) - (((49 - D[1 * i1 - 7]) - B[2 * i1 - 7]) + (49 + D[2 * i2 + 8]))) - (((15 * 67 - (D[2 * i3 - 5] + A[1 * i1 - 8])) + ((49 * A[1 * i3 + 7] - A[1 * i1 + 5]) + D[1 * i3 - 7] * 67) * C[2 * i3 - 5]) - ((B[1 * i3 - 7] * D[2 * i1 - 5] + 67 * 49) - (67 + D[2 * i3 - 8] * B[2 * i1 + 5])));
      }
    }
  }
  for (int i3 = 18; i3 <= 118; i3+=1) {
    for (int i4 = 43; i4 <= 96; i4+=1) {
      for (int i2 = 90; i2 <= 91; i2+=1) {
          B[1 * i2 + 5] = ((((((D[1 * i4 - 7] + 67) + C[2 * i4 + 8]) - A[1 * i3 - 8]) - D[1 * i4 - 8]) + 49) - 67) * (((49 + (49 + (49 + C[1 * i4 + 8]))) + 67) + (((A[2 * i4 - 7] - 15) * ((D[1 * i4 - 5] * A[2 * i3 - 7]) * 49) - E[2 * i3 + 5]) + (D[2 * i3 - 5] + (49 - ((D[1 * i3 + 5] - 67) + A[2 * i3 - 7] * 49)) * (A[1 * i4 + 7] + 49)))) + (67 + E[1 * i2 + 5]);
      }
    }
  }
  for (int i4 = 43; i4 <= 96; i4+=1) {
    for (int i1 = 36; i1 <= 96; i1+=1) {
      for (int i5 = 108; i5 <= 115; i5+=1) {
          D[1 * i4 - 7] = (((B[1 * i5 - 8] - 15) * (C[2 * i5 - 8] - ((49 + A[2 * i5 - 5]) - C[1 * i4 - 8])) + (((D[2 * i5 - 5] - 49) - 15) - A[1 * i5 - 7])) - (D[1 * i1 - 8] - C[1 * i4 - 5])) + ((C[1 * i4 + 8] - ((15 + D[2 * i4 + 8]) + 67 * (E[1 * i4 + 7] + D[1 * i1 + 5] * 15))) - ((A[1 * i5 + 7] * D[2 * i5 - 7] - B[1 * i1 + 5]) - 15)) * ((D[2 * i5 - 5] + (C[1 * i1 - 7] - B[1 * i5 - 7])) - (C[1 * i4 - 7] - 67));
      }
    }
  }
  for (int i4 = 43; i4 <= 96; i4+=1) {
    for (int i1 = 36; i1 <= 96; i1+=1) {
      for (int i3 = 18; i3 <= 118; i3+=1) {
          E[1 * i3 + 5] = ((A[2 * i3 - 7] * (B[1 * i4 - 7] - 15)) * (((D[2 * i1 + 5] + (E[1 * i3 - 8] + 15)) + (49 * 15 + C[1 * i1 + 5])) + (49 * ((B[2 * i3 + 5] + E[1 * i3 - 5]) + E[1 * i1 + 7])) * ((67 + (15 - (D[2 * i4 + 5] * E[1 * i4 + 8] + 49))) - (((B[1 * i3 - 8] + D[1 * i4 - 5]) + 15) + 67)))) * ((E[1 * i3 + 5] - B[1 * i3 - 8]) + ((49 - E[1 * i1 + 7]) + 67 * E[1 * i3 - 8]));
      }
    }
  }
  for (int i5 = 108; i5 <= 115; i5+=1) {
    for (int i3 = 18; i3 <= 118; i3+=1) {
      for (int i6 = 13; i6 <= 40; i6+=1) {
          C[1 * i6 - 5] = ((C[1 * i6 + 7] * C[1 * i5 + 7] + ((B[1 * i5 + 5] * ((A[1 * i5 + 8] + B[1 * i3 + 7]) * D[2 * i6 - 5]) + D[1 * i5 - 8] * (67 + D[1 * i5 + 7])) + A[1 * i3 + 7])) - (B[1 * i3 + 5] * B[2 * i6 + 5] + 49)) + ((E[2 * i5 + 8] + B[1 * i6 - 5]) * ((E[1 * i3 - 8] - 67) * B[1 * i6 + 5] - (C[1 * i3 - 8] - 15))) * (49 * C[1 * i6 + 7] + ((B[1 * i5 + 5] - (D[2 * i3 - 8] + 49)) - (B[1 * i3 + 7] + (C[1 * i6 - 7] + B[2 * i3 + 5]))));
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

