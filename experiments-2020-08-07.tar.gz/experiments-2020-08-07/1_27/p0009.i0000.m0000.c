#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 228], float B[restrict 229], float C[restrict 204], float D[restrict 229], float E[restrict 229]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 49; i1 <= 106; i1+=1) {
    for (int i2 = 47; i2 <= 92; i2+=1) {
      for (int i3 = 33; i3 <= 80; i3+=1) {
          A[2 * i2 + 15] = (((B[1 * i2 + 9] + C[2 * i3 - 15]) + B[2 * i2 + 9] * (D[2 * i3 - 15] - E[1 * i3 + 15])) + (C[2 * i1 - 9] - 84)) * (E[1 * i1 + 15] + (E[2 * i1 + 15] + 63)) - (D[1 * i1 - 16] * (E[2 * i2 - 16] * E[2 * i2 - 9])) * (((56 + A[2 * i2 + 9]) * (E[1 * i3 - 9] - (((56 - 63) - 84) - (B[2 * i2 + 15] + ((C[1 * i1 - 9] - E[2 * i3 + 16]) + 84))))) * (63 * (56 - (B[1 * i1 + 15] - (D[2 * i2 + 15] - B[1 * i3 - 15])))));
      }
    }
  }
  for (int i4 = 22; i4 <= 90; i4+=1) {
    for (int i3 = 33; i3 <= 80; i3+=1) {
      for (int i5 = 16; i5 <= 28; i5+=1) {
          B[2 * i4 + 16] = (((E[1 * i4 - 15] * B[1 * i5 + 9]) * ((E[2 * i4 - 15] - A[2 * i4 + 9]) * 56) - (63 * 84 - B[1 * i4 + 9])) - (84 - D[2 * i4 + 16])) * ((84 + B[2 * i4 + 9]) * ((A[1 * i4 + 16] + (B[2 * i4 - 9] - 63)) * (((D[1 * i4 - 16] - 84) - E[2 * i3 + 16]) * ((56 * 84 - ((63 - B[1 * i5 + 16]) - C[2 * i5 - 9])) + (63 + A[2 * i3 - 15]) * ((84 + 63) + 63)))));
      }
    }
  }
  for (int i1 = 49; i1 <= 106; i1+=1) {
    for (int i4 = 22; i4 <= 90; i4+=1) {
      for (int i2 = 47; i2 <= 92; i2+=1) {
          E[1 * i1 + 16] = (C[2 * i2 + 16] + A[2 * i1 - 9]) - (((D[2 * i1 + 16] + ((63 + E[2 * i1 + 9]) + 56)) + ((B[1 * i2 - 15] - B[2 * i4 - 16] * B[2 * i1 + 16]) + (84 - ((56 + D[2 * i4 - 16]) + E[2 * i4 - 16])))) * (E[2 * i4 - 9] * E[2 * i1 + 16] + (A[2 * i4 - 16] - (E[2 * i2 - 15] - (E[1 * i4 - 16] - E[2 * i1 + 15])))) - ((B[2 * i1 + 16] * 84 + (84 - 56) * (D[2 * i4 - 15] + (63 - D[2 * i2 - 15]))) + (E[2 * i4 + 16] - B[2 * i4 - 9])));
      }
    }
  }
  for (int i1 = 49; i1 <= 106; i1+=1) {
    for (int i6 = 39; i6 <= 87; i6+=1) {
      for (int i3 = 33; i3 <= 80; i3+=1) {
          A[2 * i1 - 16] = (((56 + B[2 * i6 + 9]) * D[1 * i3 - 15] - B[1 * i6 - 9]) + ((E[2 * i3 - 9] + (((A[2 * i1 - 9] + (C[2 * i6 - 9] + 56)) + 84) + 63 * (A[2 * i1 + 15] + C[2 * i1 - 16]))) + D[1 * i1 + 15] * 84)) - ((56 * 63 + (56 - C[2 * i6 + 15])) + ((B[1 * i1 + 9] * ((E[2 * i3 - 15] * C[2 * i1 - 16]) * C[1 * i3 - 16])) * (56 - B[2 * i1 - 16]) + ((B[2 * i6 + 16] - C[2 * i6 - 16]) + (84 - A[1 * i1 - 16]))));
      }
    }
  }
  for (int i6 = 39; i6 <= 87; i6+=1) {
    for (int i2 = 47; i2 <= 92; i2+=1) {
      for (int i5 = 16; i5 <= 28; i5+=1) {
          E[2 * i5 + 9] = ((B[1 * i2 + 16] + (56 - (D[2 * i5 - 16] * E[2 * i5 - 9]) * C[2 * i6 - 16])) * (((A[2 * i6 - 16] + 84) - (84 + D[1 * i6 + 16])) - C[2 * i5 - 16])) * (((D[2 * i5 + 9] + (84 - D[2 * i6 + 15])) * (((63 + 56) + (((A[2 * i2 - 16] * 56) * E[1 * i6 + 9] + A[2 * i5 - 15]) + (63 - C[2 * i2 - 15]))) - ((E[2 * i2 - 15] - (84 + 56)) + A[2 * i2 - 16]))) * (A[2 * i6 - 15] - (E[2 * i6 + 16] - D[1 * i6 + 9])));
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

