#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 232], float B[restrict 227], float C[restrict 232], float D[restrict 234], float E[restrict 227]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 33; i1 <= 75; i1+=1) {
    for (int i2 = 83; i2 <= 116; i2+=1) {
      for (int i3 = 13; i3 <= 63; i3+=1) {
          A[2 * i3 - 8] = ((93 * B[1 * i3 + 1]) * (10 + A[1 * i2 + 8]) + (C[2 * i1 - 8] - 29 * D[2 * i1 + 8])) - (((((((C[1 * i3 - 8] + E[1 * i3 + 8]) + D[2 * i2 + 1]) - A[2 * i3 - 8] * 10) - (93 + E[2 * i1 + 8])) - (10 + 10)) - (29 - D[2 * i2 - 8] * 29) * ((29 - C[2 * i3 + 8]) * (10 * C[2 * i1 - 1]))) - ((D[2 * i3 - 8] + (B[2 * i3 - 8] - 93)) - (93 + A[2 * i3 - 8])));
      }
    }
  }
  for (int i4 = 84; i4 <= 109; i4+=1) {
    for (int i3 = 13; i3 <= 63; i3+=1) {
      for (int i2 = 83; i2 <= 116; i2+=1) {
          C[2 * i3 + 8] = (((C[2 * i4 - 1] * C[2 * i2 - 1] - A[2 * i2 - 1] * 29) - ((93 * D[2 * i4 - 1]) * A[2 * i4 - 8] - A[1 * i4 + 1])) + (10 + (29 + (C[2 * i3 + 8] * B[1 * i2 + 8] + ((E[2 * i4 - 8] - 93 * 29) + (A[1 * i4 + 8] + 10 * 93)))))) * (((E[2 * i4 - 1] - B[2 * i3 + 1]) * A[1 * i2 + 1]) * (((93 - 10) - (E[1 * i3 - 8] * E[2 * i2 - 8] - (A[1 * i4 - 1] - B[2 * i2 - 8]))) * E[2 * i3 - 8]));
      }
    }
  }
  for (int i1 = 33; i1 <= 75; i1+=1) {
    for (int i5 = 63; i5 <= 105; i5+=1) {
      for (int i4 = 84; i4 <= 109; i4+=1) {
          D[2 * i4 - 8] = (93 - ((E[1 * i1 - 8] - ((A[2 * i4 - 1] + B[2 * i1 - 8]) - 29)) - (A[1 * i4 + 1] - D[2 * i5 - 1]))) + ((10 * 29 - D[1 * i5 - 1]) - (E[1 * i5 - 8] * E[2 * i5 + 8] + (29 - (E[1 * i1 - 8] + A[1 * i4 - 8])))) * (((D[2 * i1 - 8] + 29) - (B[2 * i1 - 8] - E[2 * i5 + 8])) * D[1 * i5 + 8] + ((D[1 * i4 - 1] - (D[2 * i4 - 1] + ((93 + 29) - (29 + B[2 * i4 + 8])))) + C[2 * i4 - 1] * 10));
      }
    }
  }
  for (int i6 = 50; i6 <= 99; i6+=1) {
    for (int i3 = 13; i3 <= 63; i3+=1) {
      for (int i4 = 84; i4 <= 109; i4+=1) {
          D[2 * i6 - 8] = (29 * ((10 * (93 - D[1 * i3 - 1])) * (((10 - 93) + (D[1 * i3 + 1] - D[2 * i6 - 8])) - (C[1 * i6 + 1] + ((C[2 * i6 + 1] + B[2 * i3 - 1]) - 10)) * (B[1 * i3 - 1] * B[2 * i3 + 1])))) * ((D[2 * i3 + 8] * ((A[2 * i6 + 1] - A[2 * i3 - 8]) * E[2 * i3 + 8])) * 10) + (((B[1 * i4 - 8] * C[2 * i6 + 8] + (C[2 * i3 - 1] - C[1 * i6 - 8])) + (C[2 * i3 - 8] - (E[2 * i6 - 8] + B[2 * i3 + 8]))) - (29 + C[2 * i3 + 1]));
      }
    }
  }
  for (int i3 = 13; i3 <= 63; i3+=1) {
    for (int i1 = 33; i1 <= 75; i1+=1) {
      for (int i4 = 84; i4 <= 109; i4+=1) {
          C[1 * i4 + 8] = (10 * E[1 * i3 - 8] + (C[2 * i3 - 8] - (((C[2 * i3 - 8] - 10) - (B[2 * i4 + 8] - 93) * (C[2 * i4 + 8] * B[2 * i3 - 8])) - (B[2 * i1 + 8] - D[2 * i1 + 1]) * (93 + 93)))) * ((10 - D[2 * i4 + 1]) * (((E[1 * i3 - 8] + E[2 * i4 + 8]) + (((E[1 * i1 + 8] + D[1 * i1 + 8] * D[1 * i3 + 8]) - (10 + D[2 * i1 + 1] * C[2 * i4 - 8])) - D[1 * i1 + 1] * E[2 * i4 - 8])) * (A[1 * i4 + 8] - (D[1 * i1 + 1] - C[1 * i3 + 1]))));
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

