#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 215], float B[restrict 227], float C[restrict 205], float D[restrict 243], float E[restrict 225]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 24; i1 <= 107; i1+=1) {
    for (int i2 = 51; i2 <= 80; i2+=1) {
      for (int i3 = 41; i3 <= 106; i3+=1) {
          A[2 * i2 + 0] = (((B[1 * i2 + 10] + C[1 * i3 - 0]) + B[1 * i2 + 10] * (D[1 * i3 - 0] - E[1 * i3 + 0])) + (C[2 * i1 - 10] - 41)) * (E[1 * i1 + 0] + (E[2 * i1 + 0] + 6)) - (D[1 * i1 - 12] * (E[2 * i2 - 12] * E[1 * i2 - 10])) * (((43 + A[2 * i2 + 10]) * (E[1 * i3 - 10] - (((43 - 6) - 41) - (B[1 * i2 + 0] + ((C[1 * i1 - 10] - E[2 * i3 + 12]) + 41))))) * (6 * (43 - (B[1 * i1 + 0] - (D[1 * i2 + 0] - B[1 * i3 - 0])))));
      }
    }
  }
  for (int i4 = 58; i4 <= 76; i4+=1) {
    for (int i3 = 41; i3 <= 106; i3+=1) {
      for (int i5 = 28; i5 <= 116; i5+=1) {
          B[2 * i4 + 12] = (((E[1 * i4 - 0] * B[1 * i5 + 10]) * ((E[2 * i4 - 0] - A[1 * i4 + 10]) * 43) - (6 * 41 - B[1 * i4 + 10])) - (41 - D[2 * i4 + 12])) * ((41 + B[2 * i4 + 10]) * ((A[1 * i4 + 12] + (B[1 * i4 - 10] - 6)) * (((D[1 * i4 - 12] - 41) - E[1 * i3 + 12]) * ((43 * 41 - ((6 - B[1 * i5 + 12]) - C[1 * i5 - 10])) + (6 + A[2 * i3 - 0]) * ((41 + 6) + 6)))));
      }
    }
  }
  for (int i1 = 24; i1 <= 107; i1+=1) {
    for (int i4 = 58; i4 <= 76; i4+=1) {
      for (int i2 = 51; i2 <= 80; i2+=1) {
          E[1 * i1 + 12] = (C[1 * i2 + 12] + A[2 * i1 - 10]) - (((D[2 * i1 + 12] + ((6 + E[2 * i1 + 10]) + 43)) + ((B[1 * i2 - 0] - B[1 * i4 - 12] * B[2 * i1 + 12]) + (41 - ((43 + D[2 * i4 - 12]) + E[2 * i4 - 12])))) * (E[2 * i4 - 10] * E[1 * i1 + 12] + (A[1 * i4 - 12] - (E[2 * i2 - 0] - (E[1 * i4 - 12] - E[1 * i1 + 0])))) - ((B[2 * i1 + 12] * 41 + (41 - 43) * (D[2 * i4 - 0] + (6 - D[1 * i2 - 0]))) + (E[1 * i4 + 12] - B[2 * i4 - 10])));
      }
    }
  }
  for (int i1 = 24; i1 <= 107; i1+=1) {
    for (int i6 = 18; i6 <= 95; i6+=1) {
      for (int i3 = 41; i3 <= 106; i3+=1) {
          A[1 * i1 - 12] = (((43 + B[1 * i6 + 10]) * D[1 * i3 - 0] - B[1 * i6 - 10]) + ((E[2 * i3 - 10] + (((A[2 * i1 - 10] + (C[2 * i6 - 10] + 43)) + 41) + 6 * (A[2 * i1 + 0] + C[2 * i1 - 12]))) + D[1 * i1 + 0] * 41)) - ((43 * 6 + (43 - C[1 * i6 + 0])) + ((B[1 * i1 + 10] * ((E[1 * i3 - 0] * C[2 * i1 - 12]) * C[1 * i3 - 12])) * (43 - B[2 * i1 - 12]) + ((B[1 * i6 + 12] - C[2 * i6 - 12]) + (41 - A[1 * i1 - 12]))));
      }
    }
  }
  for (int i6 = 18; i6 <= 95; i6+=1) {
    for (int i2 = 51; i2 <= 80; i2+=1) {
      for (int i5 = 28; i5 <= 116; i5+=1) {
          E[1 * i5 + 10] = ((B[1 * i2 + 12] + (43 - (D[2 * i5 - 12] * E[2 * i5 - 10]) * C[2 * i6 - 12])) * (((A[1 * i6 - 12] + 41) - (41 + D[1 * i6 + 12])) - C[1 * i5 - 12])) * (((D[2 * i5 + 10] + (41 - D[1 * i6 + 0])) * (((6 + 43) + (((A[2 * i2 - 12] * 43) * E[1 * i6 + 10] + A[1 * i5 - 0]) + (6 - C[1 * i2 - 0]))) - ((E[2 * i2 - 0] - (41 + 43)) + A[1 * i2 - 12]))) * (A[2 * i6 - 0] - (E[2 * i6 + 12] - D[1 * i6 + 10])));
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

