#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 222], float B[restrict 222], float C[restrict 213], float D[restrict 217], float E[restrict 217]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 6; i1 <= 92; i1+=1) {
    for (int i2 = 19; i2 <= 73; i2+=1) {
      for (int i3 = 26; i3 <= 107; i3+=1) {
          A[2 * i2 + 12] = (((B[2 * i2 + 2] - 52) * (59 + (C[2 * i1 + 7] - 59)) + A[2 * i2 - 7]) - (((59 - D[2 * i1 - 7]) - B[2 * i1 - 7]) + (59 + D[2 * i2 + 12]))) - (((3 * 52 - (D[2 * i3 - 2] + A[2 * i1 - 12])) + ((59 * A[2 * i3 + 7] - A[2 * i1 + 2]) + D[2 * i3 - 7] * 52) * C[2 * i3 - 2]) - ((B[2 * i3 - 7] * D[2 * i1 - 2] + 52 * 59) - (52 + D[2 * i3 - 12] * B[2 * i1 + 2])));
      }
    }
  }
  for (int i3 = 26; i3 <= 107; i3+=1) {
    for (int i4 = 15; i4 <= 44; i4+=1) {
      for (int i2 = 19; i2 <= 73; i2+=1) {
          B[2 * i2 + 2] = ((((((D[2 * i4 - 7] + 52) + C[2 * i4 + 12]) - A[2 * i3 - 12]) - D[2 * i4 - 12]) + 59) - 52) * (((59 + (59 + (59 + C[2 * i4 + 12]))) + 52) + (((A[2 * i4 - 7] - 3) * ((D[2 * i4 - 2] * A[2 * i3 - 7]) * 59) - E[2 * i3 + 2]) + (D[2 * i3 - 2] + (59 - ((D[2 * i3 + 2] - 52) + A[2 * i3 - 7] * 59)) * (A[2 * i4 + 7] + 59)))) + (52 + E[2 * i2 + 2]);
      }
    }
  }
  for (int i4 = 15; i4 <= 44; i4+=1) {
    for (int i1 = 6; i1 <= 92; i1+=1) {
      for (int i5 = 40; i5 <= 100; i5+=1) {
          D[2 * i4 - 7] = (((B[2 * i5 - 12] - 3) * (C[2 * i5 - 12] - ((59 + A[2 * i5 - 2]) - C[2 * i4 - 12])) + (((D[2 * i5 - 2] - 59) - 3) - A[2 * i5 - 7])) - (D[2 * i1 - 12] - C[2 * i4 - 2])) + ((C[2 * i4 + 12] - ((3 + D[2 * i4 + 12]) + 52 * (E[2 * i4 + 7] + D[2 * i1 + 2] * 3))) - ((A[2 * i5 + 7] * D[2 * i5 - 7] - B[2 * i1 + 2]) - 3)) * ((D[2 * i5 - 2] + (C[2 * i1 - 7] - B[2 * i5 - 7])) - (C[2 * i4 - 7] - 52));
      }
    }
  }
  for (int i4 = 15; i4 <= 44; i4+=1) {
    for (int i1 = 6; i1 <= 92; i1+=1) {
      for (int i3 = 26; i3 <= 107; i3+=1) {
          E[2 * i3 + 2] = ((A[2 * i3 - 7] * (B[2 * i4 - 7] - 3)) * (((D[2 * i1 + 2] + (E[2 * i3 - 12] + 3)) + (59 * 3 + C[2 * i1 + 2])) + (59 * ((B[2 * i3 + 2] + E[2 * i3 - 2]) + E[2 * i1 + 7])) * ((52 + (3 - (D[2 * i4 + 2] * E[2 * i4 + 12] + 59))) - (((B[2 * i3 - 12] + D[2 * i4 - 2]) + 3) + 52)))) * ((E[2 * i3 + 2] - B[2 * i3 - 12]) + ((59 - E[2 * i1 + 7]) + 52 * E[2 * i3 - 12]));
      }
    }
  }
  for (int i5 = 40; i5 <= 100; i5+=1) {
    for (int i3 = 26; i3 <= 107; i3+=1) {
      for (int i6 = 59; i6 <= 92; i6+=1) {
          C[2 * i6 - 2] = ((C[2 * i6 + 7] * C[2 * i5 + 7] + ((B[2 * i5 + 2] * ((A[2 * i5 + 12] + B[2 * i3 + 7]) * D[2 * i6 - 2]) + D[2 * i5 - 12] * (52 + D[2 * i5 + 7])) + A[2 * i3 + 7])) - (B[2 * i3 + 2] * B[2 * i6 + 2] + 59)) + ((E[2 * i5 + 12] + B[2 * i6 - 2]) * ((E[2 * i3 - 12] - 52) * B[2 * i6 + 2] - (C[2 * i3 - 12] - 3))) * (59 * C[2 * i6 + 7] + ((B[2 * i5 + 2] - (D[2 * i3 - 12] + 59)) - (B[2 * i3 + 7] + (C[2 * i6 - 7] + B[2 * i3 + 2]))));
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

