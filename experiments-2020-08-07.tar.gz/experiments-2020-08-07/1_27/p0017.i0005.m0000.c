#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 229], float B[restrict 163], float C[restrict 249], float D[restrict 249], float E[restrict 249]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 9; i1 <= 119; i1+=1) {
    for (int i2 = 22; i2 <= 69; i2+=1) {
      for (int i3 = 13; i3 <= 33; i3+=1) {
          A[2 * i2 + 10] = ((((B[2 * i2 + 10] + C[2 * i3 - 10]) - C[2 * i2 - 5]) + C[2 * i2 + 10]) - B[2 * i2 - 5] * A[2 * i3 + 10]) * (((C[2 * i1 - 10] + 75) - (D[2 * i1 + 10] * E[2 * i3 - 10] + 94)) + (((A[2 * i2 - 5] + E[2 * i3 - 10]) + C[2 * i3 - 10]) * (A[2 * i2 - 10] * (A[2 * i1 - 10] * 94)) - (((E[2 * i1 - 5] + E[2 * i1 - 10]) * C[2 * i2 - 5] - ((E[2 * i1 - 10] - A[2 * i2 - 10]) + (B[2 * i2 + 5] - C[2 * i3 + 5]) * ((D[2 * i1 - 10] + C[2 * i1 + 10]) - C[2 * i1 - 10]))) + C[2 * i1 - 5])));
      }
    }
  }
  for (int i2 = 22; i2 <= 69; i2+=1) {
    for (int i4 = 31; i4 <= 55; i4+=1) {
      for (int i5 = 53; i5 <= 76; i5+=1) {
          D[2 * i4 + 10] = (C[2 * i5 - 5] + A[2 * i4 + 5]) + (((75 - (B[2 * i4 - 10] + E[2 * i4 + 10])) * ((C[2 * i4 + 5] - 83 * 83) * (75 + D[2 * i5 + 10])) - (83 * (E[2 * i5 + 5] - A[2 * i2 - 10])) * B[2 * i5 + 5]) - (((D[2 * i4 - 10] - 83 * A[2 * i5 - 5]) - (C[2 * i5 + 10] * E[2 * i2 + 10] + 94)) - B[2 * i4 + 5] * (94 * (75 * 94 - (A[2 * i5 + 10] + D[2 * i2 - 10])))) * (C[2 * i2 - 5] + 75));
      }
    }
  }
  for (int i4 = 31; i4 <= 55; i4+=1) {
    for (int i2 = 22; i2 <= 69; i2+=1) {
      for (int i5 = 53; i5 <= 76; i5+=1) {
          E[2 * i4 - 10] = ((((A[2 * i2 + 10] + (83 - E[2 * i4 - 10])) - C[2 * i5 + 10]) - 83 * 94) + ((D[2 * i4 - 10] - E[2 * i4 + 10]) * ((75 * C[2 * i5 - 10] + D[2 * i2 - 10]) + D[2 * i4 + 10] * ((B[2 * i4 + 10] - 94) + E[2 * i5 - 5])) + (C[2 * i2 - 10] - C[2 * i4 - 10]))) * ((C[2 * i5 - 10] - D[2 * i5 + 5]) + D[2 * i5 - 10]) - D[2 * i2 - 5] * (((E[2 * i4 - 10] + 83) + (D[2 * i4 + 5] - 83)) + C[2 * i2 + 10] * (83 + A[2 * i2 - 5]));
      }
    }
  }
  for (int i1 = 9; i1 <= 119; i1+=1) {
    for (int i4 = 31; i4 <= 55; i4+=1) {
      for (int i6 = 45; i6 <= 76; i6+=1) {
          E[2 * i1 + 10] = (E[2 * i1 + 5] + ((C[2 * i4 + 10] - (E[2 * i6 + 10] + 83 * E[2 * i1 - 5])) + ((E[2 * i1 - 10] + 94) + (C[2 * i4 + 10] + (C[2 * i1 - 5] - 75)) * (83 - E[2 * i4 - 5])))) * (((((D[2 * i1 - 10] + (94 - C[2 * i4 - 10])) + C[2 * i1 - 10]) - (83 + (D[2 * i1 + 5] - 75))) - C[2 * i1 + 5]) * ((E[2 * i1 + 10] * C[2 * i6 + 10] + ((83 + (B[2 * i4 - 10] + D[2 * i4 + 5])) + 75)) + 75 * D[2 * i6 - 10]));
      }
    }
  }
  for (int i5 = 53; i5 <= 76; i5+=1) {
    for (int i3 = 13; i3 <= 33; i3+=1) {
      for (int i2 = 22; i2 <= 69; i2+=1) {
          B[2 * i2 + 5] = (((((D[2 * i3 + 10] + D[2 * i5 + 10]) - 75) * A[2 * i5 + 10]) * ((E[2 * i5 + 10] - A[2 * i5 + 10]) + E[2 * i5 + 5] * D[2 * i3 + 5]) - C[2 * i2 - 10]) + (A[2 * i5 - 10] + ((((94 - B[2 * i2 + 5]) + 94 * 75) + (D[2 * i5 + 5] + (D[2 * i2 - 10] - B[2 * i5 + 10]))) + ((75 + C[2 * i2 - 5]) - 75)))) + (((E[2 * i3 - 5] * C[2 * i3 + 10]) * (E[2 * i3 + 5] + 75)) * (C[2 * i2 - 10] * B[2 * i5 + 10]) - (A[2 * i5 + 10] - 94));
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

