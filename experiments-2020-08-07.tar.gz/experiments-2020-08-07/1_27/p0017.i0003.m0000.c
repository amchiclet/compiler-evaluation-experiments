#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 228], float B[restrict 228], float C[restrict 228], float D[restrict 228], float E[restrict 225]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 11; i1 <= 151; i1+=1) {
    for (int i2 = 75; i2 <= 218; i2+=1) {
      for (int i3 = 142; i3 <= 217; i3+=1) {
          A[1 * i2 + 2] = ((((B[1 * i2 + 2] + C[1 * i3 - 2]) - C[1 * i2 - 7]) + C[1 * i2 + 3]) - B[1 * i2 - 7] * A[1 * i3 + 3]) * (((C[1 * i1 - 2] + 124) - (D[1 * i1 + 2] * E[1 * i3 - 2] + 34)) + (((A[1 * i2 - 7] + E[1 * i3 - 2]) + C[1 * i3 - 3]) * (A[1 * i2 - 3] * (A[1 * i1 - 2] * 34)) - (((E[1 * i1 - 7] + E[1 * i1 - 3]) * C[1 * i2 - 7] - ((E[1 * i1 - 3] - A[1 * i2 - 3]) + (B[1 * i2 + 7] - C[1 * i3 + 7]) * ((D[1 * i1 - 3] + C[1 * i1 + 2]) - C[1 * i1 - 3]))) + C[1 * i1 - 7])));
      }
    }
  }
  for (int i2 = 75; i2 <= 218; i2+=1) {
    for (int i4 = 91; i4 <= 220; i4+=1) {
      for (int i5 = 33; i5 <= 180; i5+=1) {
          D[1 * i4 + 3] = (C[1 * i5 - 7] + A[1 * i4 + 7]) + (((124 - (B[1 * i4 - 2] + E[1 * i4 + 3])) * ((C[1 * i4 + 7] - 99 * 99) * (124 + D[1 * i5 + 3])) - (99 * (E[1 * i5 + 7] - A[1 * i2 - 2])) * B[1 * i5 + 7]) - (((D[1 * i4 - 3] - 99 * A[1 * i5 - 7]) - (C[1 * i5 + 2] * E[1 * i2 + 2] + 34)) - B[1 * i4 + 7] * (34 * (124 * 34 - (A[1 * i5 + 3] + D[1 * i2 - 2])))) * (C[1 * i2 - 7] + 124));
      }
    }
  }
  for (int i4 = 91; i4 <= 220; i4+=1) {
    for (int i2 = 75; i2 <= 218; i2+=1) {
      for (int i5 = 33; i5 <= 180; i5+=1) {
          E[1 * i4 - 2] = ((((A[1 * i2 + 2] + (99 - E[1 * i4 - 2])) - C[1 * i5 + 3]) - 99 * 34) + ((D[1 * i4 - 2] - E[1 * i4 + 2]) * ((124 * C[1 * i5 - 3] + D[1 * i2 - 2]) + D[1 * i4 + 2] * ((B[1 * i4 + 2] - 34) + E[1 * i5 - 7])) + (C[1 * i2 - 3] - C[1 * i4 - 3]))) * ((C[1 * i5 - 3] - D[1 * i5 + 7]) + D[1 * i5 - 2]) - D[1 * i2 - 7] * (((E[1 * i4 - 2] + 99) + (D[1 * i4 + 7] - 99)) + C[1 * i2 + 2] * (99 + A[1 * i2 - 7]));
      }
    }
  }
  for (int i1 = 11; i1 <= 151; i1+=1) {
    for (int i4 = 91; i4 <= 220; i4+=1) {
      for (int i6 = 75; i6 <= 207; i6+=1) {
          E[1 * i1 + 3] = (E[1 * i1 + 7] + ((C[1 * i4 + 3] - (E[1 * i6 + 2] + 99 * E[1 * i1 - 7])) + ((E[1 * i1 - 3] + 34) + (C[1 * i4 + 3] + (C[1 * i1 - 7] - 124)) * (99 - E[1 * i4 - 7])))) * (((((D[1 * i1 - 3] + (34 - C[1 * i4 - 3])) + C[1 * i1 - 2]) - (99 + (D[1 * i1 + 7] - 124))) - C[1 * i1 + 7]) * ((E[1 * i1 + 3] * C[1 * i6 + 2] + ((99 + (B[1 * i4 - 2] + D[1 * i4 + 7])) + 124)) + 124 * D[1 * i6 - 3]));
      }
    }
  }
  for (int i5 = 33; i5 <= 180; i5+=1) {
    for (int i3 = 142; i3 <= 217; i3+=1) {
      for (int i2 = 75; i2 <= 218; i2+=1) {
          B[1 * i2 + 7] = (((((D[1 * i3 + 3] + D[1 * i5 + 3]) - 124) * A[1 * i5 + 3]) * ((E[1 * i5 + 3] - A[1 * i5 + 2]) + E[1 * i5 + 7] * D[1 * i3 + 7]) - C[1 * i2 - 2]) + (A[1 * i5 - 3] + ((((34 - B[1 * i2 + 7]) + 34 * 124) + (D[1 * i5 + 7] + (D[1 * i2 - 3] - B[1 * i5 + 2]))) + ((124 + C[1 * i2 - 7]) - 124)))) + (((E[1 * i3 - 7] * C[1 * i3 + 3]) * (E[1 * i3 + 7] + 124)) * (C[1 * i2 - 2] * B[1 * i5 + 3]) - (A[1 * i5 + 2] - 34));
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

