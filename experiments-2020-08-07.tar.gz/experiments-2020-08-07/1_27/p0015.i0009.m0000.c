#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 251], float B[restrict 256], float C[restrict 238], float D[restrict 251], float E[restrict 256]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 79; i1 <= 98; i1+=1) {
    for (int i2 = 64; i2 <= 124; i2+=1) {
      for (int i3 = 40; i3 <= 42; i3+=1) {
          A[2 * i2 + 2] = (((B[2 * i2 + 7] - 37) * (27 + (C[2 * i1 + 9] - 27)) + A[2 * i2 - 9]) - (((27 - D[2 * i1 - 9]) - B[2 * i1 - 9]) + (27 + D[2 * i2 + 2]))) - (((87 * 37 - (D[2 * i3 - 7] + A[2 * i1 - 2])) + ((27 * A[2 * i3 + 9] - A[2 * i1 + 7]) + D[2 * i3 - 9] * 37) * C[2 * i3 - 7]) - ((B[2 * i3 - 9] * D[2 * i1 - 7] + 37 * 27) - (37 + D[2 * i3 - 2] * B[2 * i1 + 7])));
      }
    }
  }
  for (int i3 = 40; i3 <= 42; i3+=1) {
    for (int i4 = 16; i4 <= 76; i4+=1) {
      for (int i2 = 64; i2 <= 124; i2+=1) {
          B[2 * i2 + 7] = ((((((D[2 * i4 - 9] + 37) + C[2 * i4 + 2]) - A[2 * i3 - 2]) - D[2 * i4 - 2]) + 27) - 37) * (((27 + (27 + (27 + C[2 * i4 + 2]))) + 37) + (((A[2 * i4 - 9] - 87) * ((D[2 * i4 - 7] * A[2 * i3 - 9]) * 27) - E[2 * i3 + 7]) + (D[2 * i3 - 7] + (27 - ((D[2 * i3 + 7] - 37) + A[2 * i3 - 9] * 27)) * (A[2 * i4 + 9] + 27)))) + (37 + E[2 * i2 + 7]);
      }
    }
  }
  for (int i4 = 16; i4 <= 76; i4+=1) {
    for (int i1 = 79; i1 <= 98; i1+=1) {
      for (int i5 = 76; i5 <= 114; i5+=1) {
          D[2 * i4 - 9] = (((B[2 * i5 - 2] - 87) * (C[2 * i5 - 2] - ((27 + A[2 * i5 - 7]) - C[2 * i4 - 2])) + (((D[2 * i5 - 7] - 27) - 87) - A[2 * i5 - 9])) - (D[2 * i1 - 2] - C[2 * i4 - 7])) + ((C[2 * i4 + 2] - ((87 + D[2 * i4 + 2]) + 37 * (E[2 * i4 + 9] + D[2 * i1 + 7] * 87))) - ((A[2 * i5 + 9] * D[2 * i5 - 9] - B[2 * i1 + 7]) - 87)) * ((D[2 * i5 - 7] + (C[2 * i1 - 9] - B[2 * i5 - 9])) - (C[2 * i4 - 9] - 37));
      }
    }
  }
  for (int i3 = 40; i3 <= 42; i3+=1) {
    for (int i4 = 16; i4 <= 76; i4+=1) {
      for (int i1 = 79; i1 <= 98; i1+=1) {
          E[2 * i3 + 7] = ((A[2 * i3 - 9] * (B[2 * i4 - 9] - 87)) * (((D[2 * i1 + 7] + (E[2 * i3 - 2] + 87)) + (27 * 87 + C[2 * i1 + 7])) + (27 * ((B[2 * i3 + 7] + E[2 * i3 - 7]) + E[2 * i1 + 9])) * ((37 + (87 - (D[2 * i4 + 7] * E[2 * i4 + 2] + 27))) - (((B[2 * i3 - 2] + D[2 * i4 - 7]) + 87) + 37)))) * ((E[2 * i3 + 7] - B[2 * i3 - 2]) + ((27 - E[2 * i1 + 9]) + 37 * E[2 * i3 - 2]));
      }
    }
  }
  for (int i5 = 76; i5 <= 114; i5+=1) {
    for (int i3 = 40; i3 <= 42; i3+=1) {
      for (int i6 = 15; i6 <= 65; i6+=1) {
          C[2 * i6 - 7] = ((C[2 * i6 + 9] * C[2 * i5 + 9] + ((B[2 * i5 + 7] * ((A[2 * i5 + 2] + B[2 * i3 + 9]) * D[2 * i6 - 7]) + D[2 * i5 - 2] * (37 + D[2 * i5 + 9])) + A[2 * i3 + 9])) - (B[2 * i3 + 7] * B[2 * i6 + 7] + 27)) + ((E[2 * i5 + 2] + B[2 * i6 - 7]) * ((E[2 * i3 - 2] - 37) * B[2 * i6 + 7] - (C[2 * i3 - 2] - 87))) * (27 * C[2 * i6 + 9] + ((B[2 * i5 + 7] - (D[2 * i3 - 2] + 27)) - (B[2 * i3 + 9] + (C[2 * i6 - 9] + B[2 * i3 + 7]))));
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

