#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 229], float B[restrict 243], float C[restrict 235], float D[restrict 249], float E[restrict 249]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 25; i1 <= 116; i1+=1) {
    for (int i2 = 30; i2 <= 91; i2+=1) {
      for (int i3 = 21; i3 <= 119; i3+=1) {
          A[2 * i3 - 10] = ((20 * B[1 * i3 + 4]) * (110 + A[1 * i2 + 16]) + (C[1 * i1 - 16] - 118 * D[1 * i1 + 16])) - (((((((C[1 * i3 - 16] + E[1 * i3 + 16]) + D[1 * i2 + 4]) - A[2 * i3 - 16] * 110) - (20 + E[2 * i1 + 10])) - (110 + 110)) - (118 - D[1 * i2 - 10] * 118) * ((118 - C[1 * i3 + 16]) * (110 * C[2 * i1 - 4]))) - ((D[1 * i3 - 10] + (B[1 * i3 - 10] - 20)) - (20 + A[1 * i3 - 10])));
      }
    }
  }
  for (int i4 = 17; i4 <= 82; i4+=1) {
    for (int i2 = 30; i2 <= 91; i2+=1) {
      for (int i3 = 21; i3 <= 119; i3+=1) {
          C[1 * i3 + 16] = (((C[2 * i4 - 4] * C[1 * i2 - 4] - A[1 * i2 - 4] * 118) - ((20 * D[1 * i4 - 4]) * A[1 * i4 - 10] - A[1 * i4 + 4])) + (110 + (118 + (C[1 * i3 + 16] * B[1 * i2 + 10] + ((E[2 * i4 - 10] - 20 * 118) + (A[1 * i4 + 16] + 110 * 20)))))) * (((E[1 * i4 - 4] - B[1 * i3 + 4]) * A[1 * i2 + 4]) * (((20 - 110) - (E[1 * i3 - 16] * E[2 * i2 - 10] - (A[1 * i4 - 4] - B[1 * i2 - 16]))) * E[1 * i3 - 10]));
      }
    }
  }
  for (int i1 = 25; i1 <= 116; i1+=1) {
    for (int i5 = 59; i5 <= 61; i5+=1) {
      for (int i4 = 17; i4 <= 82; i4+=1) {
          D[1 * i4 - 10] = (20 - ((E[1 * i1 - 16] - ((A[1 * i4 - 4] + B[2 * i1 - 10]) - 118)) - (A[1 * i4 + 4] - D[2 * i5 - 4]))) + ((110 * 118 - D[1 * i5 - 4]) - (E[1 * i5 - 16] * E[2 * i5 + 16] + (118 - (E[1 * i1 - 10] + A[1 * i4 - 16])))) * (((D[1 * i1 - 10] + 118) - (B[1 * i1 - 10] - E[1 * i5 + 16])) * D[1 * i5 + 10] + ((D[1 * i4 - 4] - (D[2 * i4 - 4] + ((20 + 118) - (118 + B[1 * i4 + 10])))) + C[2 * i4 - 4] * 110));
      }
    }
  }
  for (int i6 = 30; i6 <= 46; i6+=1) {
    for (int i3 = 21; i3 <= 119; i3+=1) {
      for (int i4 = 17; i4 <= 82; i4+=1) {
          D[2 * i6 - 10] = (118 * ((110 * (20 - D[1 * i3 - 4])) * (((110 - 20) + (D[1 * i3 + 4] - D[2 * i6 - 16])) - (C[1 * i6 + 4] + ((C[1 * i6 + 4] + B[1 * i3 - 4]) - 110)) * (B[1 * i3 - 4] * B[2 * i3 + 4])))) * ((D[2 * i3 + 10] * ((A[1 * i6 + 4] - A[2 * i3 - 16]) * E[2 * i3 + 10])) * 110) + (((B[1 * i4 - 10] * C[2 * i6 + 10] + (C[2 * i3 - 4] - C[1 * i6 - 10])) + (C[2 * i3 - 10] - (E[1 * i6 - 10] + B[1 * i3 + 10]))) - (118 + C[1 * i3 + 4]));
      }
    }
  }
  for (int i3 = 21; i3 <= 119; i3+=1) {
    for (int i1 = 25; i1 <= 116; i1+=1) {
      for (int i4 = 17; i4 <= 82; i4+=1) {
          C[1 * i4 + 10] = (110 * E[1 * i3 - 16] + (C[2 * i3 - 16] - (((C[2 * i3 - 10] - 110) - (B[1 * i4 + 10] - 20) * (C[1 * i4 + 16] * B[1 * i3 - 10])) - (B[1 * i1 + 16] - D[2 * i1 + 4]) * (20 + 20)))) * ((110 - D[1 * i4 + 4]) * (((E[1 * i3 - 16] + E[1 * i4 + 10]) + (((E[1 * i1 + 16] + D[1 * i1 + 16] * D[1 * i3 + 10]) - (110 + D[1 * i1 + 4] * C[2 * i4 - 16])) - D[1 * i1 + 4] * E[1 * i4 - 10])) * (A[1 * i4 + 16] - (D[1 * i1 + 4] - C[1 * i3 + 4]))));
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

