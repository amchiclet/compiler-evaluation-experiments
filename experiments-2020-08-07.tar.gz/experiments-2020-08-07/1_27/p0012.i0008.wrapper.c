#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 236], float B[restrict 230], float C[restrict 216], float D[restrict 236], float E[restrict 216]);

struct Data {
  float (*A)[236];
  float (*B)[230];
  float (*C)[216];
  float (*D)[236];
  float (*E)[216];
};

float frand(float min, float max) {
  float scale = rand() / (float) RAND_MAX;
  return min + scale * (max - min);
}

float irand(int min, int max) {
  return min + (rand() % (max - min));
}

void *allocate() {
  struct Data *data = malloc(sizeof(struct Data));
  data->A = malloc(sizeof(float) * 236);
  data->B = malloc(sizeof(float) * 230);
  data->C = malloc(sizeof(float) * 216);
  data->D = malloc(sizeof(float) * 236);
  data->E = malloc(sizeof(float) * 216);
  return (void*)data;
}

int init_inner(float A[restrict 236], float B[restrict 230], float C[restrict 216], float D[restrict 236], float E[restrict 216]) {
  allocate();
  for (int i0 = 0; i0 <= 235; ++i0) {
    float v = frand(0.0, 1.0);
    A[i0] = v;
  }
  for (int i0 = 0; i0 <= 229; ++i0) {
    float v = frand(0.0, 1.0);
    B[i0] = v;
  }
  for (int i0 = 0; i0 <= 215; ++i0) {
    float v = frand(0.0, 1.0);
    C[i0] = v;
  }
  for (int i0 = 0; i0 <= 235; ++i0) {
    float v = frand(0.0, 1.0);
    D[i0] = v;
  }
  for (int i0 = 0; i0 <= 215; ++i0) {
    float v = frand(0.0, 1.0);
    E[i0] = v;
  }
  return 0;
}

float checksum_inner(float A[restrict 236], float B[restrict 230], float C[restrict 216], float D[restrict 236], float E[restrict 216]) {
  float total = 0.0;
  for (int i0 = 0; i0 <= 235; ++i0) {
    if (isnormal(A[i0])) { total += A[i0]; }
    else { total += 0.1; }
  }
  for (int i0 = 0; i0 <= 229; ++i0) {
    if (isnormal(B[i0])) { total += B[i0]; }
    else { total += 0.1; }
  }
  for (int i0 = 0; i0 <= 215; ++i0) {
    if (isnormal(C[i0])) { total += C[i0]; }
    else { total += 0.1; }
  }
  for (int i0 = 0; i0 <= 235; ++i0) {
    if (isnormal(D[i0])) { total += D[i0]; }
    else { total += 0.1; }
  }
  for (int i0 = 0; i0 <= 215; ++i0) {
    if (isnormal(E[i0])) { total += E[i0]; }
    else { total += 0.1; }
  }
  return total;
}

int init(void *void_ptr) {
  struct Data *data = (struct Data*)void_ptr;
  return init_inner(*data->A, *data->B, *data->C, *data->D, *data->E);
};

float checksum(void *void_ptr) {
  struct Data *data = (struct Data*)void_ptr;
  return checksum_inner(*data->A, *data->B, *data->C, *data->D, *data->E);
};

unsigned long long kernel(void *void_ptr) {
  struct Data *data = (struct Data*)void_ptr;
  return core(*data->A, *data->B, *data->C, *data->D, *data->E);
};

