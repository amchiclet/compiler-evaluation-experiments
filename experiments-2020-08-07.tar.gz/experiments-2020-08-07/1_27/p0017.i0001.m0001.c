#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 231], float B[restrict 231], float C[restrict 231], float D[restrict 231], float E[restrict 229]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 74; i1 <= 216; i1+=1) {
    for (int i2 = 52; i2 <= 186; i2+=1) {
      for (int i3 = 118; i3 <= 219; i3+=1) {
          A[1 * i2 + 4] = ((((B[1 * i2 + 4] + C[1 * i3 - 4]) - C[1 * i2 - 6]) + C[1 * i2 + 4]) - B[1 * i2 - 6] * A[1 * i3 + 4]) * (((C[1 * i1 - 4] + 61) - (D[1 * i1 + 4] * E[1 * i3 - 4] + 37)) + (((A[1 * i2 - 6] + E[1 * i3 - 4]) + C[1 * i3 - 4]) * (A[1 * i2 - 4] * (A[1 * i1 - 4] * 37)) - (((E[1 * i1 - 6] + E[1 * i1 - 4]) * C[1 * i2 - 6] - ((E[1 * i1 - 4] - A[1 * i2 - 4]) + (B[1 * i2 + 6] - C[1 * i3 + 6]) * ((D[1 * i1 - 4] + C[1 * i1 + 4]) - C[1 * i1 - 4]))) + C[1 * i1 - 6])));
      }
    }
  }
  for (int i2 = 52; i2 <= 186; i2+=1) {
    for (int i4 = 138; i4 <= 224; i4+=1) {
      for (int i5 = 15; i5 <= 27; i5+=1) {
          D[1 * i4 + 4] = (C[1 * i5 - 6] + A[1 * i4 + 6]) + (((61 - (B[1 * i4 - 4] + E[1 * i4 + 4])) * ((C[1 * i4 + 6] - 98 * 98) * (61 + D[1 * i5 + 4])) - (98 * (E[1 * i5 + 6] - A[1 * i2 - 4])) * B[1 * i5 + 6]) - (((D[1 * i4 - 4] - 98 * A[1 * i5 - 6]) - (C[1 * i5 + 4] * E[1 * i2 + 4] + 37)) - B[1 * i4 + 6] * (37 * (61 * 37 - (A[1 * i5 + 4] + D[1 * i2 - 4])))) * (C[1 * i2 - 6] + 61));
      }
    }
  }
  for (int i4 = 138; i4 <= 224; i4+=1) {
    for (int i2 = 52; i2 <= 186; i2+=1) {
      for (int i5 = 15; i5 <= 27; i5+=1) {
          E[1 * i4 - 4] = ((((A[1 * i2 + 4] + (98 - E[1 * i4 - 4])) - C[1 * i5 + 4]) - 98 * 37) + ((D[1 * i4 - 4] - E[1 * i4 + 4]) * ((61 * C[1 * i5 - 4] + D[1 * i2 - 4]) + D[1 * i4 + 4] * ((B[1 * i4 + 4] - 37) + E[1 * i5 - 6])) + (C[1 * i2 - 4] - C[1 * i4 - 4]))) * ((C[1 * i5 - 4] - D[1 * i5 + 6]) + D[1 * i5 - 4]) - D[1 * i2 - 6] * (((E[1 * i4 - 4] + 98) + (D[1 * i4 + 6] - 98)) + C[1 * i2 + 4] * (98 + A[1 * i2 - 6]));
      }
    }
  }
  for (int i1 = 74; i1 <= 216; i1+=1) {
    for (int i4 = 138; i4 <= 224; i4+=1) {
      for (int i6 = 107; i6 <= 126; i6+=1) {
          E[1 * i1 + 4] = (E[1 * i1 + 6] + ((C[1 * i4 + 4] - (E[1 * i6 + 4] + 98 * E[1 * i1 - 6])) + ((E[1 * i1 - 4] + 37) + (C[1 * i4 + 4] + (C[1 * i1 - 6] - 61)) * (98 - E[1 * i4 - 6])))) * (((((D[1 * i1 - 4] + (37 - C[1 * i4 - 4])) + C[1 * i1 - 4]) - (98 + (D[1 * i1 + 6] - 61))) - C[1 * i1 + 6]) * ((E[1 * i1 + 4] * C[1 * i6 + 4] + ((98 + (B[1 * i4 - 4] + D[1 * i4 + 6])) + 61)) + 61 * D[1 * i6 - 4]));
      }
    }
  }
  for (int i5 = 15; i5 <= 27; i5+=1) {
    for (int i2 = 52; i2 <= 186; i2+=1) {
      for (int i3 = 118; i3 <= 219; i3+=1) {
          B[1 * i2 + 6] = (((((D[1 * i3 + 4] + D[1 * i5 + 4]) - 61) * A[1 * i5 + 4]) * ((E[1 * i5 + 4] - A[1 * i5 + 4]) + E[1 * i5 + 6] * D[1 * i3 + 6]) - C[1 * i2 - 4]) + (A[1 * i5 - 4] + ((((37 - B[1 * i2 + 6]) + 37 * 61) + (D[1 * i5 + 6] + (D[1 * i2 - 4] - B[1 * i5 + 4]))) + ((61 + C[1 * i2 - 6]) - 61)))) + (((E[1 * i3 - 6] * C[1 * i3 + 4]) * (E[1 * i3 + 6] + 61)) * (C[1 * i2 - 4] * B[1 * i5 + 4]) - (A[1 * i5 + 4] - 37));
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

