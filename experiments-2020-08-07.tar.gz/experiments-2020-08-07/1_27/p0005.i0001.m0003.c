#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 225], float B[restrict 228], float C[restrict 239], float D[restrict 229], float E[restrict 228]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 61; i1 <= 75; i1+=1) {
    for (int i3 = 82; i3 <= 111; i3+=1) {
      for (int i2 = 50; i2 <= 113; i2+=1) {
          A[2 * i3 - 5] = ((9 * B[1 * i3 + 2]) * (117 + A[1 * i2 + 16]) + (C[2 * i1 - 16] - 128 * D[2 * i1 + 16])) - (((((((C[1 * i3 - 16] + E[1 * i3 + 16]) + D[2 * i2 + 2]) - A[2 * i3 - 16] * 117) - (9 + E[2 * i1 + 5])) - (117 + 117)) - (128 - D[2 * i2 - 5] * 128) * ((128 - C[2 * i3 + 16]) * (117 * C[2 * i1 - 2]))) - ((D[2 * i3 - 5] + (B[2 * i3 - 5] - 9)) - (9 + A[2 * i3 - 5])));
      }
    }
  }
  for (int i4 = 69; i4 <= 100; i4+=1) {
    for (int i2 = 50; i2 <= 113; i2+=1) {
      for (int i3 = 82; i3 <= 111; i3+=1) {
          C[2 * i3 + 16] = (((C[2 * i4 - 2] * C[2 * i2 - 2] - A[2 * i2 - 2] * 128) - ((9 * D[2 * i4 - 2]) * A[2 * i4 - 5] - A[1 * i4 + 2])) + (117 + (128 + (C[2 * i3 + 16] * B[1 * i2 + 5] + ((E[2 * i4 - 5] - 9 * 128) + (A[1 * i4 + 16] + 117 * 9)))))) * (((E[2 * i4 - 2] - B[2 * i3 + 2]) * A[1 * i2 + 2]) * (((9 - 117) - (E[1 * i3 - 16] * E[2 * i2 - 5] - (A[1 * i4 - 2] - B[2 * i2 - 16]))) * E[2 * i3 - 5]));
      }
    }
  }
  for (int i1 = 61; i1 <= 75; i1+=1) {
    for (int i5 = 60; i5 <= 70; i5+=1) {
      for (int i4 = 69; i4 <= 100; i4+=1) {
          D[2 * i4 - 5] = (9 - ((E[1 * i1 - 16] - ((A[2 * i4 - 2] + B[2 * i1 - 5]) - 128)) - (A[1 * i4 + 2] - D[2 * i5 - 2]))) + ((117 * 128 - D[1 * i5 - 2]) - (E[1 * i5 - 16] * E[2 * i5 + 16] + (128 - (E[1 * i1 - 5] + A[1 * i4 - 16])))) * (((D[2 * i1 - 5] + 128) - (B[2 * i1 - 5] - E[2 * i5 + 16])) * D[1 * i5 + 5] + ((D[1 * i4 - 2] - (D[2 * i4 - 2] + ((9 + 128) - (128 + B[2 * i4 + 5])))) + C[2 * i4 - 2] * 117));
      }
    }
  }
  for (int i3 = 82; i3 <= 111; i3+=1) {
    for (int i6 = 63; i6 <= 66; i6+=1) {
      for (int i4 = 69; i4 <= 100; i4+=1) {
          D[2 * i6 - 5] = (128 * ((117 * (9 - D[1 * i3 - 2])) * (((117 - 9) + (D[1 * i3 + 2] - D[2 * i6 - 16])) - (C[1 * i6 + 2] + ((C[2 * i6 + 2] + B[2 * i3 - 2]) - 117)) * (B[1 * i3 - 2] * B[2 * i3 + 2])))) * ((D[2 * i3 + 5] * ((A[2 * i6 + 2] - A[2 * i3 - 16]) * E[2 * i3 + 5])) * 117) + (((B[1 * i4 - 5] * C[2 * i6 + 5] + (C[2 * i3 - 2] - C[1 * i6 - 5])) + (C[2 * i3 - 5] - (E[2 * i6 - 5] + B[2 * i3 + 5]))) - (128 + C[2 * i3 + 2]));
      }
    }
  }
  for (int i3 = 82; i3 <= 111; i3+=1) {
    for (int i1 = 61; i1 <= 75; i1+=1) {
      for (int i4 = 69; i4 <= 100; i4+=1) {
          C[1 * i4 + 5] = (117 * E[1 * i3 - 16] + (C[2 * i3 - 16] - (((C[2 * i3 - 5] - 117) - (B[2 * i4 + 5] - 9) * (C[2 * i4 + 16] * B[2 * i3 - 5])) - (B[2 * i1 + 16] - D[2 * i1 + 2]) * (9 + 9)))) * ((117 - D[2 * i4 + 2]) * (((E[1 * i3 - 16] + E[2 * i4 + 5]) + (((E[1 * i1 + 16] + D[1 * i1 + 16] * D[1 * i3 + 5]) - (117 + D[2 * i1 + 2] * C[2 * i4 - 16])) - D[1 * i1 + 2] * E[2 * i4 - 5])) * (A[1 * i4 + 16] - (D[1 * i1 + 2] - C[1 * i3 + 2]))));
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

