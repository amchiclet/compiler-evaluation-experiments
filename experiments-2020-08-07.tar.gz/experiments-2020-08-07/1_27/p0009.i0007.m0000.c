#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 229], float B[restrict 235], float C[restrict 205], float D[restrict 233], float E[restrict 235]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 140; i1 <= 218; i1+=1) {
    for (int i2 = 172; i2 <= 190; i2+=1) {
      for (int i3 = 56; i3 <= 157; i3+=1) {
          A[1 * i2 + 10] = (((B[1 * i2 + 16] + C[1 * i3 - 10]) + B[1 * i2 + 16] * (D[1 * i3 - 10] - E[1 * i3 + 10])) + (C[1 * i1 - 16] - 112)) * (E[1 * i1 + 10] + (E[1 * i1 + 10] + 121)) - (D[1 * i1 - 14] * (E[1 * i2 - 14] * E[1 * i2 - 16])) * (((49 + A[1 * i2 + 16]) * (E[1 * i3 - 16] - (((49 - 121) - 112) - (B[1 * i2 + 10] + ((C[1 * i1 - 16] - E[1 * i3 + 14]) + 112))))) * (121 * (49 - (B[1 * i1 + 10] - (D[1 * i2 + 10] - B[1 * i3 - 10])))));
      }
    }
  }
  for (int i4 = 18; i4 <= 159; i4+=1) {
    for (int i3 = 56; i3 <= 157; i3+=1) {
      for (int i5 = 104; i5 <= 159; i5+=1) {
          B[1 * i4 + 14] = (((E[1 * i4 - 10] * B[1 * i5 + 16]) * ((E[1 * i4 - 10] - A[1 * i4 + 16]) * 49) - (121 * 112 - B[1 * i4 + 16])) - (112 - D[1 * i4 + 14])) * ((112 + B[1 * i4 + 16]) * ((A[1 * i4 + 14] + (B[1 * i4 - 16] - 121)) * (((D[1 * i4 - 14] - 112) - E[1 * i3 + 14]) * ((49 * 112 - ((121 - B[1 * i5 + 14]) - C[1 * i5 - 16])) + (121 + A[1 * i3 - 10]) * ((112 + 121) + 121)))));
      }
    }
  }
  for (int i1 = 140; i1 <= 218; i1+=1) {
    for (int i4 = 18; i4 <= 159; i4+=1) {
      for (int i2 = 172; i2 <= 190; i2+=1) {
          E[1 * i1 + 14] = (C[1 * i2 + 14] + A[1 * i1 - 16]) - (((D[1 * i1 + 14] + ((121 + E[1 * i1 + 16]) + 49)) + ((B[1 * i2 - 10] - B[1 * i4 - 14] * B[1 * i1 + 14]) + (112 - ((49 + D[1 * i4 - 14]) + E[1 * i4 - 14])))) * (E[1 * i4 - 16] * E[1 * i1 + 14] + (A[1 * i4 - 14] - (E[1 * i2 - 10] - (E[1 * i4 - 14] - E[1 * i1 + 10])))) - ((B[1 * i1 + 14] * 112 + (112 - 49) * (D[1 * i4 - 10] + (121 - D[1 * i2 - 10]))) + (E[1 * i4 + 14] - B[1 * i4 - 16])));
      }
    }
  }
  for (int i1 = 140; i1 <= 218; i1+=1) {
    for (int i6 = 31; i6 <= 91; i6+=1) {
      for (int i3 = 56; i3 <= 157; i3+=1) {
          A[1 * i1 - 14] = (((49 + B[1 * i6 + 16]) * D[1 * i3 - 10] - B[1 * i6 - 16]) + ((E[1 * i3 - 16] + (((A[1 * i1 - 16] + (C[1 * i6 - 16] + 49)) + 112) + 121 * (A[1 * i1 + 10] + C[1 * i1 - 14]))) + D[1 * i1 + 10] * 112)) - ((49 * 121 + (49 - C[1 * i6 + 10])) + ((B[1 * i1 + 16] * ((E[1 * i3 - 10] * C[1 * i1 - 14]) * C[1 * i3 - 14])) * (49 - B[1 * i1 - 14]) + ((B[1 * i6 + 14] - C[1 * i6 - 14]) + (112 - A[1 * i1 - 14]))));
      }
    }
  }
  for (int i6 = 31; i6 <= 91; i6+=1) {
    for (int i2 = 172; i2 <= 190; i2+=1) {
      for (int i5 = 104; i5 <= 159; i5+=1) {
          E[1 * i5 + 16] = ((B[1 * i2 + 14] + (49 - (D[1 * i5 - 14] * E[1 * i5 - 16]) * C[1 * i6 - 14])) * (((A[1 * i6 - 14] + 112) - (112 + D[1 * i6 + 14])) - C[1 * i5 - 14])) * (((D[1 * i5 + 16] + (112 - D[1 * i6 + 10])) * (((121 + 49) + (((A[1 * i2 - 14] * 49) * E[1 * i6 + 16] + A[1 * i5 - 10]) + (121 - C[1 * i2 - 10]))) - ((E[1 * i2 - 10] - (112 + 49)) + A[1 * i2 - 14]))) * (A[1 * i6 - 10] - (E[1 * i6 + 14] - D[1 * i6 + 16])));
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

