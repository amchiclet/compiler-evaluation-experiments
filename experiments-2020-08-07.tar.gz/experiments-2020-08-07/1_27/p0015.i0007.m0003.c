#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 252], float B[restrict 252], float C[restrict 248], float D[restrict 252], float E[restrict 252]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 16; i1 <= 120; i1+=1) {
    for (int i2 = 65; i2 <= 123; i2+=1) {
      for (int i3 = 94; i3 <= 108; i3+=1) {
          A[2 * i2 + 5] = (((B[2 * i2 + 5] - 103) * (52 + (C[2 * i1 + 7] - 52)) + A[2 * i2 - 7]) - (((52 - D[2 * i1 - 7]) - B[2 * i1 - 7]) + (52 + D[2 * i2 + 5]))) - (((127 * 103 - (D[2 * i3 - 5] + A[2 * i1 - 5])) + ((52 * A[2 * i3 + 7] - A[2 * i1 + 5]) + D[2 * i3 - 7] * 103) * C[2 * i3 - 5]) - ((B[2 * i3 - 7] * D[2 * i1 - 5] + 103 * 52) - (103 + D[2 * i3 - 5] * B[2 * i1 + 5])));
      }
    }
  }
  for (int i2 = 65; i2 <= 123; i2+=1) {
    for (int i3 = 94; i3 <= 108; i3+=1) {
      for (int i4 = 23; i4 <= 49; i4+=1) {
          B[2 * i2 + 5] = ((((((D[2 * i4 - 7] + 103) + C[2 * i4 + 5]) - A[2 * i3 - 5]) - D[2 * i4 - 5]) + 52) - 103) * (((52 + (52 + (52 + C[2 * i4 + 5]))) + 103) + (((A[2 * i4 - 7] - 127) * ((D[2 * i4 - 5] * A[2 * i3 - 7]) * 52) - E[2 * i3 + 5]) + (D[2 * i3 - 5] + (52 - ((D[2 * i3 + 5] - 103) + A[2 * i3 - 7] * 52)) * (A[2 * i4 + 7] + 52)))) + (103 + E[2 * i2 + 5]);
      }
    }
  }
  for (int i4 = 23; i4 <= 49; i4+=1) {
    for (int i1 = 16; i1 <= 120; i1+=1) {
      for (int i5 = 22; i5 <= 26; i5+=1) {
          D[2 * i4 - 7] = (((B[2 * i5 - 5] - 127) * (C[2 * i5 - 5] - ((52 + A[2 * i5 - 5]) - C[2 * i4 - 5])) + (((D[2 * i5 - 5] - 52) - 127) - A[2 * i5 - 7])) - (D[2 * i1 - 5] - C[2 * i4 - 5])) + ((C[2 * i4 + 5] - ((127 + D[2 * i4 + 5]) + 103 * (E[2 * i4 + 7] + D[2 * i1 + 5] * 127))) - ((A[2 * i5 + 7] * D[2 * i5 - 7] - B[2 * i1 + 5]) - 127)) * ((D[2 * i5 - 5] + (C[2 * i1 - 7] - B[2 * i5 - 7])) - (C[2 * i4 - 7] - 103));
      }
    }
  }
  for (int i4 = 23; i4 <= 49; i4+=1) {
    for (int i1 = 16; i1 <= 120; i1+=1) {
      for (int i3 = 94; i3 <= 108; i3+=1) {
          E[2 * i3 + 5] = ((A[2 * i3 - 7] * (B[2 * i4 - 7] - 127)) * (((D[2 * i1 + 5] + (E[2 * i3 - 5] + 127)) + (52 * 127 + C[2 * i1 + 5])) + (52 * ((B[2 * i3 + 5] + E[2 * i3 - 5]) + E[2 * i1 + 7])) * ((103 + (127 - (D[2 * i4 + 5] * E[2 * i4 + 5] + 52))) - (((B[2 * i3 - 5] + D[2 * i4 - 5]) + 127) + 103)))) * ((E[2 * i3 + 5] - B[2 * i3 - 5]) + ((52 - E[2 * i1 + 7]) + 103 * E[2 * i3 - 5]));
      }
    }
  }
  for (int i5 = 22; i5 <= 26; i5+=1) {
    for (int i3 = 94; i3 <= 108; i3+=1) {
      for (int i6 = 52; i6 <= 62; i6+=1) {
          C[2 * i6 - 5] = ((C[2 * i6 + 7] * C[2 * i5 + 7] + ((B[2 * i5 + 5] * ((A[2 * i5 + 5] + B[2 * i3 + 7]) * D[2 * i6 - 5]) + D[2 * i5 - 5] * (103 + D[2 * i5 + 7])) + A[2 * i3 + 7])) - (B[2 * i3 + 5] * B[2 * i6 + 5] + 52)) + ((E[2 * i5 + 5] + B[2 * i6 - 5]) * ((E[2 * i3 - 5] - 103) * B[2 * i6 + 5] - (C[2 * i3 - 5] - 127))) * (52 * C[2 * i6 + 7] + ((B[2 * i5 + 5] - (D[2 * i3 - 5] + 52)) - (B[2 * i3 + 7] + (C[2 * i6 - 7] + B[2 * i3 + 5]))));
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

