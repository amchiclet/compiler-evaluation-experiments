#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 226], float B[restrict 230], float C[restrict 222], float D[restrict 230], float E[restrict 240]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 105; i1 <= 110; i1+=1) {
    for (int i2 = 67; i2 <= 105; i2+=1) {
      for (int i3 = 53; i3 <= 91; i3+=1) {
          A[2 * i2 + 5] = (((B[1 * i2 + 14] + C[1 * i3 - 5]) + B[1 * i2 + 14] * (D[1 * i3 - 5] - E[1 * i3 + 5])) + (C[2 * i1 - 14] - 57)) * (E[1 * i1 + 5] + (E[2 * i1 + 5] + 84)) - (D[1 * i1 - 9] * (E[2 * i2 - 9] * E[1 * i2 - 14])) * (((105 + A[2 * i2 + 14]) * (E[1 * i3 - 14] - (((105 - 84) - 57) - (B[1 * i2 + 5] + ((C[1 * i1 - 14] - E[2 * i3 + 9]) + 57))))) * (84 * (105 - (B[1 * i1 + 5] - (D[1 * i2 + 5] - B[1 * i3 - 5])))));
      }
    }
  }
  for (int i3 = 53; i3 <= 91; i3+=1) {
    for (int i5 = 85; i5 <= 102; i5+=1) {
      for (int i4 = 59; i4 <= 71; i4+=1) {
          B[2 * i4 + 9] = (((E[1 * i4 - 5] * B[1 * i5 + 14]) * ((E[2 * i4 - 5] - A[1 * i4 + 14]) * 105) - (84 * 57 - B[1 * i4 + 14])) - (57 - D[2 * i4 + 9])) * ((57 + B[2 * i4 + 14]) * ((A[1 * i4 + 9] + (B[1 * i4 - 14] - 84)) * (((D[1 * i4 - 9] - 57) - E[1 * i3 + 9]) * ((105 * 57 - ((84 - B[1 * i5 + 9]) - C[1 * i5 - 14])) + (84 + A[2 * i3 - 5]) * ((57 + 84) + 84)))));
      }
    }
  }
  for (int i1 = 105; i1 <= 110; i1+=1) {
    for (int i4 = 59; i4 <= 71; i4+=1) {
      for (int i2 = 67; i2 <= 105; i2+=1) {
          E[1 * i1 + 9] = (C[1 * i2 + 9] + A[2 * i1 - 14]) - (((D[2 * i1 + 9] + ((84 + E[2 * i1 + 14]) + 105)) + ((B[1 * i2 - 5] - B[1 * i4 - 9] * B[2 * i1 + 9]) + (57 - ((105 + D[2 * i4 - 9]) + E[2 * i4 - 9])))) * (E[2 * i4 - 14] * E[1 * i1 + 9] + (A[1 * i4 - 9] - (E[2 * i2 - 5] - (E[1 * i4 - 9] - E[1 * i1 + 5])))) - ((B[2 * i1 + 9] * 57 + (57 - 105) * (D[2 * i4 - 5] + (84 - D[1 * i2 - 5]))) + (E[1 * i4 + 9] - B[2 * i4 - 14])));
      }
    }
  }
  for (int i6 = 61; i6 <= 115; i6+=1) {
    for (int i3 = 53; i3 <= 91; i3+=1) {
      for (int i1 = 105; i1 <= 110; i1+=1) {
          A[1 * i1 - 9] = (((105 + B[1 * i6 + 14]) * D[1 * i3 - 5] - B[1 * i6 - 14]) + ((E[2 * i3 - 14] + (((A[2 * i1 - 14] + (C[2 * i6 - 14] + 105)) + 57) + 84 * (A[2 * i1 + 5] + C[2 * i1 - 9]))) + D[1 * i1 + 5] * 57)) - ((105 * 84 + (105 - C[1 * i6 + 5])) + ((B[1 * i1 + 14] * ((E[1 * i3 - 5] * C[2 * i1 - 9]) * C[1 * i3 - 9])) * (105 - B[2 * i1 - 9]) + ((B[1 * i6 + 9] - C[2 * i6 - 9]) + (57 - A[1 * i1 - 9]))));
      }
    }
  }
  for (int i6 = 61; i6 <= 115; i6+=1) {
    for (int i2 = 67; i2 <= 105; i2+=1) {
      for (int i5 = 85; i5 <= 102; i5+=1) {
          E[1 * i5 + 14] = ((B[1 * i2 + 9] + (105 - (D[2 * i5 - 9] * E[2 * i5 - 14]) * C[2 * i6 - 9])) * (((A[1 * i6 - 9] + 57) - (57 + D[1 * i6 + 9])) - C[1 * i5 - 9])) * (((D[2 * i5 + 14] + (57 - D[1 * i6 + 5])) * (((84 + 105) + (((A[2 * i2 - 9] * 105) * E[1 * i6 + 14] + A[1 * i5 - 5]) + (84 - C[1 * i2 - 5]))) - ((E[2 * i2 - 5] - (57 + 105)) + A[1 * i2 - 9]))) * (A[2 * i6 - 5] - (E[2 * i6 + 9] - D[1 * i6 + 14])));
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

