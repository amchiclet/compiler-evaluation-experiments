#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 238], float B[restrict 248], float C[restrict 230], float D[restrict 246], float E[restrict 230]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 29; i1 <= 94; i1+=1) {
    for (int i2 = 21; i2 <= 90; i2+=1) {
      for (int i3 = 23; i3 <= 82; i3+=1) {
          A[2 * i2 + 1] = (((B[1 * i2 + 11] - 124) * (106 + (C[1 * i1 + 9] - 106)) + A[1 * i2 - 9]) - (((106 - D[1 * i1 - 9]) - B[1 * i1 - 9]) + (106 + D[1 * i2 + 1]))) - (((2 * 124 - (D[1 * i3 - 11] + A[1 * i1 - 1])) + ((106 * A[2 * i3 + 9] - A[1 * i1 + 11]) + D[2 * i3 - 9] * 124) * C[1 * i3 - 11]) - ((B[1 * i3 - 9] * D[1 * i1 - 11] + 124 * 106) - (124 + D[1 * i3 - 1] * B[1 * i1 + 11])));
      }
    }
  }
  for (int i2 = 21; i2 <= 90; i2+=1) {
    for (int i3 = 23; i3 <= 82; i3+=1) {
      for (int i4 = 91; i4 <= 114; i4+=1) {
          B[2 * i2 + 11] = ((((((D[2 * i4 - 9] + 124) + C[1 * i4 + 1]) - A[2 * i3 - 1]) - D[2 * i4 - 1]) + 106) - 124) * (((106 + (106 + (106 + C[2 * i4 + 1]))) + 124) + (((A[1 * i4 - 9] - 2) * ((D[2 * i4 - 11] * A[1 * i3 - 9]) * 106) - E[1 * i3 + 11]) + (D[1 * i3 - 11] + (106 - ((D[2 * i3 + 11] - 124) + A[1 * i3 - 9] * 106)) * (A[1 * i4 + 9] + 106)))) + (124 + E[2 * i2 + 11]);
      }
    }
  }
  for (int i4 = 91; i4 <= 114; i4+=1) {
    for (int i1 = 29; i1 <= 94; i1+=1) {
      for (int i5 = 109; i5 <= 118; i5+=1) {
          D[1 * i4 - 9] = (((B[2 * i5 - 1] - 2) * (C[1 * i5 - 1] - ((106 + A[1 * i5 - 11]) - C[1 * i4 - 1])) + (((D[1 * i5 - 11] - 106) - 2) - A[1 * i5 - 9])) - (D[2 * i1 - 1] - C[1 * i4 - 11])) + ((C[2 * i4 + 1] - ((2 + D[1 * i4 + 1]) + 124 * (E[1 * i4 + 9] + D[1 * i1 + 11] * 2))) - ((A[1 * i5 + 9] * D[1 * i5 - 9] - B[2 * i1 + 11]) - 2)) * ((D[1 * i5 - 11] + (C[1 * i1 - 9] - B[2 * i5 - 9])) - (C[1 * i4 - 9] - 124));
      }
    }
  }
  for (int i4 = 91; i4 <= 114; i4+=1) {
    for (int i1 = 29; i1 <= 94; i1+=1) {
      for (int i3 = 23; i3 <= 82; i3+=1) {
          E[1 * i3 + 11] = ((A[1 * i3 - 9] * (B[2 * i4 - 9] - 2)) * (((D[1 * i1 + 11] + (E[1 * i3 - 1] + 2)) + (106 * 2 + C[2 * i1 + 11])) + (106 * ((B[1 * i3 + 11] + E[2 * i3 - 11]) + E[1 * i1 + 9])) * ((124 + (2 - (D[1 * i4 + 11] * E[2 * i4 + 1] + 106))) - (((B[2 * i3 - 1] + D[2 * i4 - 11]) + 2) + 124)))) * ((E[2 * i3 + 11] - B[1 * i3 - 1]) + ((106 - E[1 * i1 + 9]) + 124 * E[1 * i3 - 1]));
      }
    }
  }
  for (int i5 = 109; i5 <= 118; i5+=1) {
    for (int i3 = 23; i3 <= 82; i3+=1) {
      for (int i6 = 77; i6 <= 115; i6+=1) {
          C[2 * i6 - 11] = ((C[1 * i6 + 9] * C[1 * i5 + 9] + ((B[2 * i5 + 11] * ((A[2 * i5 + 1] + B[2 * i3 + 9]) * D[1 * i6 - 11]) + D[2 * i5 - 1] * (124 + D[2 * i5 + 9])) + A[2 * i3 + 9])) - (B[2 * i3 + 11] * B[1 * i6 + 11] + 106)) + ((E[1 * i5 + 1] + B[2 * i6 - 11]) * ((E[1 * i3 - 1] - 124) * B[1 * i6 + 11] - (C[1 * i3 - 1] - 2))) * (106 * C[1 * i6 + 9] + ((B[2 * i5 + 11] - (D[1 * i3 - 1] + 106)) - (B[1 * i3 + 9] + (C[2 * i6 - 9] + B[1 * i3 + 11]))));
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

