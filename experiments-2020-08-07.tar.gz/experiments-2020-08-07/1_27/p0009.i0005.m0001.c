#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 235], float B[restrict 239], float C[restrict 222], float D[restrict 235], float E[restrict 235]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 129; i1 <= 134; i1+=1) {
    for (int i2 = 77; i2 <= 127; i2+=1) {
      for (int i3 = 63; i3 <= 136; i3+=1) {
          A[1 * i2 + 5] = (((B[1 * i2 + 4] + C[1 * i3 - 5]) + B[1 * i2 + 4] * (D[1 * i3 - 5] - E[1 * i3 + 5])) + (C[1 * i1 - 4] - 85)) * (E[1 * i1 + 5] + (E[1 * i1 + 5] + 93)) - (D[1 * i1 - 13] * (E[1 * i2 - 13] * E[1 * i2 - 4])) * (((72 + A[1 * i2 + 4]) * (E[1 * i3 - 4] - (((72 - 93) - 85) - (B[1 * i2 + 5] + ((C[1 * i1 - 4] - E[1 * i3 + 13]) + 85))))) * (93 * (72 - (B[1 * i1 + 5] - (D[1 * i2 + 5] - B[1 * i3 - 5])))));
      }
    }
  }
  for (int i4 = 125; i4 <= 221; i4+=1) {
    for (int i3 = 63; i3 <= 136; i3+=1) {
      for (int i5 = 204; i5 <= 225; i5+=1) {
          B[1 * i4 + 13] = (((E[1 * i4 - 5] * B[1 * i5 + 4]) * ((E[1 * i4 - 5] - A[1 * i4 + 4]) * 72) - (93 * 85 - B[1 * i4 + 4])) - (85 - D[1 * i4 + 13])) * ((85 + B[1 * i4 + 4]) * ((A[1 * i4 + 13] + (B[1 * i4 - 4] - 93)) * (((D[1 * i4 - 13] - 85) - E[1 * i3 + 13]) * ((72 * 85 - ((93 - B[1 * i5 + 13]) - C[1 * i5 - 4])) + (93 + A[1 * i3 - 5]) * ((85 + 93) + 93)))));
      }
    }
  }
  for (int i1 = 129; i1 <= 134; i1+=1) {
    for (int i4 = 125; i4 <= 221; i4+=1) {
      for (int i2 = 77; i2 <= 127; i2+=1) {
          E[1 * i1 + 13] = (C[1 * i2 + 13] + A[1 * i1 - 4]) - (((D[1 * i1 + 13] + ((93 + E[1 * i1 + 4]) + 72)) + ((B[1 * i2 - 5] - B[1 * i4 - 13] * B[1 * i1 + 13]) + (85 - ((72 + D[1 * i4 - 13]) + E[1 * i4 - 13])))) * (E[1 * i4 - 4] * E[1 * i1 + 13] + (A[1 * i4 - 13] - (E[1 * i2 - 5] - (E[1 * i4 - 13] - E[1 * i1 + 5])))) - ((B[1 * i1 + 13] * 85 + (85 - 72) * (D[1 * i4 - 5] + (93 - D[1 * i2 - 5]))) + (E[1 * i4 + 13] - B[1 * i4 - 4])));
      }
    }
  }
  for (int i6 = 46; i6 <= 49; i6+=1) {
    for (int i1 = 129; i1 <= 134; i1+=1) {
      for (int i3 = 63; i3 <= 136; i3+=1) {
          A[1 * i1 - 13] = (((72 + B[1 * i6 + 4]) * D[1 * i3 - 5] - B[1 * i6 - 4]) + ((E[1 * i3 - 4] + (((A[1 * i1 - 4] + (C[1 * i6 - 4] + 72)) + 85) + 93 * (A[1 * i1 + 5] + C[1 * i1 - 13]))) + D[1 * i1 + 5] * 85)) - ((72 * 93 + (72 - C[1 * i6 + 5])) + ((B[1 * i1 + 4] * ((E[1 * i3 - 5] * C[1 * i1 - 13]) * C[1 * i3 - 13])) * (72 - B[1 * i1 - 13]) + ((B[1 * i6 + 13] - C[1 * i6 - 13]) + (85 - A[1 * i1 - 13]))));
      }
    }
  }
  for (int i6 = 46; i6 <= 49; i6+=1) {
    for (int i2 = 77; i2 <= 127; i2+=1) {
      for (int i5 = 204; i5 <= 225; i5+=1) {
          E[1 * i5 + 4] = ((B[1 * i2 + 13] + (72 - (D[1 * i5 - 13] * E[1 * i5 - 4]) * C[1 * i6 - 13])) * (((A[1 * i6 - 13] + 85) - (85 + D[1 * i6 + 13])) - C[1 * i5 - 13])) * (((D[1 * i5 + 4] + (85 - D[1 * i6 + 5])) * (((93 + 72) + (((A[1 * i2 - 13] * 72) * E[1 * i6 + 4] + A[1 * i5 - 5]) + (93 - C[1 * i2 - 5]))) - ((E[1 * i2 - 5] - (85 + 72)) + A[1 * i2 - 13]))) * (A[1 * i6 - 5] - (E[1 * i6 + 13] - D[1 * i6 + 4])));
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

