#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 237], float B[restrict 254], float C[restrict 245], float D[restrict 253], float E[restrict 254]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 38; i1 <= 96; i1+=1) {
    for (int i2 = 35; i2 <= 102; i2+=1) {
      for (int i3 = 48; i3 <= 48; i3+=1) {
          A[2 * i3 - 9] = ((22 * B[1 * i3 + 8]) * (20 + A[1 * i2 + 0]) + (C[2 * i1 - 0] - 59 * D[2 * i1 + 0])) - (((((((C[1 * i3 - 0] + E[1 * i3 + 0]) + D[2 * i2 + 8]) - A[2 * i3 - 0] * 20) - (22 + E[2 * i1 + 9])) - (20 + 20)) - (59 - D[2 * i2 - 9] * 59) * ((59 - C[2 * i3 + 0]) * (20 * C[2 * i1 - 8]))) - ((D[2 * i3 - 9] + (B[2 * i3 - 9] - 22)) - (22 + A[2 * i3 - 9])));
      }
    }
  }
  for (int i4 = 53; i4 <= 122; i4+=1) {
    for (int i2 = 35; i2 <= 102; i2+=1) {
      for (int i3 = 48; i3 <= 48; i3+=1) {
          C[2 * i3 + 0] = (((C[2 * i4 - 8] * C[2 * i2 - 8] - A[2 * i2 - 8] * 59) - ((22 * D[2 * i4 - 8]) * A[2 * i4 - 9] - A[1 * i4 + 8])) + (20 + (59 + (C[2 * i3 + 0] * B[1 * i2 + 9] + ((E[2 * i4 - 9] - 22 * 59) + (A[1 * i4 + 0] + 20 * 22)))))) * (((E[2 * i4 - 8] - B[2 * i3 + 8]) * A[1 * i2 + 8]) * (((22 - 20) - (E[1 * i3 - 0] * E[2 * i2 - 9] - (A[1 * i4 - 8] - B[2 * i2 - 0]))) * E[2 * i3 - 9]));
      }
    }
  }
  for (int i1 = 38; i1 <= 96; i1+=1) {
    for (int i5 = 89; i5 <= 120; i5+=1) {
      for (int i4 = 53; i4 <= 122; i4+=1) {
          D[2 * i4 - 9] = (22 - ((E[1 * i1 - 0] - ((A[2 * i4 - 8] + B[2 * i1 - 9]) - 59)) - (A[1 * i4 + 8] - D[2 * i5 - 8]))) + ((20 * 59 - D[1 * i5 - 8]) - (E[1 * i5 - 0] * E[2 * i5 + 0] + (59 - (E[1 * i1 - 9] + A[1 * i4 - 0])))) * (((D[2 * i1 - 9] + 59) - (B[2 * i1 - 9] - E[2 * i5 + 0])) * D[1 * i5 + 9] + ((D[1 * i4 - 8] - (D[2 * i4 - 8] + ((22 + 59) - (59 + B[2 * i4 + 9])))) + C[2 * i4 - 8] * 20));
      }
    }
  }
  for (int i4 = 53; i4 <= 122; i4+=1) {
    for (int i6 = 60; i6 <= 95; i6+=1) {
      for (int i3 = 48; i3 <= 48; i3+=1) {
          D[2 * i6 - 9] = (59 * ((20 * (22 - D[1 * i3 - 8])) * (((20 - 22) + (D[1 * i3 + 8] - D[2 * i6 - 0])) - (C[1 * i6 + 8] + ((C[2 * i6 + 8] + B[2 * i3 - 8]) - 20)) * (B[1 * i3 - 8] * B[2 * i3 + 8])))) * ((D[2 * i3 + 9] * ((A[2 * i6 + 8] - A[2 * i3 - 0]) * E[2 * i3 + 9])) * 20) + (((B[1 * i4 - 9] * C[2 * i6 + 9] + (C[2 * i3 - 8] - C[1 * i6 - 9])) + (C[2 * i3 - 9] - (E[2 * i6 - 9] + B[2 * i3 + 9]))) - (59 + C[2 * i3 + 8]));
      }
    }
  }
  for (int i1 = 38; i1 <= 96; i1+=1) {
    for (int i4 = 53; i4 <= 122; i4+=1) {
      for (int i3 = 48; i3 <= 48; i3+=1) {
          C[1 * i4 + 9] = (20 * E[1 * i3 - 0] + (C[2 * i3 - 0] - (((C[2 * i3 - 9] - 20) - (B[2 * i4 + 9] - 22) * (C[2 * i4 + 0] * B[2 * i3 - 9])) - (B[2 * i1 + 0] - D[2 * i1 + 8]) * (22 + 22)))) * ((20 - D[2 * i4 + 8]) * (((E[1 * i3 - 0] + E[2 * i4 + 9]) + (((E[1 * i1 + 0] + D[1 * i1 + 0] * D[1 * i3 + 9]) - (20 + D[2 * i1 + 8] * C[2 * i4 - 0])) - D[1 * i1 + 8] * E[2 * i4 - 9])) * (A[1 * i4 + 0] - (D[1 * i1 + 8] - C[1 * i3 + 8]))));
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

