#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 231], float B[restrict 125], float C[restrict 221], float D[restrict 236], float E[restrict 229]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 13; i1 <= 16; i1+=1) {
    for (int i2 = 16; i2 <= 27; i2+=1) {
      for (int i3 = 95; i3 <= 110; i3+=1) {
          A[1 * i2 + 13] = ((((B[2 * i2 + 13] + C[1 * i3 - 13]) - C[1 * i2 - 8]) + C[1 * i2 + 2]) - B[1 * i2 - 8] * A[1 * i3 + 2]) * (((C[1 * i1 - 13] + 6) - (D[1 * i1 + 13] * E[1 * i3 - 13] + 56)) + (((A[2 * i2 - 8] + E[1 * i3 - 13]) + C[1 * i3 - 2]) * (A[2 * i2 - 2] * (A[1 * i1 - 13] * 56)) - (((E[2 * i1 - 8] + E[1 * i1 - 2]) * C[1 * i2 - 8] - ((E[2 * i1 - 2] - A[1 * i2 - 2]) + (B[1 * i2 + 8] - C[1 * i3 + 8]) * ((D[1 * i1 - 2] + C[2 * i1 + 13]) - C[1 * i1 - 2]))) + C[1 * i1 - 8])));
      }
    }
  }
  for (int i2 = 16; i2 <= 27; i2+=1) {
    for (int i4 = 96; i4 <= 111; i4+=1) {
      for (int i5 = 13; i5 <= 39; i5+=1) {
          D[1 * i4 + 2] = (C[1 * i5 - 8] + A[2 * i4 + 8]) + (((6 - (B[1 * i4 - 13] + E[1 * i4 + 2])) * ((C[1 * i4 + 8] - 105 * 105) * (6 + D[1 * i5 + 2])) - (105 * (E[1 * i5 + 8] - A[1 * i2 - 13])) * B[1 * i5 + 8]) - (((D[1 * i4 - 2] - 105 * A[2 * i5 - 8]) - (C[2 * i5 + 13] * E[1 * i2 + 13] + 56)) - B[1 * i4 + 8] * (56 * (6 * 56 - (A[1 * i5 + 2] + D[2 * i2 - 13])))) * (C[2 * i2 - 8] + 6));
      }
    }
  }
  for (int i4 = 96; i4 <= 111; i4+=1) {
    for (int i2 = 16; i2 <= 27; i2+=1) {
      for (int i5 = 13; i5 <= 39; i5+=1) {
          E[1 * i4 - 13] = ((((A[2 * i2 + 13] + (105 - E[1 * i4 - 13])) - C[1 * i5 + 2]) - 105 * 56) + ((D[2 * i4 - 13] - E[1 * i4 + 13]) * ((6 * C[1 * i5 - 2] + D[1 * i2 - 13]) + D[2 * i4 + 13] * ((B[1 * i4 + 13] - 56) + E[2 * i5 - 8])) + (C[1 * i2 - 2] - C[1 * i4 - 2]))) * ((C[1 * i5 - 2] - D[1 * i5 + 8]) + D[1 * i5 - 13]) - D[1 * i2 - 8] * (((E[2 * i4 - 13] + 105) + (D[1 * i4 + 8] - 105)) + C[2 * i2 + 13] * (105 + A[1 * i2 - 8]));
      }
    }
  }
  for (int i1 = 13; i1 <= 16; i1+=1) {
    for (int i4 = 96; i4 <= 111; i4+=1) {
      for (int i6 = 48; i6 <= 73; i6+=1) {
          E[1 * i1 + 2] = (E[1 * i1 + 8] + ((C[1 * i4 + 2] - (E[2 * i6 + 13] + 105 * E[2 * i1 - 8])) + ((E[1 * i1 - 2] + 56) + (C[1 * i4 + 2] + (C[1 * i1 - 8] - 6)) * (105 - E[1 * i4 - 8])))) * (((((D[1 * i1 - 2] + (56 - C[2 * i4 - 2])) + C[1 * i1 - 13]) - (105 + (D[2 * i1 + 8] - 6))) - C[1 * i1 + 8]) * ((E[1 * i1 + 2] * C[1 * i6 + 13] + ((105 + (B[1 * i4 - 13] + D[1 * i4 + 8])) + 6)) + 6 * D[1 * i6 - 2]));
      }
    }
  }
  for (int i5 = 13; i5 <= 39; i5+=1) {
    for (int i3 = 95; i3 <= 110; i3+=1) {
      for (int i2 = 16; i2 <= 27; i2+=1) {
          B[2 * i2 + 8] = (((((D[1 * i3 + 2] + D[1 * i5 + 2]) - 6) * A[1 * i5 + 2]) * ((E[1 * i5 + 2] - A[2 * i5 + 13]) + E[2 * i5 + 8] * D[1 * i3 + 8]) - C[1 * i2 - 13]) + (A[2 * i5 - 2] + ((((56 - B[1 * i2 + 8]) + 56 * 6) + (D[1 * i5 + 8] + (D[1 * i2 - 2] - B[2 * i5 + 13]))) + ((6 + C[1 * i2 - 8]) - 6)))) + (((E[2 * i3 - 8] * C[1 * i3 + 2]) * (E[2 * i3 + 8] + 6)) * (C[1 * i2 - 13] * B[2 * i5 + 2]) - (A[1 * i5 + 13] - 56));
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

