#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 230], float B[restrict 208], float C[restrict 225], float D[restrict 228], float E[restrict 230]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 107; i1 <= 143; i1+=1) {
    for (int i2 = 39; i2 <= 106; i2+=1) {
      for (int i3 = 45; i3 <= 77; i3+=1) {
          A[1 * i2 + 6] = (((B[1 * i2 + 9] - 78) * (2 + (C[1 * i1 + 11] - 2)) + A[1 * i2 - 11]) - (((2 - D[1 * i1 - 11]) - B[1 * i1 - 11]) + (2 + D[1 * i2 + 6]))) - (((58 * 78 - (D[1 * i3 - 9] + A[1 * i1 - 6])) + ((2 * A[1 * i3 + 11] - A[1 * i1 + 9]) + D[1 * i3 - 11] * 78) * C[1 * i3 - 9]) - ((B[1 * i3 - 11] * D[1 * i1 - 9] + 78 * 2) - (78 + D[1 * i3 - 6] * B[1 * i1 + 9])));
      }
    }
  }
  for (int i3 = 45; i3 <= 77; i3+=1) {
    for (int i4 = 147; i4 <= 218; i4+=1) {
      for (int i2 = 39; i2 <= 106; i2+=1) {
          B[1 * i2 + 9] = ((((((D[1 * i4 - 11] + 78) + C[1 * i4 + 6]) - A[1 * i3 - 6]) - D[1 * i4 - 6]) + 2) - 78) * (((2 + (2 + (2 + C[1 * i4 + 6]))) + 78) + (((A[1 * i4 - 11] - 58) * ((D[1 * i4 - 9] * A[1 * i3 - 11]) * 2) - E[1 * i3 + 9]) + (D[1 * i3 - 9] + (2 - ((D[1 * i3 + 9] - 78) + A[1 * i3 - 11] * 2)) * (A[1 * i4 + 11] + 2)))) + (78 + E[1 * i2 + 9]);
      }
    }
  }
  for (int i4 = 147; i4 <= 218; i4+=1) {
    for (int i1 = 107; i1 <= 143; i1+=1) {
      for (int i5 = 24; i5 <= 122; i5+=1) {
          D[1 * i4 - 11] = (((B[1 * i5 - 6] - 58) * (C[1 * i5 - 6] - ((2 + A[1 * i5 - 9]) - C[1 * i4 - 6])) + (((D[1 * i5 - 9] - 2) - 58) - A[1 * i5 - 11])) - (D[1 * i1 - 6] - C[1 * i4 - 9])) + ((C[1 * i4 + 6] - ((58 + D[1 * i4 + 6]) + 78 * (E[1 * i4 + 11] + D[1 * i1 + 9] * 58))) - ((A[1 * i5 + 11] * D[1 * i5 - 11] - B[1 * i1 + 9]) - 58)) * ((D[1 * i5 - 9] + (C[1 * i1 - 11] - B[1 * i5 - 11])) - (C[1 * i4 - 11] - 78));
      }
    }
  }
  for (int i4 = 147; i4 <= 218; i4+=1) {
    for (int i1 = 107; i1 <= 143; i1+=1) {
      for (int i3 = 45; i3 <= 77; i3+=1) {
          E[1 * i3 + 9] = ((A[1 * i3 - 11] * (B[1 * i4 - 11] - 58)) * (((D[1 * i1 + 9] + (E[1 * i3 - 6] + 58)) + (2 * 58 + C[1 * i1 + 9])) + (2 * ((B[1 * i3 + 9] + E[1 * i3 - 9]) + E[1 * i1 + 11])) * ((78 + (58 - (D[1 * i4 + 9] * E[1 * i4 + 6] + 2))) - (((B[1 * i3 - 6] + D[1 * i4 - 9]) + 58) + 78)))) * ((E[1 * i3 + 9] - B[1 * i3 - 6]) + ((2 - E[1 * i1 + 11]) + 78 * E[1 * i3 - 6]));
      }
    }
  }
  for (int i6 = 31; i6 <= 32; i6+=1) {
    for (int i5 = 24; i5 <= 122; i5+=1) {
      for (int i3 = 45; i3 <= 77; i3+=1) {
          C[1 * i6 - 9] = ((C[1 * i6 + 11] * C[1 * i5 + 11] + ((B[1 * i5 + 9] * ((A[1 * i5 + 6] + B[1 * i3 + 11]) * D[1 * i6 - 9]) + D[1 * i5 - 6] * (78 + D[1 * i5 + 11])) + A[1 * i3 + 11])) - (B[1 * i3 + 9] * B[1 * i6 + 9] + 2)) + ((E[1 * i5 + 6] + B[1 * i6 - 9]) * ((E[1 * i3 - 6] - 78) * B[1 * i6 + 9] - (C[1 * i3 - 6] - 58))) * (2 * C[1 * i6 + 11] + ((B[1 * i5 + 9] - (D[1 * i3 - 6] + 2)) - (B[1 * i3 + 11] + (C[1 * i6 - 11] + B[1 * i3 + 9]))));
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

