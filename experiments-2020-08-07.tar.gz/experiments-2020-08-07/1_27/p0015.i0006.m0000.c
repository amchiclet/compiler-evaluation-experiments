#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 230], float B[restrict 230], float C[restrict 230], float D[restrict 230], float E[restrict 224]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 76; i1 <= 110; i1+=1) {
    for (int i2 = 26; i2 <= 51; i2+=1) {
      for (int i3 = 22; i3 <= 54; i3+=1) {
          A[2 * i2 + 3] = (((B[1 * i2 + 9] - 50) * (11 + (C[2 * i1 + 3] - 11)) + A[1 * i2 - 3]) - (((11 - D[2 * i1 - 3]) - B[1 * i1 - 3]) + (11 + D[1 * i2 + 3]))) - (((115 * 50 - (D[1 * i3 - 9] + A[2 * i1 - 3])) + ((11 * A[2 * i3 + 3] - A[2 * i1 + 9]) + D[2 * i3 - 3] * 50) * C[1 * i3 - 9]) - ((B[2 * i3 - 3] * D[1 * i1 - 9] + 50 * 11) - (50 + D[1 * i3 - 3] * B[1 * i1 + 9])));
      }
    }
  }
  for (int i3 = 22; i3 <= 54; i3+=1) {
    for (int i2 = 26; i2 <= 51; i2+=1) {
      for (int i4 = 62; i4 <= 71; i4+=1) {
          B[2 * i2 + 9] = ((((((D[2 * i4 - 3] + 50) + C[1 * i4 + 3]) - A[2 * i3 - 3]) - D[2 * i4 - 3]) + 11) - 50) * (((11 + (11 + (11 + C[2 * i4 + 3]))) + 50) + (((A[1 * i4 - 3] - 115) * ((D[2 * i4 - 9] * A[1 * i3 - 3]) * 11) - E[1 * i3 + 9]) + (D[1 * i3 - 9] + (11 - ((D[2 * i3 + 9] - 50) + A[1 * i3 - 3] * 11)) * (A[2 * i4 + 3] + 11)))) + (50 + E[2 * i2 + 9]);
      }
    }
  }
  for (int i4 = 62; i4 <= 71; i4+=1) {
    for (int i1 = 76; i1 <= 110; i1+=1) {
      for (int i5 = 13; i5 <= 49; i5+=1) {
          D[2 * i4 - 3] = (((B[2 * i5 - 3] - 115) * (C[1 * i5 - 3] - ((11 + A[1 * i5 - 9]) - C[2 * i4 - 3])) + (((D[1 * i5 - 9] - 11) - 115) - A[2 * i5 - 3])) - (D[2 * i1 - 3] - C[2 * i4 - 9])) + ((C[2 * i4 + 3] - ((115 + D[1 * i4 + 3]) + 50 * (E[2 * i4 + 3] + D[2 * i1 + 9] * 115))) - ((A[2 * i5 + 3] * D[1 * i5 - 3] - B[2 * i1 + 9]) - 115)) * ((D[1 * i5 - 9] + (C[2 * i1 - 3] - B[2 * i5 - 3])) - (C[2 * i4 - 3] - 50));
      }
    }
  }
  for (int i4 = 62; i4 <= 71; i4+=1) {
    for (int i1 = 76; i1 <= 110; i1+=1) {
      for (int i3 = 22; i3 <= 54; i3+=1) {
          E[2 * i3 + 9] = ((A[1 * i3 - 3] * (B[2 * i4 - 3] - 115)) * (((D[1 * i1 + 9] + (E[2 * i3 - 3] + 115)) + (11 * 115 + C[2 * i1 + 9])) + (11 * ((B[1 * i3 + 9] + E[2 * i3 - 9]) + E[2 * i1 + 3])) * ((50 + (115 - (D[1 * i4 + 9] * E[2 * i4 + 3] + 11))) - (((B[2 * i3 - 3] + D[2 * i4 - 9]) + 115) + 50)))) * ((E[2 * i3 + 9] - B[2 * i3 - 3]) + ((11 - E[2 * i1 + 3]) + 50 * E[2 * i3 - 3]));
      }
    }
  }
  for (int i5 = 13; i5 <= 49; i5+=1) {
    for (int i3 = 22; i3 <= 54; i3+=1) {
      for (int i6 = 44; i6 <= 62; i6+=1) {
          C[2 * i6 - 9] = ((C[2 * i6 + 3] * C[2 * i5 + 3] + ((B[2 * i5 + 9] * ((A[2 * i5 + 3] + B[2 * i3 + 3]) * D[1 * i6 - 9]) + D[2 * i5 - 3] * (50 + D[2 * i5 + 3])) + A[2 * i3 + 3])) - (B[2 * i3 + 9] * B[1 * i6 + 9] + 11)) + ((E[1 * i5 + 3] + B[2 * i6 - 9]) * ((E[2 * i3 - 3] - 50) * B[2 * i6 + 9] - (C[2 * i3 - 3] - 115))) * (11 * C[2 * i6 + 3] + ((B[2 * i5 + 9] - (D[1 * i3 - 3] + 11)) - (B[2 * i3 + 3] + (C[2 * i6 - 3] + B[1 * i3 + 9]))));
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

