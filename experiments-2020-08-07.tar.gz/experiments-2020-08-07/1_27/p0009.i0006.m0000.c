#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 231], float B[restrict 223], float C[restrict 230], float D[restrict 247], float E[restrict 247]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 26; i1 <= 101; i1+=1) {
    for (int i2 = 31; i2 <= 67; i2+=1) {
      for (int i3 = 16; i3 <= 30; i3+=1) {
          A[2 * i2 + 4] = (((B[2 * i2 + 12] + C[1 * i3 - 4]) + B[1 * i2 + 12] * (D[1 * i3 - 4] - E[2 * i3 + 4])) + (C[2 * i1 - 12] - 83)) * (E[2 * i1 + 4] + (E[2 * i1 + 4] + 8)) - (D[2 * i1 - 5] * (E[2 * i2 - 5] * E[1 * i2 - 12])) * (((67 + A[2 * i2 + 12]) * (E[2 * i3 - 12] - (((67 - 8) - 83) - (B[1 * i2 + 4] + ((C[2 * i1 - 12] - E[2 * i3 + 5]) + 83))))) * (8 * (67 - (B[2 * i1 + 4] - (D[1 * i2 + 4] - B[2 * i3 - 4])))));
      }
    }
  }
  for (int i4 = 34; i4 <= 64; i4+=1) {
    for (int i3 = 16; i3 <= 30; i3+=1) {
      for (int i5 = 18; i5 <= 103; i5+=1) {
          B[2 * i4 + 5] = (((E[2 * i4 - 4] * B[2 * i5 + 12]) * ((E[2 * i4 - 4] - A[1 * i4 + 12]) * 67) - (8 * 83 - B[2 * i4 + 12])) - (83 - D[2 * i4 + 5])) * ((83 + B[2 * i4 + 12]) * ((A[2 * i4 + 5] + (B[1 * i4 - 12] - 8)) * (((D[2 * i4 - 5] - 83) - E[1 * i3 + 5]) * ((67 * 83 - ((8 - B[2 * i5 + 5]) - C[1 * i5 - 12])) + (8 + A[2 * i3 - 4]) * ((83 + 8) + 8)))));
      }
    }
  }
  for (int i1 = 26; i1 <= 101; i1+=1) {
    for (int i4 = 34; i4 <= 64; i4+=1) {
      for (int i2 = 31; i2 <= 67; i2+=1) {
          E[2 * i1 + 5] = (C[1 * i2 + 5] + A[2 * i1 - 12]) - (((D[2 * i1 + 5] + ((8 + E[2 * i1 + 12]) + 67)) + ((B[2 * i2 - 4] - B[1 * i4 - 5] * B[2 * i1 + 5]) + (83 - ((67 + D[2 * i4 - 5]) + E[2 * i4 - 5])))) * (E[2 * i4 - 12] * E[1 * i1 + 5] + (A[1 * i4 - 5] - (E[2 * i2 - 4] - (E[2 * i4 - 5] - E[1 * i1 + 4])))) - ((B[2 * i1 + 5] * 83 + (83 - 67) * (D[2 * i4 - 4] + (8 - D[1 * i2 - 4]))) + (E[1 * i4 + 5] - B[2 * i4 - 12])));
      }
    }
  }
  for (int i1 = 26; i1 <= 101; i1+=1) {
    for (int i6 = 12; i6 <= 117; i6+=1) {
      for (int i3 = 16; i3 <= 30; i3+=1) {
          A[1 * i1 - 5] = (((67 + B[1 * i6 + 12]) * D[2 * i3 - 4] - B[2 * i6 - 12]) + ((E[2 * i3 - 12] + (((A[2 * i1 - 12] + (C[2 * i6 - 12] + 67)) + 83) + 8 * (A[2 * i1 + 4] + C[2 * i1 - 5]))) + D[2 * i1 + 4] * 83)) - ((67 * 8 + (67 - C[1 * i6 + 4])) + ((B[2 * i1 + 12] * ((E[1 * i3 - 4] * C[2 * i1 - 5]) * C[2 * i3 - 5])) * (67 - B[2 * i1 - 5]) + ((B[1 * i6 + 5] - C[2 * i6 - 5]) + (83 - A[2 * i1 - 5]))));
      }
    }
  }
  for (int i6 = 12; i6 <= 117; i6+=1) {
    for (int i2 = 31; i2 <= 67; i2+=1) {
      for (int i5 = 18; i5 <= 103; i5+=1) {
          E[1 * i5 + 12] = ((B[2 * i2 + 5] + (67 - (D[2 * i5 - 5] * E[2 * i5 - 12]) * C[2 * i6 - 5])) * (((A[1 * i6 - 5] + 83) - (83 + D[2 * i6 + 5])) - C[1 * i5 - 5])) * (((D[2 * i5 + 12] + (83 - D[1 * i6 + 4])) * (((8 + 67) + (((A[2 * i2 - 5] * 67) * E[2 * i6 + 12] + A[1 * i5 - 4]) + (8 - C[1 * i2 - 4]))) - ((E[2 * i2 - 4] - (83 + 67)) + A[1 * i2 - 5]))) * (A[2 * i6 - 4] - (E[2 * i6 + 5] - D[2 * i6 + 12])));
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

