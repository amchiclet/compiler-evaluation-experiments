#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 251], float B[restrict 248], float C[restrict 224], float D[restrict 226], float E[restrict 230]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 23; i1 <= 52; i1+=1) {
    for (int i2 = 80; i2 <= 119; i2+=1) {
      for (int i3 = 9; i3 <= 108; i3+=1) {
          A[2 * i3 - 9] = ((2 * B[2 * i3 + 7]) * (46 + A[2 * i2 + 12]) + (C[1 * i1 - 12] - 49 * D[1 * i1 + 12])) - (((((((C[2 * i3 - 12] + E[2 * i3 + 12]) + D[1 * i2 + 7]) - A[2 * i3 - 12] * 46) - (2 + E[2 * i1 + 9])) - (46 + 46)) - (49 - D[1 * i2 - 9] * 49) * ((49 - C[1 * i3 + 12]) * (46 * C[2 * i1 - 7]))) - ((D[1 * i3 - 9] + (B[1 * i3 - 9] - 2)) - (2 + A[1 * i3 - 9])));
      }
    }
  }
  for (int i4 = 38; i4 <= 73; i4+=1) {
    for (int i2 = 80; i2 <= 119; i2+=1) {
      for (int i3 = 9; i3 <= 108; i3+=1) {
          C[1 * i3 + 12] = (((C[2 * i4 - 7] * C[1 * i2 - 7] - A[1 * i2 - 7] * 49) - ((2 * D[1 * i4 - 7]) * A[1 * i4 - 9] - A[2 * i4 + 7])) + (46 + (49 + (C[1 * i3 + 12] * B[2 * i2 + 9] + ((E[2 * i4 - 9] - 2 * 49) + (A[2 * i4 + 12] + 46 * 2)))))) * (((E[1 * i4 - 7] - B[1 * i3 + 7]) * A[2 * i2 + 7]) * (((2 - 46) - (E[2 * i3 - 12] * E[2 * i2 - 9] - (A[2 * i4 - 7] - B[1 * i2 - 12]))) * E[1 * i3 - 9]));
      }
    }
  }
  for (int i1 = 23; i1 <= 52; i1+=1) {
    for (int i5 = 83; i5 <= 89; i5+=1) {
      for (int i4 = 38; i4 <= 73; i4+=1) {
          D[1 * i4 - 9] = (2 - ((E[2 * i1 - 12] - ((A[1 * i4 - 7] + B[2 * i1 - 9]) - 49)) - (A[2 * i4 + 7] - D[2 * i5 - 7]))) + ((46 * 49 - D[2 * i5 - 7]) - (E[2 * i5 - 12] * E[2 * i5 + 12] + (49 - (E[2 * i1 - 9] + A[2 * i4 - 12])))) * (((D[1 * i1 - 9] + 49) - (B[1 * i1 - 9] - E[1 * i5 + 12])) * D[2 * i5 + 9] + ((D[2 * i4 - 7] - (D[2 * i4 - 7] + ((2 + 49) - (49 + B[1 * i4 + 9])))) + C[2 * i4 - 7] * 46));
      }
    }
  }
  for (int i6 = 27; i6 <= 98; i6+=1) {
    for (int i3 = 9; i3 <= 108; i3+=1) {
      for (int i4 = 38; i4 <= 73; i4+=1) {
          D[2 * i6 - 9] = (49 * ((46 * (2 - D[2 * i3 - 7])) * (((46 - 2) + (D[2 * i3 + 7] - D[2 * i6 - 12])) - (C[2 * i6 + 7] + ((C[1 * i6 + 7] + B[1 * i3 - 7]) - 46)) * (B[2 * i3 - 7] * B[2 * i3 + 7])))) * ((D[2 * i3 + 9] * ((A[1 * i6 + 7] - A[2 * i3 - 12]) * E[2 * i3 + 9])) * 46) + (((B[2 * i4 - 9] * C[2 * i6 + 9] + (C[2 * i3 - 7] - C[2 * i6 - 9])) + (C[2 * i3 - 9] - (E[1 * i6 - 9] + B[1 * i3 + 9]))) - (49 + C[1 * i3 + 7]));
      }
    }
  }
  for (int i3 = 9; i3 <= 108; i3+=1) {
    for (int i1 = 23; i1 <= 52; i1+=1) {
      for (int i4 = 38; i4 <= 73; i4+=1) {
          C[2 * i4 + 9] = (46 * E[2 * i3 - 12] + (C[2 * i3 - 12] - (((C[2 * i3 - 9] - 46) - (B[1 * i4 + 9] - 2) * (C[1 * i4 + 12] * B[1 * i3 - 9])) - (B[1 * i1 + 12] - D[2 * i1 + 7]) * (2 + 2)))) * ((46 - D[1 * i4 + 7]) * (((E[2 * i3 - 12] + E[1 * i4 + 9]) + (((E[2 * i1 + 12] + D[2 * i1 + 12] * D[2 * i3 + 9]) - (46 + D[1 * i1 + 7] * C[2 * i4 - 12])) - D[2 * i1 + 7] * E[1 * i4 - 9])) * (A[2 * i4 + 12] - (D[2 * i1 + 7] - C[2 * i3 + 7]))));
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

