#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 252], float B[restrict 244], float C[restrict 244], float D[restrict 212], float E[restrict 252]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 36; i1 <= 62; i1+=1) {
    for (int i2 = 65; i2 <= 79; i2+=1) {
      for (int i3 = 26; i3 <= 121; i3+=1) {
          A[2 * i2 + 1] = 93 * ((93 - (B[2 * i2 + 1] + C[2 * i2 - 1])) * (((B[1 * i2 - 1] * 121) * (121 - (((121 * 121 - ((D[1 * i2 - 1] + B[2 * i2 - 1]) - A[1 * i3 - 1])) + E[2 * i2 - 1] * 93) - 93)) + 93) + ((93 + (E[1 * i3 + 1] + E[2 * i1 + 1])) - C[2 * i3 + 1]) * ((A[2 * i1 - 1] - 121 * A[2 * i2 + 1]) * (81 * D[2 * i2 + 1] + E[2 * i1 - 1]) - (B[2 * i3 + 1] - B[2 * i2 - 1]))));
      }
    }
  }
  for (int i1 = 36; i1 <= 62; i1+=1) {
    for (int i4 = 47; i4 <= 125; i4+=1) {
      for (int i2 = 65; i2 <= 79; i2+=1) {
          E[2 * i4 + 1] = ((121 - (A[2 * i2 - 1] + (121 + 121))) + ((A[2 * i4 + 1] - D[2 * i1 - 1]) * ((E[2 * i1 + 1] * (81 - 81)) * A[2 * i2 - 1] + ((93 + B[1 * i2 - 1]) - E[2 * i1 + 1])) - E[2 * i1 + 1])) * ((A[2 * i4 - 1] - A[2 * i4 + 1]) + (93 - A[1 * i1 + 1])) + (((A[1 * i2 - 1] + B[2 * i1 + 1]) - A[1 * i4 - 1]) * (81 * 121) - (B[1 * i4 - 1] - (D[1 * i4 + 1] + E[1 * i2 - 1] * B[1 * i4 - 1])) * D[2 * i2 - 1]);
      }
    }
  }
  for (int i5 = 59; i5 <= 106; i5+=1) {
    for (int i3 = 26; i3 <= 121; i3+=1) {
      for (int i6 = 7; i6 <= 84; i6+=1) {
          C[2 * i5 + 1] = ((((C[2 * i6 + 1] + 93) + D[1 * i5 + 1]) - ((121 - E[2 * i5 + 1]) - (121 - 93))) + (81 + B[2 * i3 + 1])) - ((B[1 * i5 - 1] * ((E[2 * i3 - 1] * D[2 * i6 + 1] - B[1 * i3 + 1]) - (81 * E[1 * i5 - 1] - A[1 * i3 - 1])) - ((B[2 * i6 - 1] * (A[2 * i5 + 1] + (81 - 93)) - 93 * A[1 * i6 - 1]) - (93 - (D[2 * i6 - 1] - 121)))) - (B[2 * i6 - 1] * A[2 * i6 + 1]) * 81);
      }
    }
  }
  for (int i6 = 7; i6 <= 84; i6+=1) {
    for (int i5 = 59; i5 <= 106; i5+=1) {
      for (int i2 = 65; i2 <= 79; i2+=1) {
          C[2 * i5 + 1] = (81 * (B[1 * i6 + 1] + E[2 * i5 + 1])) * (C[2 * i2 + 1] - (C[2 * i2 - 1] - B[2 * i2 - 1]) * C[1 * i5 + 1]) + (((A[1 * i6 + 1] * ((B[2 * i2 - 1] + B[2 * i5 + 1]) - (C[1 * i2 + 1] - D[2 * i2 + 1]))) * 93 + (A[2 * i2 - 1] * (121 * E[2 * i2 + 1]) + ((C[1 * i2 - 1] - E[2 * i6 + 1]) + D[2 * i5 - 1]) * 121)) + (121 + ((E[2 * i5 + 1] + ((93 + A[2 * i6 + 1]) + (A[2 * i2 - 1] + 93))) * E[2 * i2 + 1]) * A[2 * i5 - 1]));
      }
    }
  }
  for (int i5 = 59; i5 <= 106; i5+=1) {
    for (int i6 = 7; i6 <= 84; i6+=1) {
      for (int i2 = 65; i2 <= 79; i2+=1) {
          D[2 * i5 - 1] = (93 * 81 - (121 - 121)) * D[1 * i6 - 1] - ((B[2 * i2 - 1] - ((D[1 * i5 + 1] + 81) + (B[2 * i6 + 1] + 93))) - (D[2 * i2 + 1] * (C[1 * i6 - 1] + C[2 * i5 + 1]) - ((121 * D[1 * i2 - 1] + ((A[2 * i2 - 1] + 93) - 93) * ((D[1 * i6 - 1] + 121) * ((93 + B[2 * i2 - 1]) * 121))) - E[1 * i2 + 1] * 81) * (B[2 * i2 - 1] * 93))) * D[1 * i2 - 1];
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

