#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 252], float B[restrict 228], float C[restrict 252], float D[restrict 228], float E[restrict 250]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 44; i1 <= 113; i1+=1) {
    for (int i3 = 61; i3 <= 92; i3+=1) {
      for (int i2 = 26; i2 <= 35; i2+=1) {
          A[1 * i3 - 1] = ((79 * B[1 * i3 + 1]) * (50 + A[1 * i2 + 1]) + (C[2 * i1 - 1] - 105 * D[2 * i1 + 1])) - (((((((C[1 * i3 - 1] + E[1 * i3 + 1]) + D[2 * i2 + 1]) - A[1 * i3 - 1] * 50) - (79 + E[1 * i1 + 1])) - (50 + 50)) - (105 - D[2 * i2 - 1] * 105) * ((105 - C[2 * i3 + 1]) * (50 * C[1 * i1 - 1]))) - ((D[2 * i3 - 1] + (B[2 * i3 - 1] - 79)) - (79 + A[2 * i3 - 1])));
      }
    }
  }
  for (int i3 = 61; i3 <= 92; i3+=1) {
    for (int i4 = 16; i4 <= 44; i4+=1) {
      for (int i2 = 26; i2 <= 35; i2+=1) {
          C[2 * i3 + 1] = (((C[1 * i4 - 1] * C[2 * i2 - 1] - A[2 * i2 - 1] * 105) - ((79 * D[2 * i4 - 1]) * A[2 * i4 - 1] - A[1 * i4 + 1])) + (50 + (105 + (C[2 * i3 + 1] * B[1 * i2 + 1] + ((E[1 * i4 - 1] - 79 * 105) + (A[1 * i4 + 1] + 50 * 79)))))) * (((E[2 * i4 - 1] - B[2 * i3 + 1]) * A[1 * i2 + 1]) * (((79 - 50) - (E[1 * i3 - 1] * E[1 * i2 - 1] - (A[1 * i4 - 1] - B[2 * i2 - 1]))) * E[2 * i3 - 1]));
      }
    }
  }
  for (int i1 = 44; i1 <= 113; i1+=1) {
    for (int i5 = 10; i5 <= 124; i5+=1) {
      for (int i4 = 16; i4 <= 44; i4+=1) {
          D[2 * i4 - 1] = (79 - ((E[1 * i1 - 1] - ((A[2 * i4 - 1] + B[1 * i1 - 1]) - 105)) - (A[1 * i4 + 1] - D[1 * i5 - 1]))) + ((50 * 105 - D[1 * i5 - 1]) - (E[1 * i5 - 1] * E[1 * i5 + 1] + (105 - (E[1 * i1 - 1] + A[1 * i4 - 1])))) * (((D[2 * i1 - 1] + 105) - (B[2 * i1 - 1] - E[2 * i5 + 1])) * D[1 * i5 + 1] + ((D[1 * i4 - 1] - (D[1 * i4 - 1] + ((79 + 105) - (105 + B[2 * i4 + 1])))) + C[1 * i4 - 1] * 50));
      }
    }
  }
  for (int i6 = 58; i6 <= 125; i6+=1) {
    for (int i3 = 61; i3 <= 92; i3+=1) {
      for (int i4 = 16; i4 <= 44; i4+=1) {
          D[1 * i6 - 1] = (105 * ((50 * (79 - D[1 * i3 - 1])) * (((50 - 79) + (D[1 * i3 + 1] - D[1 * i6 - 1])) - (C[1 * i6 + 1] + ((C[2 * i6 + 1] + B[2 * i3 - 1]) - 50)) * (B[1 * i3 - 1] * B[1 * i3 + 1])))) * ((D[1 * i3 + 1] * ((A[2 * i6 + 1] - A[1 * i3 - 1]) * E[1 * i3 + 1])) * 50) + (((B[1 * i4 - 1] * C[1 * i6 + 1] + (C[1 * i3 - 1] - C[1 * i6 - 1])) + (C[1 * i3 - 1] - (E[2 * i6 - 1] + B[2 * i3 + 1]))) - (105 + C[2 * i3 + 1]));
      }
    }
  }
  for (int i3 = 61; i3 <= 92; i3+=1) {
    for (int i1 = 44; i1 <= 113; i1+=1) {
      for (int i4 = 16; i4 <= 44; i4+=1) {
          C[1 * i4 + 1] = (50 * E[1 * i3 - 1] + (C[1 * i3 - 1] - (((C[1 * i3 - 1] - 50) - (B[2 * i4 + 1] - 79) * (C[2 * i4 + 1] * B[2 * i3 - 1])) - (B[2 * i1 + 1] - D[1 * i1 + 1]) * (79 + 79)))) * ((50 - D[2 * i4 + 1]) * (((E[1 * i3 - 1] + E[2 * i4 + 1]) + (((E[1 * i1 + 1] + D[1 * i1 + 1] * D[1 * i3 + 1]) - (50 + D[2 * i1 + 1] * C[1 * i4 - 1])) - D[1 * i1 + 1] * E[2 * i4 - 1])) * (A[1 * i4 + 1] - (D[1 * i1 + 1] - C[1 * i3 + 1]))));
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

