#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 229], float B[restrict 242], float C[restrict 242], float D[restrict 242], float E[restrict 242]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 13; i1 <= 34; i1+=1) {
    for (int i2 = 32; i2 <= 82; i2+=1) {
      for (int i3 = 96; i3 <= 112; i3+=1) {
          A[1 * i2 + 13] = (((B[2 * i2 + 7] + C[2 * i3 - 13]) + B[2 * i2 + 7] * (D[2 * i3 - 13] - E[2 * i3 + 13])) + (C[1 * i1 - 7] - 109)) * (E[2 * i1 + 13] + (E[1 * i1 + 13] + 72)) - (D[2 * i1 - 0] * (E[1 * i2 - 0] * E[2 * i2 - 7])) * (((90 + A[1 * i2 + 7]) * (E[2 * i3 - 7] - (((90 - 72) - 109) - (B[2 * i2 + 13] + ((C[2 * i1 - 7] - E[1 * i3 + 0]) + 109))))) * (72 * (90 - (B[2 * i1 + 13] - (D[2 * i2 + 13] - B[2 * i3 - 13])))));
      }
    }
  }
  for (int i4 = 37; i4 <= 65; i4+=1) {
    for (int i3 = 96; i3 <= 112; i3+=1) {
      for (int i5 = 15; i5 <= 117; i5+=1) {
          B[1 * i4 + 0] = (((E[2 * i4 - 13] * B[2 * i5 + 7]) * ((E[1 * i4 - 13] - A[2 * i4 + 7]) * 90) - (72 * 109 - B[2 * i4 + 7])) - (109 - D[1 * i4 + 0])) * ((109 + B[1 * i4 + 7]) * ((A[2 * i4 + 0] + (B[2 * i4 - 7] - 72)) * (((D[2 * i4 - 0] - 109) - E[2 * i3 + 0]) * ((90 * 109 - ((72 - B[2 * i5 + 0]) - C[2 * i5 - 7])) + (72 + A[1 * i3 - 13]) * ((109 + 72) + 72)))));
      }
    }
  }
  for (int i1 = 13; i1 <= 34; i1+=1) {
    for (int i4 = 37; i4 <= 65; i4+=1) {
      for (int i2 = 32; i2 <= 82; i2+=1) {
          E[2 * i1 + 0] = (C[2 * i2 + 0] + A[1 * i1 - 7]) - (((D[1 * i1 + 0] + ((72 + E[1 * i1 + 7]) + 90)) + ((B[2 * i2 - 13] - B[2 * i4 - 0] * B[1 * i1 + 0]) + (109 - ((90 + D[1 * i4 - 0]) + E[1 * i4 - 0])))) * (E[1 * i4 - 7] * E[2 * i1 + 0] + (A[2 * i4 - 0] - (E[1 * i2 - 13] - (E[2 * i4 - 0] - E[2 * i1 + 13])))) - ((B[1 * i1 + 0] * 109 + (109 - 90) * (D[1 * i4 - 13] + (72 - D[2 * i2 - 13]))) + (E[2 * i4 + 0] - B[1 * i4 - 7])));
      }
    }
  }
  for (int i1 = 13; i1 <= 34; i1+=1) {
    for (int i6 = 108; i6 <= 114; i6+=1) {
      for (int i3 = 96; i3 <= 112; i3+=1) {
          A[2 * i1 - 0] = (((90 + B[2 * i6 + 7]) * D[2 * i3 - 13] - B[2 * i6 - 7]) + ((E[1 * i3 - 7] + (((A[1 * i1 - 7] + (C[1 * i6 - 7] + 90)) + 109) + 72 * (A[1 * i1 + 13] + C[1 * i1 - 0]))) + D[2 * i1 + 13] * 109)) - ((90 * 72 + (90 - C[2 * i6 + 13])) + ((B[2 * i1 + 7] * ((E[2 * i3 - 13] * C[1 * i1 - 0]) * C[2 * i3 - 0])) * (90 - B[1 * i1 - 0]) + ((B[2 * i6 + 0] - C[1 * i6 - 0]) + (109 - A[2 * i1 - 0]))));
      }
    }
  }
  for (int i6 = 108; i6 <= 114; i6+=1) {
    for (int i2 = 32; i2 <= 82; i2+=1) {
      for (int i5 = 15; i5 <= 117; i5+=1) {
          E[2 * i5 + 7] = ((B[2 * i2 + 0] + (90 - (D[1 * i5 - 0] * E[1 * i5 - 7]) * C[1 * i6 - 0])) * (((A[2 * i6 - 0] + 109) - (109 + D[2 * i6 + 0])) - C[2 * i5 - 0])) * (((D[1 * i5 + 7] + (109 - D[2 * i6 + 13])) * (((72 + 90) + (((A[1 * i2 - 0] * 90) * E[2 * i6 + 7] + A[2 * i5 - 13]) + (72 - C[2 * i2 - 13]))) - ((E[1 * i2 - 13] - (109 + 90)) + A[2 * i2 - 0]))) * (A[1 * i6 - 13] - (E[1 * i6 + 0] - D[2 * i6 + 7])));
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

