#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 205], float B[restrict 220], float C[restrict 250], float D[restrict 250], float E[restrict 233]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 49; i1 <= 70; i1+=1) {
    for (int i2 = 46; i2 <= 54; i2+=1) {
      for (int i3 = 64; i3 <= 101; i3+=1) {
          A[1 * i2 + 15] = 110 * ((110 - (B[1 * i2 + 15] + C[1 * i2 - 16])) * (((B[2 * i2 - 15] * 121) * (121 - (((121 * 121 - ((D[2 * i2 - 2] + B[1 * i2 - 15]) - A[2 * i3 - 16])) + E[1 * i2 - 15] * 110) - 110)) + 110) + ((110 + (E[2 * i3 + 16] + E[1 * i1 + 16])) - C[1 * i3 + 2]) * ((A[1 * i1 - 2] - 121 * A[1 * i2 + 15]) * (57 * D[1 * i2 + 2] + E[1 * i1 - 16]) - (B[1 * i3 + 16] - B[1 * i2 - 2]))));
      }
    }
  }
  for (int i4 = 99; i4 <= 103; i4+=1) {
    for (int i1 = 49; i1 <= 70; i1+=1) {
      for (int i2 = 46; i2 <= 54; i2+=1) {
          E[1 * i4 + 2] = ((121 - (A[1 * i2 - 15] + (121 + 121))) + ((A[1 * i4 + 15] - D[1 * i1 - 2]) * ((E[1 * i1 + 2] * (57 - 57)) * A[1 * i2 - 2] + ((110 + B[2 * i2 - 15]) - E[1 * i1 + 15])) - E[1 * i1 + 16])) * ((A[1 * i4 - 2] - A[1 * i4 + 16]) + (110 - A[2 * i1 + 15])) + (((A[2 * i2 - 16] + B[1 * i1 + 2]) - A[2 * i4 - 2]) * (57 * 121) - (B[2 * i4 - 2] - (D[2 * i4 + 15] + E[2 * i2 - 16] * B[2 * i4 - 16])) * D[1 * i2 - 15]);
      }
    }
  }
  for (int i3 = 64; i3 <= 101; i3+=1) {
    for (int i5 = 84; i5 <= 117; i5+=1) {
      for (int i6 = 25; i6 <= 31; i6+=1) {
          C[1 * i5 + 15] = ((((C[1 * i6 + 15] + 110) + D[2 * i5 + 15]) - ((121 - E[1 * i5 + 16]) - (121 - 110))) + (57 + B[1 * i3 + 16])) - ((B[2 * i5 - 15] * ((E[1 * i3 - 16] * D[1 * i6 + 16] - B[2 * i3 + 15]) - (57 * E[2 * i5 - 2] - A[2 * i3 - 15])) - ((B[1 * i6 - 15] * (A[1 * i5 + 2] + (57 - 110)) - 110 * A[2 * i6 - 15]) - (110 - (D[1 * i6 - 2] - 121)))) - (B[1 * i6 - 16] * A[1 * i6 + 15]) * 57);
      }
    }
  }
  for (int i6 = 25; i6 <= 31; i6+=1) {
    for (int i5 = 84; i5 <= 117; i5+=1) {
      for (int i2 = 46; i2 <= 54; i2+=1) {
          C[1 * i5 + 2] = (57 * (B[2 * i6 + 2] + E[1 * i5 + 2])) * (C[1 * i2 + 15] - (C[1 * i2 - 16] - B[1 * i2 - 15]) * C[2 * i5 + 15]) + (((A[2 * i6 + 15] * ((B[1 * i2 - 15] + B[1 * i5 + 15]) - (C[2 * i2 + 16] - D[1 * i2 + 15]))) * 110 + (A[1 * i2 - 15] * (121 * E[1 * i2 + 2]) + ((C[2 * i2 - 16] - E[1 * i6 + 16]) + D[1 * i5 - 16]) * 121)) + (121 + ((E[1 * i5 + 16] + ((110 + A[1 * i6 + 15]) + (A[1 * i2 - 2] + 110))) * E[1 * i2 + 15]) * A[1 * i5 - 2]));
      }
    }
  }
  for (int i5 = 84; i5 <= 117; i5+=1) {
    for (int i6 = 25; i6 <= 31; i6+=1) {
      for (int i2 = 46; i2 <= 54; i2+=1) {
          D[1 * i5 - 16] = (110 * 57 - (121 - 121)) * D[2 * i6 - 15] - ((B[1 * i2 - 16] - ((D[2 * i5 + 2] + 57) + (B[1 * i6 + 2] + 110))) - (D[1 * i2 + 15] * (C[2 * i6 - 16] + C[1 * i5 + 16]) - ((121 * D[2 * i2 - 15] + ((A[1 * i2 - 16] + 110) - 110) * ((D[2 * i6 - 15] + 121) * ((110 + B[1 * i2 - 15]) * 121))) - E[2 * i2 + 2] * 57) * (B[1 * i2 - 16] * 110))) * D[2 * i2 - 16];
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

