#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 255], float B[restrict 255], float C[restrict 233], float D[restrict 255], float E[restrict 255]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 52; i1 <= 238; i1+=1) {
    for (int i2 = 17; i2 <= 195; i2+=1) {
      for (int i3 = 47; i3 <= 148; i3+=1) {
          A[1 * i2 + 16] = (((B[1 * i2 + 6] + C[1 * i3 - 16]) + B[1 * i2 + 6] * (D[1 * i3 - 16] - E[1 * i3 + 16])) + (C[1 * i1 - 6] - 110)) * (E[1 * i1 + 16] + (E[1 * i1 + 16] + 125)) - (D[1 * i1 - 14] * (E[1 * i2 - 14] * E[1 * i2 - 6])) * (((126 + A[1 * i2 + 6]) * (E[1 * i3 - 6] - (((126 - 125) - 110) - (B[1 * i2 + 16] + ((C[1 * i1 - 6] - E[1 * i3 + 14]) + 110))))) * (125 * (126 - (B[1 * i1 + 16] - (D[1 * i2 + 16] - B[1 * i3 - 16])))));
      }
    }
  }
  for (int i4 = 23; i4 <= 116; i4+=1) {
    for (int i3 = 47; i3 <= 148; i3+=1) {
      for (int i5 = 134; i5 <= 135; i5+=1) {
          B[1 * i4 + 14] = (((E[1 * i4 - 16] * B[1 * i5 + 6]) * ((E[1 * i4 - 16] - A[1 * i4 + 6]) * 126) - (125 * 110 - B[1 * i4 + 6])) - (110 - D[1 * i4 + 14])) * ((110 + B[1 * i4 + 6]) * ((A[1 * i4 + 14] + (B[1 * i4 - 6] - 125)) * (((D[1 * i4 - 14] - 110) - E[1 * i3 + 14]) * ((126 * 110 - ((125 - B[1 * i5 + 14]) - C[1 * i5 - 6])) + (125 + A[1 * i3 - 16]) * ((110 + 125) + 125)))));
      }
    }
  }
  for (int i1 = 52; i1 <= 238; i1+=1) {
    for (int i4 = 23; i4 <= 116; i4+=1) {
      for (int i2 = 17; i2 <= 195; i2+=1) {
          E[1 * i1 + 14] = (C[1 * i2 + 14] + A[1 * i1 - 6]) - (((D[1 * i1 + 14] + ((125 + E[1 * i1 + 6]) + 126)) + ((B[1 * i2 - 16] - B[1 * i4 - 14] * B[1 * i1 + 14]) + (110 - ((126 + D[1 * i4 - 14]) + E[1 * i4 - 14])))) * (E[1 * i4 - 6] * E[1 * i1 + 14] + (A[1 * i4 - 14] - (E[1 * i2 - 16] - (E[1 * i4 - 14] - E[1 * i1 + 16])))) - ((B[1 * i1 + 14] * 110 + (110 - 126) * (D[1 * i4 - 16] + (125 - D[1 * i2 - 16]))) + (E[1 * i4 + 14] - B[1 * i4 - 6])));
      }
    }
  }
  for (int i1 = 52; i1 <= 238; i1+=1) {
    for (int i6 = 166; i6 <= 208; i6+=1) {
      for (int i3 = 47; i3 <= 148; i3+=1) {
          A[1 * i1 - 14] = (((126 + B[1 * i6 + 6]) * D[1 * i3 - 16] - B[1 * i6 - 6]) + ((E[1 * i3 - 6] + (((A[1 * i1 - 6] + (C[1 * i6 - 6] + 126)) + 110) + 125 * (A[1 * i1 + 16] + C[1 * i1 - 14]))) + D[1 * i1 + 16] * 110)) - ((126 * 125 + (126 - C[1 * i6 + 16])) + ((B[1 * i1 + 6] * ((E[1 * i3 - 16] * C[1 * i1 - 14]) * C[1 * i3 - 14])) * (126 - B[1 * i1 - 14]) + ((B[1 * i6 + 14] - C[1 * i6 - 14]) + (110 - A[1 * i1 - 14]))));
      }
    }
  }
  for (int i6 = 166; i6 <= 208; i6+=1) {
    for (int i2 = 17; i2 <= 195; i2+=1) {
      for (int i5 = 134; i5 <= 135; i5+=1) {
          E[1 * i5 + 6] = ((B[1 * i2 + 14] + (126 - (D[1 * i5 - 14] * E[1 * i5 - 6]) * C[1 * i6 - 14])) * (((A[1 * i6 - 14] + 110) - (110 + D[1 * i6 + 14])) - C[1 * i5 - 14])) * (((D[1 * i5 + 6] + (110 - D[1 * i6 + 16])) * (((125 + 126) + (((A[1 * i2 - 14] * 126) * E[1 * i6 + 6] + A[1 * i5 - 16]) + (125 - C[1 * i2 - 16]))) - ((E[1 * i2 - 16] - (110 + 126)) + A[1 * i2 - 14]))) * (A[1 * i6 - 16] - (E[1 * i6 + 14] - D[1 * i6 + 6])));
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

