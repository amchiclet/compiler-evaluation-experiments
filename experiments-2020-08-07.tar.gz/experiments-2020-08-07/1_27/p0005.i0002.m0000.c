#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 131], float B[restrict 126], float C[restrict 246], float D[restrict 200], float E[restrict 186]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 81; i1 <= 88; i1+=1) {
    for (int i2 = 44; i2 <= 49; i2+=1) {
      for (int i3 = 42; i3 <= 55; i3+=1) {
          A[1 * i3 - 7] = ((49 * B[2 * i3 + 15]) * (65 + A[2 * i2 + 9]) + (C[1 * i1 - 9] - 58 * D[1 * i1 + 9])) - (((((((C[2 * i3 - 9] + E[2 * i3 + 9]) + D[1 * i2 + 15]) - A[1 * i3 - 9] * 65) - (49 + E[1 * i1 + 7])) - (65 + 65)) - (58 - D[1 * i2 - 7] * 58) * ((58 - C[1 * i3 + 9]) * (65 * C[1 * i1 - 15]))) - ((D[1 * i3 - 7] + (B[1 * i3 - 7] - 49)) - (49 + A[1 * i3 - 7])));
      }
    }
  }
  for (int i4 = 33; i4 <= 56; i4+=1) {
    for (int i3 = 42; i3 <= 55; i3+=1) {
      for (int i2 = 44; i2 <= 49; i2+=1) {
          C[1 * i3 + 9] = (((C[1 * i4 - 15] * C[1 * i2 - 15] - A[1 * i2 - 15] * 58) - ((49 * D[1 * i4 - 15]) * A[1 * i4 - 7] - A[2 * i4 + 15])) + (65 + (58 + (C[1 * i3 + 9] * B[2 * i2 + 7] + ((E[1 * i4 - 7] - 49 * 58) + (A[2 * i4 + 9] + 65 * 49)))))) * (((E[1 * i4 - 15] - B[1 * i3 + 15]) * A[2 * i2 + 15]) * (((49 - 65) - (E[2 * i3 - 9] * E[1 * i2 - 7] - (A[2 * i4 - 15] - B[1 * i2 - 9]))) * E[1 * i3 - 7]));
      }
    }
  }
  for (int i1 = 81; i1 <= 88; i1+=1) {
    for (int i5 = 48; i5 <= 96; i5+=1) {
      for (int i4 = 33; i4 <= 56; i4+=1) {
          D[1 * i4 - 7] = (49 - ((E[2 * i1 - 9] - ((A[1 * i4 - 15] + B[1 * i1 - 7]) - 58)) - (A[2 * i4 + 15] - D[1 * i5 - 15]))) + ((65 * 58 - D[2 * i5 - 15]) - (E[2 * i5 - 9] * E[1 * i5 + 9] + (58 - (E[2 * i1 - 7] + A[2 * i4 - 9])))) * (((D[1 * i1 - 7] + 58) - (B[1 * i1 - 7] - E[1 * i5 + 9])) * D[2 * i5 + 7] + ((D[2 * i4 - 15] - (D[1 * i4 - 15] + ((49 + 58) - (58 + B[1 * i4 + 7])))) + C[1 * i4 - 15] * 65));
      }
    }
  }
  for (int i6 = 71; i6 <= 115; i6+=1) {
    for (int i3 = 42; i3 <= 55; i3+=1) {
      for (int i4 = 33; i4 <= 56; i4+=1) {
          D[1 * i6 - 7] = (58 * ((65 * (49 - D[2 * i3 - 15])) * (((65 - 49) + (D[2 * i3 + 15] - D[1 * i6 - 9])) - (C[2 * i6 + 15] + ((C[1 * i6 + 15] + B[1 * i3 - 15]) - 65)) * (B[2 * i3 - 15] * B[1 * i3 + 15])))) * ((D[1 * i3 + 7] * ((A[1 * i6 + 15] - A[1 * i3 - 9]) * E[1 * i3 + 7])) * 65) + (((B[2 * i4 - 7] * C[1 * i6 + 7] + (C[1 * i3 - 15] - C[2 * i6 - 7])) + (C[1 * i3 - 7] - (E[1 * i6 - 7] + B[1 * i3 + 7]))) - (58 + C[1 * i3 + 15]));
      }
    }
  }
  for (int i3 = 42; i3 <= 55; i3+=1) {
    for (int i1 = 81; i1 <= 88; i1+=1) {
      for (int i4 = 33; i4 <= 56; i4+=1) {
          C[2 * i4 + 7] = (65 * E[2 * i3 - 9] + (C[1 * i3 - 9] - (((C[1 * i3 - 7] - 65) - (B[1 * i4 + 7] - 49) * (C[1 * i4 + 9] * B[1 * i3 - 7])) - (B[1 * i1 + 9] - D[1 * i1 + 15]) * (49 + 49)))) * ((65 - D[1 * i4 + 15]) * (((E[2 * i3 - 9] + E[1 * i4 + 7]) + (((E[2 * i1 + 9] + D[2 * i1 + 9] * D[2 * i3 + 7]) - (65 + D[1 * i1 + 15] * C[1 * i4 - 9])) - D[2 * i1 + 15] * E[1 * i4 - 7])) * (A[2 * i4 + 9] - (D[2 * i1 + 15] - C[2 * i3 + 15]))));
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

