#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 189], float B[restrict 189], float C[restrict 189], float D[restrict 191], float E[restrict 223]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 64; i1 <= 65; i1+=1) {
    for (int i2 = 69; i2 <= 77; i2+=1) {
      for (int i3 = 51; i3 <= 100; i3+=1) {
          A[1 * i2 + 16] = ((((B[2 * i2 + 16] + C[1 * i3 - 16]) - C[1 * i2 - 14]) + C[1 * i2 + 11]) - B[1 * i2 - 14] * A[1 * i3 + 11]) * (((C[1 * i1 - 16] + 117) - (D[1 * i1 + 16] * E[1 * i3 - 16] + 89)) + (((A[2 * i2 - 14] + E[1 * i3 - 16]) + C[1 * i3 - 11]) * (A[2 * i2 - 11] * (A[1 * i1 - 16] * 89)) - (((E[2 * i1 - 14] + E[1 * i1 - 11]) * C[1 * i2 - 14] - ((E[2 * i1 - 11] - A[1 * i2 - 11]) + (B[1 * i2 + 14] - C[1 * i3 + 14]) * ((D[1 * i1 - 11] + C[2 * i1 + 16]) - C[1 * i1 - 11]))) + C[1 * i1 - 14])));
      }
    }
  }
  for (int i2 = 69; i2 <= 77; i2+=1) {
    for (int i4 = 52; i4 <= 87; i4+=1) {
      for (int i5 = 70; i5 <= 86; i5+=1) {
          D[1 * i4 + 11] = (C[1 * i5 - 14] + A[2 * i4 + 14]) + (((117 - (B[1 * i4 - 16] + E[1 * i4 + 11])) * ((C[1 * i4 + 14] - 5 * 5) * (117 + D[1 * i5 + 11])) - (5 * (E[1 * i5 + 14] - A[1 * i2 - 16])) * B[1 * i5 + 14]) - (((D[1 * i4 - 11] - 5 * A[2 * i5 - 14]) - (C[2 * i5 + 16] * E[1 * i2 + 16] + 89)) - B[1 * i4 + 14] * (89 * (117 * 89 - (A[1 * i5 + 11] + D[2 * i2 - 16])))) * (C[2 * i2 - 14] + 117));
      }
    }
  }
  for (int i4 = 52; i4 <= 87; i4+=1) {
    for (int i2 = 69; i2 <= 77; i2+=1) {
      for (int i5 = 70; i5 <= 86; i5+=1) {
          E[1 * i4 - 16] = ((((A[2 * i2 + 16] + (5 - E[1 * i4 - 16])) - C[1 * i5 + 11]) - 5 * 89) + ((D[2 * i4 - 16] - E[1 * i4 + 16]) * ((117 * C[1 * i5 - 11] + D[1 * i2 - 16]) + D[2 * i4 + 16] * ((B[1 * i4 + 16] - 89) + E[2 * i5 - 14])) + (C[1 * i2 - 11] - C[1 * i4 - 11]))) * ((C[1 * i5 - 11] - D[1 * i5 + 14]) + D[1 * i5 - 16]) - D[1 * i2 - 14] * (((E[2 * i4 - 16] + 5) + (D[1 * i4 + 14] - 5)) + C[2 * i2 + 16] * (5 + A[1 * i2 - 14]));
      }
    }
  }
  for (int i4 = 52; i4 <= 87; i4+=1) {
    for (int i6 = 69; i6 <= 103; i6+=1) {
      for (int i1 = 64; i1 <= 65; i1+=1) {
          E[1 * i1 + 11] = (E[1 * i1 + 14] + ((C[1 * i4 + 11] - (E[2 * i6 + 16] + 5 * E[2 * i1 - 14])) + ((E[1 * i1 - 11] + 89) + (C[1 * i4 + 11] + (C[1 * i1 - 14] - 117)) * (5 - E[1 * i4 - 14])))) * (((((D[1 * i1 - 11] + (89 - C[2 * i4 - 11])) + C[1 * i1 - 16]) - (5 + (D[2 * i1 + 14] - 117))) - C[1 * i1 + 14]) * ((E[1 * i1 + 11] * C[1 * i6 + 16] + ((5 + (B[1 * i4 - 16] + D[1 * i4 + 14])) + 117)) + 117 * D[1 * i6 - 11]));
      }
    }
  }
  for (int i5 = 70; i5 <= 86; i5+=1) {
    for (int i3 = 51; i3 <= 100; i3+=1) {
      for (int i2 = 69; i2 <= 77; i2+=1) {
          B[2 * i2 + 14] = (((((D[1 * i3 + 11] + D[1 * i5 + 11]) - 117) * A[1 * i5 + 11]) * ((E[1 * i5 + 11] - A[2 * i5 + 16]) + E[2 * i5 + 14] * D[1 * i3 + 14]) - C[1 * i2 - 16]) + (A[2 * i5 - 11] + ((((89 - B[1 * i2 + 14]) + 89 * 117) + (D[1 * i5 + 14] + (D[1 * i2 - 11] - B[2 * i5 + 16]))) + ((117 + C[1 * i2 - 14]) - 117)))) + (((E[2 * i3 - 14] * C[1 * i3 + 11]) * (E[2 * i3 + 14] + 117)) * (C[1 * i2 - 16] * B[2 * i5 + 11]) - (A[1 * i5 + 16] - 89));
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

