#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 222], float B[restrict 242], float C[restrict 232], float D[restrict 242], float E[restrict 182]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 3; i1 <= 7; i1+=1) {
    for (int i2 = 107; i2 <= 118; i2+=1) {
      for (int i3 = 66; i3 <= 73; i3+=1) {
          A[2 * i2 - 15] = 105 + 64;
          B[2 * i2 + 5] = A[1 * i3 + 15] + A[2 * i1 + 15];
          A[2 * i1 + 15] = 64 - 105;
      }
    }
  }
  for (int i3 = 66; i3 <= 73; i3+=1) {
    for (int i2 = 107; i2 <= 118; i2+=1) {
      for (int i4 = 49; i4 <= 108; i4+=1) {
          C[1 * i4 + 15] = B[2 * i4 - 9] * D[1 * i2 + 9];
          C[2 * i2 - 5] = B[1 * i3 - 9] - D[1 * i3 + 15];
          D[2 * i2 + 5] = B[1 * i4 + 5] * 105;
      }
    }
  }
  for (int i3 = 66; i3 <= 73; i3+=1) {
    for (int i1 = 3; i1 <= 7; i1+=1) {
      for (int i5 = 10; i5 <= 93; i5+=1) {
          B[2 * i3 - 9] = 64 - C[2 * i5 - 15];
          E[2 * i5 - 5] = 14 * 14;
          B[2 * i1 + 9] = A[2 * i3 - 9] * 14;
      }
    }
  }
  for (int i4 = 49; i4 <= 108; i4+=1) {
    for (int i5 = 10; i5 <= 93; i5+=1) {
      for (int i2 = 107; i2 <= 118; i2+=1) {
          D[1 * i4 + 9] = D[2 * i2 + 5] * A[2 * i2 - 15];
          E[1 * i4 + 15] = 105 + A[2 * i4 + 5];
          D[2 * i5 - 15] = B[2 * i4 + 15] - B[2 * i5 - 5];
      }
    }
  }
  for (int i1 = 3; i1 <= 7; i1+=1) {
    for (int i3 = 66; i3 <= 73; i3+=1) {
      for (int i5 = 10; i5 <= 93; i5+=1) {
          C[1 * i5 + 9] = D[2 * i3 + 9] - 105;
          D[1 * i3 - 5] = D[2 * i3 + 9] + 14;
          B[2 * i3 - 5] = A[1 * i5 - 5] + C[1 * i3 + 9];
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

