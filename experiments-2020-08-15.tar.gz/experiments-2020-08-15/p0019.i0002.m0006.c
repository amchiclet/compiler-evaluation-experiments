#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 226], float B[restrict 236], float C[restrict 208], float D[restrict 230], float E[restrict 229]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i3 = 32; i3 <= 120; i3+=1) {
    for (int i1 = 19; i1 <= 122; i1+=1) {
      for (int i2 = 28; i2 <= 61; i2+=1) {
          A[1 * i2 + 15] = 74 - 74;
          B[2 * i3 - 5] = C[2 * i2 + 5] + A[2 * i2 - 5];
          D[1 * i1 - 5] = C[2 * i2 - 5] + A[1 * i3 - 16];
      }
    }
  }
  for (int i1 = 19; i1 <= 122; i1+=1) {
    for (int i4 = 28; i4 <= 111; i4+=1) {
      for (int i5 = 30; i5 <= 86; i5+=1) {
          D[2 * i5 + 16] = B[2 * i5 + 5] - D[1 * i1 + 16];
          D[2 * i5 + 5] = D[2 * i1 - 15] * E[1 * i1 + 5];
          D[2 * i4 - 15] = B[2 * i4 - 15] * 126;
      }
    }
  }
  for (int i5 = 30; i5 <= 86; i5+=1) {
    for (int i3 = 32; i3 <= 120; i3+=1) {
      for (int i1 = 19; i1 <= 122; i1+=1) {
          C[1 * i1 - 5] = A[2 * i3 - 15] * 23;
          E[1 * i5 + 5] = E[1 * i1 - 16] * 126;
          B[1 * i3 + 15] = D[1 * i1 - 15] * 126;
      }
    }
  }
  for (int i2 = 28; i2 <= 61; i2+=1) {
    for (int i4 = 28; i4 <= 111; i4+=1) {
      for (int i1 = 19; i1 <= 122; i1+=1) {
          E[2 * i2 - 15] = E[2 * i4 + 5] + 74;
          E[2 * i1 - 16] = A[2 * i4 - 5] + 126;
          E[2 * i4 - 5] = C[2 * i4 - 15] + A[1 * i1 - 5];
      }
    }
  }
  for (int i3 = 32; i3 <= 120; i3+=1) {
    for (int i5 = 30; i5 <= 86; i5+=1) {
      for (int i2 = 28; i2 <= 61; i2+=1) {
          A[2 * i2 + 5] = E[2 * i5 - 5] * E[2 * i2 - 16];
          A[1 * i5 + 15] = A[1 * i2 - 16] * A[1 * i2 + 16];
          B[1 * i5 + 16] = D[2 * i2 + 15] + A[1 * i5 + 5];
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

