#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 238], float B[restrict 238], float C[restrict 230], float D[restrict 238], float E[restrict 238]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i2 = 6; i2 <= 113; i2+=1) {
    for (int i3 = 35; i3 <= 91; i3+=1) {
      for (int i1 = 32; i1 <= 106; i1+=1) {
          A[2 * i2 + 3] = B[2 * i2 + 11] + C[2 * i3 - 11];
          B[1 * i3 + 11] = C[2 * i2 + 3] - A[2 * i1 + 11];
          D[2 * i2 - 3] = 65 + D[2 * i1 + 11];
      }
    }
  }
  for (int i1 = 32; i1 <= 106; i1+=1) {
    for (int i3 = 35; i3 <= 91; i3+=1) {
      for (int i2 = 6; i2 <= 113; i2+=1) {
          D[1 * i1 + 3] = B[2 * i2 + 11] - B[2 * i1 - 11];
          E[1 * i2 + 11] = E[2 * i1 + 11] - 67;
          B[1 * i1 + 11] = C[2 * i1 - 11] * 91;
      }
    }
  }
  for (int i2 = 6; i2 <= 113; i2+=1) {
    for (int i1 = 32; i1 <= 106; i1+=1) {
      for (int i4 = 15; i4 <= 52; i4+=1) {
          D[2 * i4 + 11] = E[2 * i2 - 11] - D[2 * i1 + 11];
          E[2 * i4 + 11] = 67 - B[1 * i2 + 11];
          D[2 * i2 + 11] = 65 - 91;
      }
    }
  }
  for (int i5 = 19; i5 <= 37; i5+=1) {
    for (int i1 = 32; i1 <= 106; i1+=1) {
      for (int i4 = 15; i4 <= 52; i4+=1) {
          C[1 * i4 + 3] = 65 * A[1 * i4 - 3];
          E[2 * i4 + 11] = D[2 * i1 - 11] + A[2 * i1 - 11];
          D[1 * i4 + 11] = D[2 * i5 - 3] * D[2 * i5 + 11];
      }
    }
  }
  for (int i2 = 6; i2 <= 113; i2+=1) {
    for (int i6 = 95; i6 <= 182; i6+=1) {
      for (int i4 = 15; i4 <= 52; i4+=1) {
          D[1 * i6 + 11] = C[1 * i4 - 11] + 65;
          A[2 * i2 + 11] = E[2 * i2 + 11] * C[2 * i2 - 11];
          A[1 * i4 - 11] = B[2 * i4 + 11] - 67;
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

