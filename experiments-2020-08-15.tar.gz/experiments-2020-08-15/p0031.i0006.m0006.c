#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 211], float B[restrict 159], float C[restrict 241], float D[restrict 147], float E[restrict 235]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i3 = 109; i3 <= 111; i3+=1) {
    for (int i2 = 13; i2 <= 101; i2+=1) {
      for (int i1 = 16; i1 <= 73; i1+=1) {
          A[1 * i3 - 11] = B[1 * i1 + 12] + C[1 * i2 - 11];
          B[1 * i2 + 11] = B[2 * i1 + 12] * 93;
          C[1 * i2 - 11] = D[2 * i1 - 0] * E[1 * i2 + 11];
      }
    }
  }
  for (int i3 = 109; i3 <= 111; i3+=1) {
    for (int i2 = 13; i2 <= 101; i2+=1) {
      for (int i1 = 16; i1 <= 73; i1+=1) {
          A[1 * i3 + 11] = D[1 * i1 + 12] + 93;
          B[1 * i3 - 12] = 49 * 93;
          E[2 * i3 + 12] = A[1 * i3 - 0] * C[2 * i1 - 11];
      }
    }
  }
  for (int i4 = 69; i4 <= 196; i4+=1) {
    for (int i2 = 13; i2 <= 101; i2+=1) {
      for (int i1 = 16; i1 <= 73; i1+=1) {
          E[1 * i4 + 12] = E[2 * i1 + 11] + C[2 * i2 + 11];
          C[1 * i4 + 11] = 62 + 93;
          C[1 * i1 - 12] = 93 + 49;
      }
    }
  }
  for (int i2 = 13; i2 <= 101; i2+=1) {
    for (int i5 = 13; i5 <= 120; i5+=1) {
      for (int i1 = 16; i1 <= 73; i1+=1) {
          B[1 * i5 - 12] = 62 - 93;
          C[1 * i1 + 11] = 62 * D[1 * i1 - 12];
          C[2 * i5 + 0] = C[1 * i1 + 0] + C[1 * i2 + 0];
      }
    }
  }
  for (int i1 = 16; i1 <= 73; i1+=1) {
    for (int i6 = 13; i6 <= 105; i6+=1) {
      for (int i5 = 13; i5 <= 120; i5+=1) {
          A[1 * i6 + 11] = D[1 * i5 + 11] * C[1 * i1 + 12];
          A[1 * i6 - 12] = 62 - E[1 * i5 - 11];
          A[2 * i6 + 0] = 62 * A[1 * i1 - 11];
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

