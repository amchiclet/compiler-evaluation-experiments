#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 250], float B[restrict 252], float C[restrict 212], float D[restrict 234], float E[restrict 255]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 51; i1 <= 104; i1+=1) {
    for (int i3 = 45; i3 <= 109; i3+=1) {
      for (int i2 = 93; i2 <= 121; i2+=1) {
          A[2 * i3 - 12] = B[2 * i1 - 7] * C[2 * i3 - 7];
          D[2 * i1 - 9] = 34 + D[2 * i2 - 9];
          A[1 * i1 - 7] = D[2 * i3 - 12] + C[1 * i2 + 9];
      }
    }
  }
  for (int i4 = 46; i4 <= 112; i4+=1) {
    for (int i1 = 51; i1 <= 104; i1+=1) {
      for (int i5 = 16; i5 <= 79; i5+=1) {
          D[2 * i4 + 9] = D[2 * i1 + 7] - 22;
          D[2 * i1 - 12] = 22 * B[2 * i4 - 7];
          B[2 * i1 + 7] = C[1 * i1 + 12] + 34;
      }
    }
  }
  for (int i2 = 93; i2 <= 121; i2+=1) {
    for (int i3 = 45; i3 <= 109; i3+=1) {
      for (int i4 = 46; i4 <= 112; i4+=1) {
          E[2 * i2 - 7] = 76 * 34;
          A[2 * i2 + 7] = 34 * 22;
          E[2 * i2 + 12] = 22 - 22;
      }
    }
  }
  for (int i5 = 16; i5 <= 79; i5+=1) {
    for (int i1 = 51; i1 <= 104; i1+=1) {
      for (int i2 = 93; i2 <= 121; i2+=1) {
          A[2 * i2 + 7] = 76 - C[1 * i5 + 12];
          B[2 * i2 + 9] = B[2 * i1 - 7] * 34;
          C[2 * i5 + 9] = D[2 * i1 + 9] - B[2 * i5 + 9];
      }
    }
  }
  for (int i6 = 60; i6 <= 73; i6+=1) {
    for (int i3 = 45; i3 <= 109; i3+=1) {
      for (int i5 = 16; i5 <= 79; i5+=1) {
          E[2 * i5 + 9] = 34 - C[1 * i5 - 12];
          C[1 * i5 + 9] = 34 + E[1 * i3 + 12];
          C[2 * i6 + 7] = 76 * E[2 * i6 + 12];
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

