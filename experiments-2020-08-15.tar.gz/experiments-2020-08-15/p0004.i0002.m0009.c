#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 241], float B[restrict 220], float C[restrict 254], float D[restrict 241], float E[restrict 133]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i2 = 21; i2 <= 30; i2+=1) {
    for (int i1 = 101; i1 <= 190; i1+=1) {
      for (int i3 = 16; i3 <= 116; i3+=1) {
          A[1 * i2 - 8] = 62 + 1;
          B[1 * i2 + 15] = A[2 * i3 + 8] + A[1 * i1 + 8];
          A[1 * i1 + 8] = 1 - 62;
      }
    }
  }
  for (int i4 = 47; i4 <= 62; i4+=1) {
    for (int i2 = 21; i2 <= 30; i2+=1) {
      for (int i3 = 16; i3 <= 116; i3+=1) {
          C[2 * i4 + 8] = B[1 * i4 - 13] * D[2 * i2 + 13];
          C[1 * i2 - 15] = B[2 * i3 - 13] - D[2 * i3 + 8];
          D[1 * i2 + 15] = B[2 * i4 + 15] * 62;
      }
    }
  }
  for (int i3 = 16; i3 <= 116; i3+=1) {
    for (int i1 = 101; i1 <= 190; i1+=1) {
      for (int i5 = 20; i5 <= 120; i5+=1) {
          B[1 * i3 - 13] = 1 - C[1 * i5 - 8];
          E[1 * i5 - 15] = 61 * 61;
          B[1 * i1 + 13] = A[1 * i3 - 13] * 61;
      }
    }
  }
  for (int i4 = 47; i4 <= 62; i4+=1) {
    for (int i5 = 20; i5 <= 120; i5+=1) {
      for (int i2 = 21; i2 <= 30; i2+=1) {
          D[2 * i4 + 13] = D[1 * i2 + 15] * A[1 * i2 - 8];
          E[2 * i4 + 8] = 62 + A[1 * i4 + 15];
          D[1 * i5 - 8] = B[1 * i4 + 8] - B[1 * i5 - 15];
      }
    }
  }
  for (int i3 = 16; i3 <= 116; i3+=1) {
    for (int i1 = 101; i1 <= 190; i1+=1) {
      for (int i5 = 20; i5 <= 120; i5+=1) {
          C[2 * i5 + 13] = D[1 * i3 + 13] - 62;
          D[2 * i3 - 15] = D[1 * i3 + 13] + 61;
          B[1 * i3 - 15] = A[2 * i5 - 15] + C[2 * i3 + 13];
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

