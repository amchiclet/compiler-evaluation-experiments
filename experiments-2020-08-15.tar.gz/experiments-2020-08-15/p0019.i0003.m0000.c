#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 232], float B[restrict 224], float C[restrict 226], float D[restrict 232], float E[restrict 216]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i3 = 85; i3 <= 208; i3+=1) {
    for (int i1 = 40; i1 <= 77; i1+=1) {
      for (int i2 = 132; i2 <= 216; i2+=1) {
          A[1 * i2 + 15] = 29 - 29;
          B[1 * i3 - 9] = C[1 * i2 + 9] + A[1 * i2 - 9];
          D[1 * i1 - 9] = C[1 * i2 - 9] + A[1 * i3 - 1];
      }
    }
  }
  for (int i4 = 120; i4 <= 137; i4+=1) {
    for (int i1 = 40; i1 <= 77; i1+=1) {
      for (int i5 = 58; i5 <= 74; i5+=1) {
          D[1 * i5 + 1] = B[1 * i5 + 9] - D[1 * i1 + 1];
          D[1 * i5 + 9] = D[1 * i1 - 15] * E[1 * i1 + 9];
          D[1 * i4 - 15] = B[1 * i4 - 15] * 50;
      }
    }
  }
  for (int i5 = 58; i5 <= 74; i5+=1) {
    for (int i1 = 40; i1 <= 77; i1+=1) {
      for (int i3 = 85; i3 <= 208; i3+=1) {
          C[1 * i1 - 9] = A[1 * i3 - 15] * 82;
          E[1 * i5 + 9] = E[1 * i1 - 1] * 50;
          B[1 * i3 + 15] = D[1 * i1 - 15] * 50;
      }
    }
  }
  for (int i4 = 120; i4 <= 137; i4+=1) {
    for (int i2 = 132; i2 <= 216; i2+=1) {
      for (int i1 = 40; i1 <= 77; i1+=1) {
          E[1 * i2 - 15] = E[1 * i4 + 9] + 29;
          E[1 * i1 - 1] = A[1 * i4 - 9] + 50;
          E[1 * i4 - 9] = C[1 * i4 - 15] + A[1 * i1 - 9];
      }
    }
  }
  for (int i2 = 132; i2 <= 216; i2+=1) {
    for (int i3 = 85; i3 <= 208; i3+=1) {
      for (int i5 = 58; i5 <= 74; i5+=1) {
          A[1 * i2 + 9] = E[1 * i5 - 9] * E[1 * i2 - 1];
          A[1 * i5 + 15] = A[1 * i2 - 1] * A[1 * i2 + 1];
          B[1 * i5 + 1] = D[1 * i2 + 15] + A[1 * i5 + 9];
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

