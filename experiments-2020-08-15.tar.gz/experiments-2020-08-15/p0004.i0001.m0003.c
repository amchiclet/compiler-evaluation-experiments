#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 251], float B[restrict 251], float C[restrict 240], float D[restrict 244], float E[restrict 240]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i2 = 62; i2 <= 104; i2+=1) {
    for (int i1 = 22; i1 <= 145; i1+=1) {
      for (int i3 = 37; i3 <= 39; i3+=1) {
          A[2 * i2 - 5] = 116 + 114;
          B[2 * i2 + 16] = A[2 * i3 + 5] + A[1 * i1 + 5];
          A[1 * i1 + 5] = 114 - 116;
      }
    }
  }
  for (int i4 = 74; i4 <= 117; i4+=1) {
    for (int i2 = 62; i2 <= 104; i2+=1) {
      for (int i3 = 37; i3 <= 39; i3+=1) {
          C[2 * i4 + 5] = B[1 * i4 - 9] * D[2 * i2 + 9];
          C[2 * i2 - 16] = B[2 * i3 - 9] - D[2 * i3 + 5];
          D[1 * i2 + 16] = B[2 * i4 + 16] * 116;
      }
    }
  }
  for (int i1 = 22; i1 <= 145; i1+=1) {
    for (int i3 = 37; i3 <= 39; i3+=1) {
      for (int i5 = 30; i5 <= 114; i5+=1) {
          B[1 * i3 - 9] = 114 - C[1 * i5 - 5];
          E[1 * i5 - 16] = 6 * 6;
          B[1 * i1 + 9] = A[2 * i3 - 9] * 6;
      }
    }
  }
  for (int i2 = 62; i2 <= 104; i2+=1) {
    for (int i4 = 74; i4 <= 117; i4+=1) {
      for (int i5 = 30; i5 <= 114; i5+=1) {
          D[2 * i4 + 9] = D[2 * i2 + 16] * A[2 * i2 - 5];
          E[2 * i4 + 5] = 116 + A[2 * i4 + 16];
          D[1 * i5 - 5] = B[1 * i4 + 5] - B[2 * i5 - 16];
      }
    }
  }
  for (int i5 = 30; i5 <= 114; i5+=1) {
    for (int i1 = 22; i1 <= 145; i1+=1) {
      for (int i3 = 37; i3 <= 39; i3+=1) {
          C[2 * i5 + 9] = D[2 * i3 + 9] - 116;
          D[2 * i3 - 16] = D[2 * i3 + 9] + 6;
          B[2 * i3 - 16] = A[2 * i5 - 16] + C[2 * i3 + 9];
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

