#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 137], float B[restrict 229], float C[restrict 212], float D[restrict 180], float E[restrict 137]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 16; i1 <= 65; i1+=1) {
    for (int i2 = 40; i2 <= 41; i2+=1) {
      for (int i3 = 144; i3 <= 222; i3+=1) {
          A[1 * i2 + 9] = B[2 * i2 + 11] + C[1 * i3 - 11];
          B[1 * i3 + 6] = C[2 * i2 + 9] - A[2 * i1 + 6];
          D[2 * i2 - 9] = 1 + D[1 * i1 + 6];
      }
    }
  }
  for (int i3 = 144; i3 <= 222; i3+=1) {
    for (int i1 = 16; i1 <= 65; i1+=1) {
      for (int i2 = 40; i2 <= 41; i2+=1) {
          D[1 * i1 + 9] = B[1 * i2 + 11] - B[2 * i1 - 11];
          E[1 * i2 + 11] = E[2 * i1 + 6] - 102;
          B[1 * i1 + 11] = C[1 * i1 - 11] * 12;
      }
    }
  }
  for (int i4 = 16; i4 <= 18; i4+=1) {
    for (int i2 = 40; i2 <= 41; i2+=1) {
      for (int i1 = 16; i1 <= 65; i1+=1) {
          D[1 * i4 + 11] = E[1 * i2 - 6] - D[2 * i1 + 11];
          E[2 * i4 + 11] = 102 - B[1 * i2 + 11];
          D[2 * i2 + 6] = 1 - 12;
      }
    }
  }
  for (int i4 = 16; i4 <= 18; i4+=1) {
    for (int i5 = 24; i5 <= 79; i5+=1) {
      for (int i1 = 16; i1 <= 65; i1+=1) {
          C[1 * i4 + 9] = 1 * A[1 * i4 - 9];
          E[1 * i4 + 11] = D[2 * i1 - 11] + A[1 * i1 - 11];
          D[1 * i4 + 11] = D[1 * i5 - 9] * D[2 * i5 + 6];
      }
    }
  }
  for (int i2 = 40; i2 <= 41; i2+=1) {
    for (int i6 = 150; i6 <= 168; i6+=1) {
      for (int i4 = 16; i4 <= 18; i4+=1) {
          D[1 * i6 + 11] = C[1 * i4 - 6] + 1;
          A[1 * i2 + 11] = E[1 * i2 + 6] * C[1 * i2 - 6];
          A[1 * i4 - 11] = B[1 * i4 + 6] - 102;
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

