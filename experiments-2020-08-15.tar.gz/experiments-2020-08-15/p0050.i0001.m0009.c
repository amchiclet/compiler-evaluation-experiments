#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 97], float B[restrict 130], float C[restrict 176], float D[restrict 141], float E[restrict 226]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i2 = 57; i2 <= 76; i2+=1) {
    for (int i3 = 84; i3 <= 107; i3+=1) {
      for (int i1 = 13; i1 <= 46; i1+=1) {
          A[1 * i3 - 11] = B[1 * i1 - 9] * C[1 * i3 - 9];
          D[1 * i1 - 2] = 113 + D[1 * i2 - 2];
          A[2 * i1 - 9] = D[1 * i3 - 11] + C[2 * i2 + 2];
      }
    }
  }
  for (int i5 = 66; i5 <= 73; i5+=1) {
    for (int i1 = 13; i1 <= 46; i1+=1) {
      for (int i4 = 80; i4 <= 138; i4+=1) {
          D[1 * i4 + 2] = D[1 * i1 + 9] - 14;
          D[1 * i1 - 11] = 14 * B[1 * i4 - 9];
          B[1 * i1 + 9] = C[2 * i1 + 11] + 113;
      }
    }
  }
  for (int i2 = 57; i2 <= 76; i2+=1) {
    for (int i4 = 80; i4 <= 138; i4+=1) {
      for (int i3 = 84; i3 <= 107; i3+=1) {
          E[1 * i2 - 9] = 101 * 113;
          A[1 * i2 + 9] = 113 * 14;
          E[1 * i2 + 11] = 14 - 14;
      }
    }
  }
  for (int i5 = 66; i5 <= 73; i5+=1) {
    for (int i2 = 57; i2 <= 76; i2+=1) {
      for (int i1 = 13; i1 <= 46; i1+=1) {
          A[1 * i2 + 9] = 101 - C[2 * i5 + 11];
          B[1 * i2 + 2] = B[1 * i1 - 9] * 113;
          C[1 * i5 + 2] = D[1 * i1 + 2] - B[1 * i5 + 2];
      }
    }
  }
  for (int i5 = 66; i5 <= 73; i5+=1) {
    for (int i3 = 84; i3 <= 107; i3+=1) {
      for (int i6 = 89; i6 <= 166; i6+=1) {
          E[1 * i5 + 2] = 113 - C[2 * i5 - 11];
          C[2 * i5 + 2] = 113 + E[2 * i3 + 11];
          C[1 * i6 + 9] = 101 * E[1 * i6 + 11];
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

