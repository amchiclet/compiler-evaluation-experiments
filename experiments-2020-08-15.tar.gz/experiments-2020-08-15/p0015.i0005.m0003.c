#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 213], float B[restrict 224], float C[restrict 177], float D[restrict 225], float E[restrict 213]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 64; i1 <= 104; i1+=1) {
    for (int i3 = 58; i3 <= 71; i3+=1) {
      for (int i2 = 48; i2 <= 80; i2+=1) {
          A[1 * i2 + 16] = B[2 * i2 + 15] + C[1 * i3 - 15];
          B[2 * i3 + 4] = C[2 * i2 + 16] - A[2 * i1 + 4];
          D[2 * i2 - 16] = 22 + D[1 * i1 + 4];
      }
    }
  }
  for (int i3 = 58; i3 <= 71; i3+=1) {
    for (int i1 = 64; i1 <= 104; i1+=1) {
      for (int i2 = 48; i2 <= 80; i2+=1) {
          D[2 * i1 + 16] = B[1 * i2 + 15] - B[2 * i1 - 15];
          E[2 * i2 + 15] = E[2 * i1 + 4] - 50;
          B[2 * i1 + 15] = C[1 * i1 - 15] * 45;
      }
    }
  }
  for (int i1 = 64; i1 <= 104; i1+=1) {
    for (int i2 = 48; i2 <= 80; i2+=1) {
      for (int i4 = 10; i4 <= 67; i4+=1) {
          D[1 * i4 + 15] = E[1 * i2 - 4] - D[2 * i1 + 15];
          E[2 * i4 + 15] = 50 - B[2 * i2 + 15];
          D[2 * i2 + 4] = 22 - 45;
      }
    }
  }
  for (int i5 = 95; i5 <= 103; i5+=1) {
    for (int i1 = 64; i1 <= 104; i1+=1) {
      for (int i4 = 10; i4 <= 67; i4+=1) {
          C[2 * i4 + 16] = 22 * A[2 * i4 - 16];
          E[1 * i4 + 15] = D[2 * i1 - 15] + A[1 * i1 - 15];
          D[2 * i4 + 15] = D[1 * i5 - 16] * D[2 * i5 + 4];
      }
    }
  }
  for (int i2 = 48; i2 <= 80; i2+=1) {
    for (int i4 = 10; i4 <= 67; i4+=1) {
      for (int i6 = 59; i6 <= 80; i6+=1) {
          D[2 * i6 + 15] = C[2 * i4 - 4] + 22;
          A[1 * i2 + 15] = E[1 * i2 + 4] * C[1 * i2 - 4];
          A[2 * i4 - 15] = B[1 * i4 + 4] - 50;
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

