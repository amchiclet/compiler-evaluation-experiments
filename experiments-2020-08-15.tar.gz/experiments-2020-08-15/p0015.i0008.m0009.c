#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 151], float B[restrict 240], float C[restrict 239], float D[restrict 241], float E[restrict 208]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 25; i1 <= 67; i1+=1) {
    for (int i2 = 48; i2 <= 112; i2+=1) {
      for (int i3 = 125; i3 <= 147; i3+=1) {
          A[1 * i2 + 14] = B[2 * i2 + 15] + C[1 * i3 - 15];
          B[1 * i3 + 16] = C[2 * i2 + 14] - A[2 * i1 + 16];
          D[2 * i2 - 14] = 41 + D[1 * i1 + 16];
      }
    }
  }
  for (int i2 = 48; i2 <= 112; i2+=1) {
    for (int i1 = 25; i1 <= 67; i1+=1) {
      for (int i3 = 125; i3 <= 147; i3+=1) {
          D[1 * i1 + 14] = B[1 * i2 + 15] - B[2 * i1 - 15];
          E[1 * i2 + 15] = E[2 * i1 + 16] - 83;
          B[1 * i1 + 15] = C[1 * i1 - 15] * 36;
      }
    }
  }
  for (int i2 = 48; i2 <= 112; i2+=1) {
    for (int i1 = 25; i1 <= 67; i1+=1) {
      for (int i4 = 81; i4 <= 96; i4+=1) {
          D[1 * i4 + 15] = E[1 * i2 - 16] - D[2 * i1 + 15];
          E[2 * i4 + 15] = 83 - B[1 * i2 + 15];
          D[2 * i2 + 16] = 41 - 36;
      }
    }
  }
  for (int i5 = 33; i5 <= 75; i5+=1) {
    for (int i4 = 81; i4 <= 96; i4+=1) {
      for (int i1 = 25; i1 <= 67; i1+=1) {
          C[1 * i4 + 14] = 41 * A[1 * i4 - 14];
          E[1 * i4 + 15] = D[2 * i1 - 15] + A[1 * i1 - 15];
          D[1 * i4 + 15] = D[1 * i5 - 14] * D[2 * i5 + 16];
      }
    }
  }
  for (int i4 = 81; i4 <= 96; i4+=1) {
    for (int i6 = 85; i6 <= 196; i6+=1) {
      for (int i2 = 48; i2 <= 112; i2+=1) {
          D[1 * i6 + 15] = C[1 * i4 - 16] + 41;
          A[1 * i2 + 15] = E[1 * i2 + 16] * C[1 * i2 - 16];
          A[1 * i4 - 15] = B[1 * i4 + 16] - 83;
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

