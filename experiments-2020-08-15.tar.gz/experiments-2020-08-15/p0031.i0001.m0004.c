#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 230], float B[restrict 235], float C[restrict 246], float D[restrict 235], float E[restrict 246]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 125; i1 <= 230; i1+=1) {
    for (int i2 = 93; i2 <= 165; i2+=1) {
      for (int i3 = 22; i3 <= 214; i3+=1) {
          A[1 * i3 - 15] = B[1 * i1 + 4] + C[1 * i2 - 15];
          B[1 * i2 + 15] = B[1 * i1 + 4] * 126;
          C[1 * i2 - 15] = D[1 * i1 - 6] * E[1 * i2 + 15];
      }
    }
  }
  for (int i3 = 22; i3 <= 214; i3+=1) {
    for (int i2 = 93; i2 <= 165; i2+=1) {
      for (int i1 = 125; i1 <= 230; i1+=1) {
          A[1 * i3 + 15] = D[1 * i1 + 4] + 126;
          B[1 * i3 - 4] = 96 * 126;
          E[1 * i3 + 4] = A[1 * i3 - 6] * C[1 * i1 - 15];
      }
    }
  }
  for (int i4 = 1; i4 <= 44; i4+=1) {
    for (int i1 = 125; i1 <= 230; i1+=1) {
      for (int i2 = 93; i2 <= 165; i2+=1) {
          E[1 * i4 + 4] = E[1 * i1 + 15] + C[1 * i2 + 15];
          C[1 * i4 + 15] = 123 + 126;
          C[1 * i1 - 4] = 126 + 96;
      }
    }
  }
  for (int i2 = 93; i2 <= 165; i2+=1) {
    for (int i5 = 24; i5 <= 39; i5+=1) {
      for (int i1 = 125; i1 <= 230; i1+=1) {
          B[1 * i5 - 4] = 123 - 126;
          C[1 * i1 + 15] = 123 * D[1 * i1 - 4];
          C[1 * i5 + 6] = C[1 * i1 + 6] + C[1 * i2 + 6];
      }
    }
  }
  for (int i5 = 24; i5 <= 39; i5+=1) {
    for (int i6 = 54; i6 <= 158; i6+=1) {
      for (int i1 = 125; i1 <= 230; i1+=1) {
          A[1 * i6 + 15] = D[1 * i5 + 15] * C[1 * i1 + 4];
          A[1 * i6 - 4] = 123 - E[1 * i5 - 15];
          A[1 * i6 + 6] = 123 * A[1 * i1 - 15];
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

