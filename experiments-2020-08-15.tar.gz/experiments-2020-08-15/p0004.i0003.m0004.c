#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 237], float B[restrict 255], float C[restrict 251], float D[restrict 255], float E[restrict 101]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i3 = 64; i3 <= 65; i3+=1) {
    for (int i1 = 40; i1 <= 128; i1+=1) {
      for (int i2 = 31; i2 <= 126; i2+=1) {
          A[2 * i2 - 16] = 51 + 107;
          B[2 * i2 + 2] = A[1 * i3 + 16] + A[1 * i1 + 16];
          A[1 * i1 + 16] = 107 - 51;
      }
    }
  }
  for (int i2 = 31; i2 <= 126; i2+=1) {
    for (int i3 = 64; i3 <= 65; i3+=1) {
      for (int i4 = 36; i4 <= 60; i4+=1) {
          C[1 * i4 + 16] = B[1 * i4 - 15] * D[1 * i2 + 15];
          C[2 * i2 - 2] = B[1 * i3 - 15] - D[1 * i3 + 16];
          D[1 * i2 + 2] = B[1 * i4 + 2] * 51;
      }
    }
  }
  for (int i5 = 29; i5 <= 102; i5+=1) {
    for (int i3 = 64; i3 <= 65; i3+=1) {
      for (int i1 = 40; i1 <= 128; i1+=1) {
          B[1 * i3 - 15] = 107 - C[1 * i5 - 16];
          E[1 * i5 - 2] = 80 * 80;
          B[1 * i1 + 15] = A[2 * i3 - 15] * 80;
      }
    }
  }
  for (int i2 = 31; i2 <= 126; i2+=1) {
    for (int i4 = 36; i4 <= 60; i4+=1) {
      for (int i5 = 29; i5 <= 102; i5+=1) {
          D[1 * i4 + 15] = D[2 * i2 + 2] * A[2 * i2 - 16];
          E[1 * i4 + 16] = 51 + A[2 * i4 + 2];
          D[1 * i5 - 16] = B[1 * i4 + 16] - B[2 * i5 - 2];
      }
    }
  }
  for (int i3 = 64; i3 <= 65; i3+=1) {
    for (int i5 = 29; i5 <= 102; i5+=1) {
      for (int i1 = 40; i1 <= 128; i1+=1) {
          C[1 * i5 + 15] = D[2 * i3 + 15] - 51;
          D[1 * i3 - 2] = D[2 * i3 + 15] + 80;
          B[2 * i3 - 2] = A[1 * i5 - 2] + C[1 * i3 + 15];
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

