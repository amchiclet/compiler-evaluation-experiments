#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 204], float B[restrict 204], float C[restrict 236], float D[restrict 214], float E[restrict 231]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i3 = 66; i3 <= 74; i3+=1) {
    for (int i1 = 58; i1 <= 104; i1+=1) {
      for (int i2 = 15; i2 <= 93; i2+=1) {
          A[2 * i3 - 0] = B[1 * i1 - 5] * C[1 * i3 - 5];
          D[2 * i1 - 5] = 117 + D[2 * i2 - 5];
          A[2 * i1 - 5] = D[1 * i3 - 0] + C[2 * i2 + 5];
      }
    }
  }
  for (int i5 = 57; i5 <= 91; i5+=1) {
    for (int i1 = 58; i1 <= 104; i1+=1) {
      for (int i4 = 196; i4 <= 200; i4+=1) {
          D[1 * i4 + 5] = D[2 * i1 + 5] - 93;
          D[2 * i1 - 0] = 93 * B[1 * i4 - 5];
          B[1 * i1 + 5] = C[2 * i1 + 0] + 117;
      }
    }
  }
  for (int i2 = 15; i2 <= 93; i2+=1) {
    for (int i3 = 66; i3 <= 74; i3+=1) {
      for (int i4 = 196; i4 <= 200; i4+=1) {
          E[1 * i2 - 5] = 94 * 117;
          A[1 * i2 + 5] = 117 * 93;
          E[1 * i2 + 0] = 93 - 93;
      }
    }
  }
  for (int i5 = 57; i5 <= 91; i5+=1) {
    for (int i2 = 15; i2 <= 93; i2+=1) {
      for (int i1 = 58; i1 <= 104; i1+=1) {
          A[1 * i2 + 5] = 94 - C[2 * i5 + 0];
          B[2 * i2 + 5] = B[2 * i1 - 5] * 117;
          C[2 * i5 + 5] = D[2 * i1 + 5] - B[2 * i5 + 5];
      }
    }
  }
  for (int i6 = 55; i6 <= 115; i6+=1) {
    for (int i3 = 66; i3 <= 74; i3+=1) {
      for (int i5 = 57; i5 <= 91; i5+=1) {
          E[1 * i5 + 5] = 117 - C[2 * i5 - 0];
          C[2 * i5 + 5] = 117 + E[2 * i3 + 0];
          C[2 * i6 + 5] = 94 * E[2 * i6 + 0];
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

