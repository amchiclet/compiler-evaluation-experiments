#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 179], float B[restrict 191], float C[restrict 241], float D[restrict 191], float E[restrict 237]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i3 = 71; i3 <= 73; i3+=1) {
    for (int i1 = 48; i1 <= 93; i1+=1) {
      for (int i2 = 20; i2 <= 44; i2+=1) {
          A[2 * i3 - 8] = B[2 * i1 + 4] + C[2 * i2 - 8];
          B[2 * i2 + 8] = B[1 * i1 + 4] * 95;
          C[2 * i2 - 8] = D[1 * i1 - 2] * E[2 * i2 + 8];
      }
    }
  }
  for (int i3 = 71; i3 <= 73; i3+=1) {
    for (int i2 = 20; i2 <= 44; i2+=1) {
      for (int i1 = 48; i1 <= 93; i1+=1) {
          A[2 * i3 + 8] = D[2 * i1 + 4] + 95;
          B[2 * i3 - 4] = 66 * 95;
          E[1 * i3 + 4] = A[2 * i3 - 2] * C[1 * i1 - 8];
      }
    }
  }
  for (int i2 = 20; i2 <= 44; i2+=1) {
    for (int i4 = 9; i4 <= 116; i4+=1) {
      for (int i1 = 48; i1 <= 93; i1+=1) {
          E[2 * i4 + 4] = E[1 * i1 + 8] + C[1 * i2 + 8];
          C[2 * i4 + 8] = 21 + 95;
          C[2 * i1 - 4] = 95 + 66;
      }
    }
  }
  for (int i2 = 20; i2 <= 44; i2+=1) {
    for (int i5 = 48; i5 <= 73; i5+=1) {
      for (int i1 = 48; i1 <= 93; i1+=1) {
          B[2 * i5 - 4] = 21 - 95;
          C[2 * i1 + 8] = 21 * D[2 * i1 - 4];
          C[1 * i5 + 2] = C[2 * i1 + 2] + C[2 * i2 + 2];
      }
    }
  }
  for (int i1 = 48; i1 <= 93; i1+=1) {
    for (int i6 = 30; i6 <= 31; i6+=1) {
      for (int i5 = 48; i5 <= 73; i5+=1) {
          A[2 * i6 + 8] = D[2 * i5 + 8] * C[2 * i1 + 4];
          A[2 * i6 - 4] = 21 - E[2 * i5 - 8];
          A[1 * i6 + 2] = 21 * A[2 * i1 - 8];
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

