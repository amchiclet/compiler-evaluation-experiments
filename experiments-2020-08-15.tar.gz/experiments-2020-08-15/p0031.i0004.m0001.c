#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 239], float B[restrict 191], float C[restrict 189], float D[restrict 177], float E[restrict 187]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 86; i1 <= 91; i1+=1) {
    for (int i2 = 9; i2 <= 35; i2+=1) {
      for (int i3 = 10; i3 <= 17; i3+=1) {
          A[2 * i3 - 4] = B[2 * i1 + 8] + C[2 * i2 - 4];
          B[2 * i2 + 4] = B[2 * i1 + 8] * 101;
          C[1 * i2 - 4] = D[2 * i1 - 6] * E[1 * i2 + 4];
      }
    }
  }
  for (int i3 = 10; i3 <= 17; i3+=1) {
    for (int i1 = 86; i1 <= 91; i1+=1) {
      for (int i2 = 9; i2 <= 35; i2+=1) {
          A[1 * i3 + 4] = D[1 * i1 + 8] + 101;
          B[2 * i3 - 8] = 77 * 101;
          E[2 * i3 + 8] = A[2 * i3 - 6] * C[2 * i1 - 4];
      }
    }
  }
  for (int i2 = 9; i2 <= 35; i2+=1) {
    for (int i1 = 86; i1 <= 91; i1+=1) {
      for (int i4 = 22; i4 <= 51; i4+=1) {
          E[2 * i4 + 8] = E[2 * i1 + 4] + C[2 * i2 + 4];
          C[2 * i4 + 4] = 128 + 101;
          C[1 * i1 - 8] = 101 + 77;
      }
    }
  }
  for (int i1 = 86; i1 <= 91; i1+=1) {
    for (int i5 = 54; i5 <= 91; i5+=1) {
      for (int i2 = 9; i2 <= 35; i2+=1) {
          B[2 * i5 - 8] = 128 - 101;
          C[2 * i1 + 4] = 128 * D[2 * i1 - 8];
          C[2 * i5 + 6] = C[2 * i1 + 6] + C[2 * i2 + 6];
      }
    }
  }
  for (int i5 = 54; i5 <= 91; i5+=1) {
    for (int i6 = 108; i6 <= 116; i6+=1) {
      for (int i1 = 86; i1 <= 91; i1+=1) {
          A[2 * i6 + 4] = D[1 * i5 + 4] * C[1 * i1 + 8];
          A[2 * i6 - 8] = 128 - E[2 * i5 - 4];
          A[2 * i6 + 6] = 128 * A[1 * i1 - 4];
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

