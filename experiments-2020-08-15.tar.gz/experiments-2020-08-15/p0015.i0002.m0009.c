#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 181], float B[restrict 181], float C[restrict 253], float D[restrict 179], float E[restrict 177]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 22; i1 <= 89; i1+=1) {
    for (int i3 = 109; i3 <= 128; i3+=1) {
      for (int i2 = 38; i2 <= 88; i2+=1) {
          A[2 * i2 + 2] = B[1 * i2 + 4] + C[2 * i3 - 4];
          B[1 * i3 + 0] = C[1 * i2 + 2] - A[1 * i1 + 0];
          D[1 * i2 - 2] = 84 + D[2 * i1 + 0];
      }
    }
  }
  for (int i3 = 109; i3 <= 128; i3+=1) {
    for (int i1 = 22; i1 <= 89; i1+=1) {
      for (int i2 = 38; i2 <= 88; i2+=1) {
          D[1 * i1 + 2] = B[2 * i2 + 4] - B[1 * i1 - 4];
          E[1 * i2 + 4] = E[1 * i1 + 0] - 99;
          B[1 * i1 + 4] = C[2 * i1 - 4] * 9;
      }
    }
  }
  for (int i4 = 4; i4 <= 37; i4+=1) {
    for (int i2 = 38; i2 <= 88; i2+=1) {
      for (int i1 = 22; i1 <= 89; i1+=1) {
          D[2 * i4 + 4] = E[2 * i2 - 0] - D[1 * i1 + 4];
          E[1 * i4 + 4] = 99 - B[1 * i2 + 4];
          D[1 * i2 + 0] = 84 - 9;
      }
    }
  }
  for (int i4 = 4; i4 <= 37; i4+=1) {
    for (int i1 = 22; i1 <= 89; i1+=1) {
      for (int i5 = 60; i5 <= 78; i5+=1) {
          C[1 * i4 + 2] = 84 * A[1 * i4 - 2];
          E[2 * i4 + 4] = D[1 * i1 - 4] + A[2 * i1 - 4];
          D[1 * i4 + 4] = D[2 * i5 - 2] * D[1 * i5 + 0];
      }
    }
  }
  for (int i2 = 38; i2 <= 88; i2+=1) {
    for (int i4 = 4; i4 <= 37; i4+=1) {
      for (int i6 = 89; i6 <= 158; i6+=1) {
          D[1 * i6 + 4] = C[1 * i4 - 0] + 84;
          A[2 * i2 + 4] = E[2 * i2 + 0] * C[2 * i2 - 0];
          A[1 * i4 - 4] = B[2 * i4 + 0] - 99;
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

