#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 185], float B[restrict 188], float C[restrict 167], float D[restrict 182], float E[restrict 173]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 29; i1 <= 83; i1+=1) {
    for (int i3 = 71; i3 <= 78; i3+=1) {
      for (int i2 = 40; i2 <= 57; i2+=1) {
          A[2 * i2 + 12] = 121 - 121;
          B[1 * i3 - 0] = C[1 * i2 + 0] + A[1 * i2 - 0];
          D[2 * i1 - 0] = C[1 * i2 - 0] + A[2 * i3 - 15];
      }
    }
  }
  for (int i4 = 24; i4 <= 77; i4+=1) {
    for (int i1 = 29; i1 <= 83; i1+=1) {
      for (int i5 = 39; i5 <= 86; i5+=1) {
          D[1 * i5 + 15] = B[1 * i5 + 0] - D[2 * i1 + 15];
          D[1 * i5 + 0] = D[1 * i1 - 12] * E[2 * i1 + 0];
          D[1 * i4 - 12] = B[1 * i4 - 12] * 33;
      }
    }
  }
  for (int i5 = 39; i5 <= 86; i5+=1) {
    for (int i3 = 71; i3 <= 78; i3+=1) {
      for (int i1 = 29; i1 <= 83; i1+=1) {
          C[2 * i1 - 0] = A[1 * i3 - 12] * 16;
          E[2 * i5 + 0] = E[2 * i1 - 15] * 33;
          B[2 * i3 + 12] = D[2 * i1 - 12] * 33;
      }
    }
  }
  for (int i1 = 29; i1 <= 83; i1+=1) {
    for (int i2 = 40; i2 <= 57; i2+=1) {
      for (int i4 = 24; i4 <= 77; i4+=1) {
          E[1 * i2 - 12] = E[1 * i4 + 0] + 121;
          E[1 * i1 - 15] = A[1 * i4 - 0] + 33;
          E[1 * i4 - 0] = C[1 * i4 - 12] + A[2 * i1 - 0];
      }
    }
  }
  for (int i3 = 71; i3 <= 78; i3+=1) {
    for (int i5 = 39; i5 <= 86; i5+=1) {
      for (int i2 = 40; i2 <= 57; i2+=1) {
          A[1 * i2 + 0] = E[1 * i5 - 0] * E[1 * i2 - 15];
          A[2 * i5 + 12] = A[2 * i2 - 15] * A[2 * i2 + 15];
          B[2 * i5 + 15] = D[1 * i2 + 12] + A[2 * i5 + 0];
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

