#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 213], float B[restrict 213], float C[restrict 177], float D[restrict 177], float E[restrict 180]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i3 = 40; i3 <= 106; i3+=1) {
    for (int i1 = 31; i1 <= 73; i1+=1) {
      for (int i2 = 33; i2 <= 33; i2+=1) {
          A[2 * i2 + 0] = 4 - 4;
          B[2 * i3 - 3] = C[2 * i2 + 3] + A[2 * i2 - 3];
          D[2 * i1 - 3] = C[2 * i2 - 3] + A[2 * i3 - 16];
      }
    }
  }
  for (int i5 = 44; i5 <= 64; i5+=1) {
    for (int i1 = 31; i1 <= 73; i1+=1) {
      for (int i4 = 19; i4 <= 88; i4+=1) {
          D[2 * i5 + 16] = B[2 * i5 + 3] - D[2 * i1 + 16];
          D[2 * i5 + 3] = D[2 * i1 - 0] * E[2 * i1 + 3];
          D[2 * i4 - 0] = B[2 * i4 - 0] * 60;
      }
    }
  }
  for (int i3 = 40; i3 <= 106; i3+=1) {
    for (int i1 = 31; i1 <= 73; i1+=1) {
      for (int i5 = 44; i5 <= 64; i5+=1) {
          C[2 * i1 - 3] = A[2 * i3 - 0] * 72;
          E[2 * i5 + 3] = E[2 * i1 - 16] * 60;
          B[2 * i3 + 0] = D[2 * i1 - 0] * 60;
      }
    }
  }
  for (int i4 = 19; i4 <= 88; i4+=1) {
    for (int i1 = 31; i1 <= 73; i1+=1) {
      for (int i2 = 33; i2 <= 33; i2+=1) {
          E[2 * i2 - 0] = E[2 * i4 + 3] + 4;
          E[2 * i1 - 16] = A[2 * i4 - 3] + 60;
          E[2 * i4 - 3] = C[2 * i4 - 0] + A[2 * i1 - 3];
      }
    }
  }
  for (int i3 = 40; i3 <= 106; i3+=1) {
    for (int i5 = 44; i5 <= 64; i5+=1) {
      for (int i2 = 33; i2 <= 33; i2+=1) {
          A[2 * i2 + 3] = E[2 * i5 - 3] * E[2 * i2 - 16];
          A[2 * i5 + 0] = A[2 * i2 - 16] * A[2 * i2 + 16];
          B[2 * i5 + 16] = D[2 * i2 + 0] + A[2 * i5 + 3];
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

