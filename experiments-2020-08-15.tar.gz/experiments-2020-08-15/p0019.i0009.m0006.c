#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 246], float B[restrict 216], float C[restrict 181], float D[restrict 148], float E[restrict 223]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i3 = 15; i3 <= 88; i3+=1) {
    for (int i2 = 23; i2 <= 116; i2+=1) {
      for (int i1 = 13; i1 <= 67; i1+=1) {
          A[2 * i2 + 10] = 0 - 0;
          B[1 * i3 - 2] = C[1 * i2 + 2] + A[1 * i2 - 2];
          D[2 * i1 - 2] = C[1 * i2 - 2] + A[2 * i3 - 13];
      }
    }
  }
  for (int i4 = 94; i4 <= 95; i4+=1) {
    for (int i1 = 13; i1 <= 67; i1+=1) {
      for (int i5 = 77; i5 <= 101; i5+=1) {
          D[1 * i5 + 13] = B[1 * i5 + 2] - D[2 * i1 + 13];
          D[1 * i5 + 2] = D[2 * i1 - 10] * E[2 * i1 + 2];
          D[1 * i4 - 10] = B[2 * i4 - 10] * 105;
      }
    }
  }
  for (int i3 = 15; i3 <= 88; i3+=1) {
    for (int i1 = 13; i1 <= 67; i1+=1) {
      for (int i5 = 77; i5 <= 101; i5+=1) {
          C[2 * i1 - 2] = A[2 * i3 - 10] * 22;
          E[2 * i5 + 2] = E[2 * i1 - 13] * 105;
          B[2 * i3 + 10] = D[2 * i1 - 10] * 105;
      }
    }
  }
  for (int i1 = 13; i1 <= 67; i1+=1) {
    for (int i2 = 23; i2 <= 116; i2+=1) {
      for (int i4 = 94; i4 <= 95; i4+=1) {
          E[2 * i2 - 10] = E[2 * i4 + 2] + 0;
          E[2 * i1 - 13] = A[1 * i4 - 2] + 105;
          E[2 * i4 - 2] = C[2 * i4 - 10] + A[2 * i1 - 2];
      }
    }
  }
  for (int i5 = 77; i5 <= 101; i5+=1) {
    for (int i3 = 15; i3 <= 88; i3+=1) {
      for (int i2 = 23; i2 <= 116; i2+=1) {
          A[2 * i2 + 2] = E[1 * i5 - 2] * E[1 * i2 - 13];
          A[2 * i5 + 10] = A[2 * i2 - 13] * A[2 * i2 + 13];
          B[2 * i5 + 13] = D[1 * i2 + 10] + A[2 * i5 + 2];
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

