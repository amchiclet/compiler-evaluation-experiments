#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 229], float B[restrict 230], float C[restrict 197], float D[restrict 97], float E[restrict 196]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i3 = 53; i3 <= 121; i3+=1) {
    for (int i2 = 15; i2 <= 33; i2+=1) {
      for (int i1 = 17; i1 <= 21; i1+=1) {
          A[2 * i3 - 14] = B[2 * i1 + 13] + C[2 * i2 - 14];
          B[2 * i2 + 14] = B[1 * i1 + 13] * 99;
          C[1 * i2 - 14] = D[1 * i1 - 14] * E[1 * i2 + 14];
      }
    }
  }
  for (int i3 = 53; i3 <= 121; i3+=1) {
    for (int i1 = 17; i1 <= 21; i1+=1) {
      for (int i2 = 15; i2 <= 33; i2+=1) {
          A[1 * i3 + 14] = D[1 * i1 + 13] + 99;
          B[2 * i3 - 13] = 12 * 99;
          E[1 * i3 + 13] = A[2 * i3 - 14] * C[1 * i1 - 14];
      }
    }
  }
  for (int i2 = 15; i2 <= 33; i2+=1) {
    for (int i4 = 85; i4 <= 91; i4+=1) {
      for (int i1 = 17; i1 <= 21; i1+=1) {
          E[2 * i4 + 13] = E[1 * i1 + 14] + C[1 * i2 + 14];
          C[2 * i4 + 14] = 9 + 99;
          C[1 * i1 - 13] = 99 + 12;
      }
    }
  }
  for (int i5 = 31; i5 <= 82; i5+=1) {
    for (int i2 = 15; i2 <= 33; i2+=1) {
      for (int i1 = 17; i1 <= 21; i1+=1) {
          B[2 * i5 - 13] = 9 - 99;
          C[2 * i1 + 14] = 9 * D[2 * i1 - 13];
          C[1 * i5 + 14] = C[2 * i1 + 14] + C[2 * i2 + 14];
      }
    }
  }
  for (int i6 = 84; i6 <= 105; i6+=1) {
    for (int i1 = 17; i1 <= 21; i1+=1) {
      for (int i5 = 31; i5 <= 82; i5+=1) {
          A[2 * i6 + 14] = D[1 * i5 + 14] * C[1 * i1 + 13];
          A[2 * i6 - 13] = 9 - E[2 * i5 - 14];
          A[1 * i6 + 14] = 9 * A[1 * i1 - 14];
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

