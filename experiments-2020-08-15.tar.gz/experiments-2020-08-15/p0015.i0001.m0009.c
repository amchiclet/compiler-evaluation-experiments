#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 212], float B[restrict 180], float C[restrict 212], float D[restrict 234], float E[restrict 176]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i2 = 41; i2 <= 56; i2+=1) {
    for (int i3 = 10; i3 <= 28; i3+=1) {
      for (int i1 = 16; i1 <= 110; i1+=1) {
          A[2 * i2 + 16] = B[1 * i2 + 9] + C[2 * i3 - 9];
          B[1 * i3 + 13] = C[1 * i2 + 16] - A[1 * i1 + 13];
          D[1 * i2 - 16] = 71 + D[2 * i1 + 13];
      }
    }
  }
  for (int i3 = 10; i3 <= 28; i3+=1) {
    for (int i1 = 16; i1 <= 110; i1+=1) {
      for (int i2 = 41; i2 <= 56; i2+=1) {
          D[1 * i1 + 16] = B[2 * i2 + 9] - B[1 * i1 - 9];
          E[1 * i2 + 9] = E[1 * i1 + 13] - 120;
          B[1 * i1 + 9] = C[2 * i1 - 9] * 117;
      }
    }
  }
  for (int i2 = 41; i2 <= 56; i2+=1) {
    for (int i1 = 16; i1 <= 110; i1+=1) {
      for (int i4 = 80; i4 <= 83; i4+=1) {
          D[2 * i4 + 9] = E[2 * i2 - 13] - D[1 * i1 + 9];
          E[1 * i4 + 9] = 120 - B[1 * i2 + 9];
          D[1 * i2 + 13] = 71 - 117;
      }
    }
  }
  for (int i5 = 14; i5 <= 115; i5+=1) {
    for (int i1 = 16; i1 <= 110; i1+=1) {
      for (int i4 = 80; i4 <= 83; i4+=1) {
          C[1 * i4 + 16] = 71 * A[1 * i4 - 16];
          E[2 * i4 + 9] = D[1 * i1 - 9] + A[2 * i1 - 9];
          D[1 * i4 + 9] = D[2 * i5 - 16] * D[1 * i5 + 13];
      }
    }
  }
  for (int i6 = 28; i6 <= 144; i6+=1) {
    for (int i4 = 80; i4 <= 83; i4+=1) {
      for (int i2 = 41; i2 <= 56; i2+=1) {
          D[1 * i6 + 9] = C[1 * i4 - 13] + 71;
          A[2 * i2 + 9] = E[2 * i2 + 13] * C[2 * i2 - 13];
          A[1 * i4 - 9] = B[2 * i4 + 13] - 120;
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

