#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 194], float B[restrict 230], float C[restrict 230], float D[restrict 194], float E[restrict 244]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i3 = 14; i3 <= 27; i3+=1) {
    for (int i2 = 65; i2 <= 66; i2+=1) {
      for (int i1 = 19; i1 <= 22; i1+=1) {
          A[1 * i2 + 7] = 35 - 35;
          B[1 * i3 - 7] = C[1 * i2 + 7] + A[1 * i2 - 7];
          D[1 * i1 - 7] = C[1 * i2 - 7] + A[1 * i3 - 6];
      }
    }
  }
  for (int i4 = 56; i4 <= 118; i4+=1) {
    for (int i1 = 19; i1 <= 22; i1+=1) {
      for (int i5 = 141; i5 <= 186; i5+=1) {
          D[1 * i5 + 6] = B[1 * i5 + 7] - D[1 * i1 + 6];
          D[1 * i5 + 7] = D[2 * i1 - 7] * E[1 * i1 + 7];
          D[1 * i4 - 7] = B[2 * i4 - 7] * 57;
      }
    }
  }
  for (int i3 = 14; i3 <= 27; i3+=1) {
    for (int i5 = 141; i5 <= 186; i5+=1) {
      for (int i1 = 19; i1 <= 22; i1+=1) {
          C[1 * i1 - 7] = A[2 * i3 - 7] * 91;
          E[1 * i5 + 7] = E[1 * i1 - 6] * 57;
          B[1 * i3 + 7] = D[1 * i1 - 7] * 57;
      }
    }
  }
  for (int i2 = 65; i2 <= 66; i2+=1) {
    for (int i4 = 56; i4 <= 118; i4+=1) {
      for (int i1 = 19; i1 <= 22; i1+=1) {
          E[2 * i2 - 7] = E[2 * i4 + 7] + 35;
          E[2 * i1 - 6] = A[1 * i4 - 7] + 57;
          E[2 * i4 - 7] = C[2 * i4 - 7] + A[1 * i1 - 7];
      }
    }
  }
  for (int i3 = 14; i3 <= 27; i3+=1) {
    for (int i5 = 141; i5 <= 186; i5+=1) {
      for (int i2 = 65; i2 <= 66; i2+=1) {
          A[2 * i2 + 7] = E[1 * i5 - 7] * E[1 * i2 - 6];
          A[1 * i5 + 7] = A[1 * i2 - 6] * A[1 * i2 + 6];
          B[1 * i5 + 6] = D[1 * i2 + 7] + A[1 * i5 + 7];
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

