#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 213], float B[restrict 216], float C[restrict 185], float D[restrict 209], float E[restrict 116]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i2 = 92; i2 <= 98; i2+=1) {
    for (int i1 = 53; i1 <= 66; i1+=1) {
      for (int i3 = 56; i3 <= 66; i3+=1) {
          A[2 * i2 - 15] = 97 + 87;
          B[2 * i2 + 12] = A[1 * i3 + 15] + A[2 * i1 + 15];
          A[2 * i1 + 15] = 87 - 97;
      }
    }
  }
  for (int i2 = 92; i2 <= 98; i2+=1) {
    for (int i3 = 56; i3 <= 66; i3+=1) {
      for (int i4 = 19; i4 <= 100; i4+=1) {
          C[1 * i4 + 15] = B[2 * i4 - 3] * D[1 * i2 + 3];
          C[2 * i2 - 12] = B[1 * i3 - 3] - D[1 * i3 + 15];
          D[2 * i2 + 12] = B[1 * i4 + 12] * 97;
      }
    }
  }
  for (int i1 = 53; i1 <= 66; i1+=1) {
    for (int i3 = 56; i3 <= 66; i3+=1) {
      for (int i5 = 13; i5 <= 26; i5+=1) {
          B[2 * i3 - 3] = 87 - C[2 * i5 - 15];
          E[2 * i5 - 12] = 68 * 68;
          B[2 * i1 + 3] = A[2 * i3 - 3] * 68;
      }
    }
  }
  for (int i4 = 19; i4 <= 100; i4+=1) {
    for (int i5 = 13; i5 <= 26; i5+=1) {
      for (int i2 = 92; i2 <= 98; i2+=1) {
          D[1 * i4 + 3] = D[2 * i2 + 12] * A[2 * i2 - 15];
          E[1 * i4 + 15] = 97 + A[2 * i4 + 12];
          D[2 * i5 - 15] = B[2 * i4 + 15] - B[2 * i5 - 12];
      }
    }
  }
  for (int i3 = 56; i3 <= 66; i3+=1) {
    for (int i1 = 53; i1 <= 66; i1+=1) {
      for (int i5 = 13; i5 <= 26; i5+=1) {
          C[1 * i5 + 3] = D[2 * i3 + 3] - 97;
          D[1 * i3 - 12] = D[2 * i3 + 3] + 68;
          B[2 * i3 - 12] = A[1 * i5 - 12] + C[1 * i3 + 3];
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

