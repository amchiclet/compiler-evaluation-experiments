#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 122], float B[restrict 180], float C[restrict 242], float D[restrict 242], float E[restrict 238]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i2 = 106; i2 <= 108; i2+=1) {
    for (int i1 = 35; i1 <= 58; i1+=1) {
      for (int i3 = 28; i3 <= 30; i3+=1) {
          A[1 * i2 - 5] = 101 + 9;
          B[1 * i2 + 9] = A[1 * i3 + 5] + A[2 * i1 + 5];
          A[2 * i1 + 5] = 9 - 101;
      }
    }
  }
  for (int i3 = 28; i3 <= 30; i3+=1) {
    for (int i2 = 106; i2 <= 108; i2+=1) {
      for (int i4 = 44; i4 <= 87; i4+=1) {
          C[1 * i4 + 5] = B[2 * i4 - 10] * D[1 * i2 + 10];
          C[1 * i2 - 9] = B[1 * i3 - 10] - D[1 * i3 + 5];
          D[2 * i2 + 9] = B[1 * i4 + 9] * 101;
      }
    }
  }
  for (int i1 = 35; i1 <= 58; i1+=1) {
    for (int i3 = 28; i3 <= 30; i3+=1) {
      for (int i5 = 75; i5 <= 123; i5+=1) {
          B[2 * i3 - 10] = 9 - C[2 * i5 - 5];
          E[2 * i5 - 9] = 74 * 74;
          B[2 * i1 + 10] = A[1 * i3 - 10] * 74;
      }
    }
  }
  for (int i4 = 44; i4 <= 87; i4+=1) {
    for (int i5 = 75; i5 <= 123; i5+=1) {
      for (int i2 = 106; i2 <= 108; i2+=1) {
          D[1 * i4 + 10] = D[1 * i2 + 9] * A[1 * i2 - 5];
          E[1 * i4 + 5] = 101 + A[1 * i4 + 9];
          D[2 * i5 - 5] = B[2 * i4 + 5] - B[1 * i5 - 9];
      }
    }
  }
  for (int i5 = 75; i5 <= 123; i5+=1) {
    for (int i3 = 28; i3 <= 30; i3+=1) {
      for (int i1 = 35; i1 <= 58; i1+=1) {
          C[1 * i5 + 10] = D[1 * i3 + 10] - 101;
          D[1 * i3 - 9] = D[1 * i3 + 10] + 74;
          B[1 * i3 - 9] = A[1 * i5 - 9] + C[1 * i3 + 10];
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

