#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 241], float B[restrict 241], float C[restrict 256], float D[restrict 244], float E[restrict 233]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i3 = 63; i3 <= 76; i3+=1) {
    for (int i1 = 6; i1 <= 18; i1+=1) {
      for (int i2 = 75; i2 <= 78; i2+=1) {
          A[2 * i2 - 1] = 57 + 96;
          B[2 * i2 + 10] = A[2 * i3 + 1] + A[2 * i1 + 1];
          A[2 * i1 + 1] = 96 - 57;
      }
    }
  }
  for (int i4 = 69; i4 <= 115; i4+=1) {
    for (int i2 = 75; i2 <= 78; i2+=1) {
      for (int i3 = 63; i3 <= 76; i3+=1) {
          C[2 * i4 + 1] = B[2 * i4 - 13] * D[2 * i2 + 13];
          C[2 * i2 - 10] = B[2 * i3 - 13] - D[2 * i3 + 1];
          D[2 * i2 + 10] = B[2 * i4 + 10] * 57;
      }
    }
  }
  for (int i3 = 63; i3 <= 76; i3+=1) {
    for (int i1 = 6; i1 <= 18; i1+=1) {
      for (int i5 = 13; i5 <= 121; i5+=1) {
          B[2 * i3 - 13] = 96 - C[2 * i5 - 1];
          E[2 * i5 - 10] = 117 * 117;
          B[2 * i1 + 13] = A[2 * i3 - 13] * 117;
      }
    }
  }
  for (int i5 = 13; i5 <= 121; i5+=1) {
    for (int i4 = 69; i4 <= 115; i4+=1) {
      for (int i2 = 75; i2 <= 78; i2+=1) {
          D[2 * i4 + 13] = D[2 * i2 + 10] * A[2 * i2 - 1];
          E[2 * i4 + 1] = 57 + A[2 * i4 + 10];
          D[2 * i5 - 1] = B[2 * i4 + 1] - B[2 * i5 - 10];
      }
    }
  }
  for (int i1 = 6; i1 <= 18; i1+=1) {
    for (int i5 = 13; i5 <= 121; i5+=1) {
      for (int i3 = 63; i3 <= 76; i3+=1) {
          C[2 * i5 + 13] = D[2 * i3 + 13] - 57;
          D[2 * i3 - 10] = D[2 * i3 + 13] + 117;
          B[2 * i3 - 10] = A[2 * i5 - 10] + C[2 * i3 + 13];
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

