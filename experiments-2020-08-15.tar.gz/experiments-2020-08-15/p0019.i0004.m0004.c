#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 244], float B[restrict 253], float C[restrict 238], float D[restrict 253], float E[restrict 244]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i2 = 58; i2 <= 94; i2+=1) {
    for (int i1 = 37; i1 <= 120; i1+=1) {
      for (int i3 = 84; i3 <= 99; i3+=1) {
          A[2 * i2 + 0] = 19 - 19;
          B[1 * i3 - 3] = C[1 * i2 + 3] + A[1 * i2 - 3];
          D[2 * i1 - 3] = C[1 * i2 - 3] + A[2 * i3 - 12];
      }
    }
  }
  for (int i5 = 45; i5 <= 120; i5+=1) {
    for (int i4 = 98; i4 <= 104; i4+=1) {
      for (int i1 = 37; i1 <= 120; i1+=1) {
          D[1 * i5 + 12] = B[1 * i5 + 3] - D[2 * i1 + 12];
          D[1 * i5 + 3] = D[2 * i1 - 0] * E[2 * i1 + 3];
          D[1 * i4 - 0] = B[2 * i4 - 0] * 89;
      }
    }
  }
  for (int i3 = 84; i3 <= 99; i3+=1) {
    for (int i1 = 37; i1 <= 120; i1+=1) {
      for (int i5 = 45; i5 <= 120; i5+=1) {
          C[2 * i1 - 3] = A[2 * i3 - 0] * 72;
          E[2 * i5 + 3] = E[2 * i1 - 12] * 89;
          B[2 * i3 + 0] = D[2 * i1 - 0] * 89;
      }
    }
  }
  for (int i4 = 98; i4 <= 104; i4+=1) {
    for (int i1 = 37; i1 <= 120; i1+=1) {
      for (int i2 = 58; i2 <= 94; i2+=1) {
          E[2 * i2 - 0] = E[2 * i4 + 3] + 19;
          E[2 * i1 - 12] = A[1 * i4 - 3] + 89;
          E[2 * i4 - 3] = C[2 * i4 - 0] + A[2 * i1 - 3];
      }
    }
  }
  for (int i3 = 84; i3 <= 99; i3+=1) {
    for (int i2 = 58; i2 <= 94; i2+=1) {
      for (int i5 = 45; i5 <= 120; i5+=1) {
          A[2 * i2 + 3] = E[1 * i5 - 3] * E[1 * i2 - 12];
          A[2 * i5 + 0] = A[2 * i2 - 12] * A[2 * i2 + 12];
          B[2 * i5 + 12] = D[1 * i2 + 0] + A[2 * i5 + 3];
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

