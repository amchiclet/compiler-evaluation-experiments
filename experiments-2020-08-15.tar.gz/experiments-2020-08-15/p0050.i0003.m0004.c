#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 185], float B[restrict 223], float C[restrict 199], float D[restrict 229], float E[restrict 99]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i3 = 27; i3 <= 43; i3+=1) {
    for (int i1 = 91; i1 <= 93; i1+=1) {
      for (int i2 = 36; i2 <= 69; i2+=1) {
          A[1 * i3 - 12] = B[1 * i1 - 2] * C[1 * i3 - 2];
          D[1 * i1 - 4] = 32 + D[1 * i2 - 4];
          A[2 * i1 - 2] = D[1 * i3 - 12] + C[2 * i2 + 4];
      }
    }
  }
  for (int i1 = 91; i1 <= 93; i1+=1) {
    for (int i4 = 120; i4 <= 224; i4+=1) {
      for (int i5 = 46; i5 <= 64; i5+=1) {
          D[1 * i4 + 4] = D[1 * i1 + 2] - 36;
          D[1 * i1 - 12] = 36 * B[1 * i4 - 2];
          B[1 * i1 + 2] = C[2 * i1 + 12] + 32;
      }
    }
  }
  for (int i3 = 27; i3 <= 43; i3+=1) {
    for (int i2 = 36; i2 <= 69; i2+=1) {
      for (int i4 = 120; i4 <= 224; i4+=1) {
          E[1 * i2 - 2] = 30 * 32;
          A[1 * i2 + 2] = 32 * 36;
          E[1 * i2 + 12] = 36 - 36;
      }
    }
  }
  for (int i1 = 91; i1 <= 93; i1+=1) {
    for (int i2 = 36; i2 <= 69; i2+=1) {
      for (int i5 = 46; i5 <= 64; i5+=1) {
          A[1 * i2 + 2] = 30 - C[2 * i5 + 12];
          B[1 * i2 + 4] = B[1 * i1 - 2] * 32;
          C[1 * i5 + 4] = D[1 * i1 + 4] - B[1 * i5 + 4];
      }
    }
  }
  for (int i6 = 5; i6 <= 29; i6+=1) {
    for (int i3 = 27; i3 <= 43; i3+=1) {
      for (int i5 = 46; i5 <= 64; i5+=1) {
          E[1 * i5 + 4] = 32 - C[2 * i5 - 12];
          C[2 * i5 + 4] = 32 + E[2 * i3 + 12];
          C[1 * i6 + 2] = 30 * E[1 * i6 + 12];
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

