#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 210], float B[restrict 196], float C[restrict 196], float D[restrict 208], float E[restrict 206]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 26; i1 <= 91; i1+=1) {
    for (int i2 = 50; i2 <= 79; i2+=1) {
      for (int i3 = 45; i3 <= 104; i3+=1) {
          A[2 * i3 - 1] = B[2 * i1 + 13] + C[2 * i2 - 1];
          B[2 * i2 + 1] = B[1 * i1 + 13] * 82;
          C[2 * i2 - 1] = D[1 * i1 - 5] * E[2 * i2 + 1];
      }
    }
  }
  for (int i2 = 50; i2 <= 79; i2+=1) {
    for (int i1 = 26; i1 <= 91; i1+=1) {
      for (int i3 = 45; i3 <= 104; i3+=1) {
          A[2 * i3 + 1] = D[2 * i1 + 13] + 82;
          B[2 * i3 - 13] = 56 * 82;
          E[1 * i3 + 13] = A[2 * i3 - 5] * C[1 * i1 - 1];
      }
    }
  }
  for (int i1 = 26; i1 <= 91; i1+=1) {
    for (int i2 = 50; i2 <= 79; i2+=1) {
      for (int i4 = 33; i4 <= 38; i4+=1) {
          E[2 * i4 + 13] = E[1 * i1 + 1] + C[1 * i2 + 1];
          C[2 * i4 + 1] = 122 + 82;
          C[2 * i1 - 13] = 82 + 56;
      }
    }
  }
  for (int i5 = 49; i5 <= 103; i5+=1) {
    for (int i1 = 26; i1 <= 91; i1+=1) {
      for (int i2 = 50; i2 <= 79; i2+=1) {
          B[2 * i5 - 13] = 122 - 82;
          C[2 * i1 + 1] = 122 * D[2 * i1 - 13];
          C[1 * i5 + 5] = C[2 * i1 + 5] + C[2 * i2 + 5];
      }
    }
  }
  for (int i1 = 26; i1 <= 91; i1+=1) {
    for (int i6 = 15; i6 <= 53; i6+=1) {
      for (int i5 = 49; i5 <= 103; i5+=1) {
          A[2 * i6 + 1] = D[2 * i5 + 1] * C[2 * i1 + 13];
          A[2 * i6 - 13] = 122 - E[2 * i5 - 1];
          A[1 * i6 + 5] = 122 * A[2 * i1 - 1];
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

