#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 190], float B[restrict 212], float C[restrict 190], float D[restrict 222], float E[restrict 212]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i3 = 32; i3 <= 80; i3+=1) {
    for (int i2 = 31; i2 <= 88; i2+=1) {
      for (int i1 = 21; i1 <= 24; i1+=1) {
          A[2 * i2 + 13] = B[2 * i2 + 5] + C[2 * i3 - 5];
          B[1 * i3 + 5] = C[2 * i2 + 13] - A[2 * i1 + 5];
          D[2 * i2 - 13] = 59 + D[2 * i1 + 5];
      }
    }
  }
  for (int i2 = 31; i2 <= 88; i2+=1) {
    for (int i1 = 21; i1 <= 24; i1+=1) {
      for (int i3 = 32; i3 <= 80; i3+=1) {
          D[1 * i1 + 13] = B[2 * i2 + 5] - B[2 * i1 - 5];
          E[1 * i2 + 5] = E[2 * i1 + 5] - 20;
          B[1 * i1 + 5] = C[2 * i1 - 5] * 68;
      }
    }
  }
  for (int i1 = 21; i1 <= 24; i1+=1) {
    for (int i4 = 28; i4 <= 103; i4+=1) {
      for (int i2 = 31; i2 <= 88; i2+=1) {
          D[2 * i4 + 5] = E[2 * i2 - 5] - D[2 * i1 + 5];
          E[2 * i4 + 5] = 20 - B[1 * i2 + 5];
          D[2 * i2 + 5] = 59 - 68;
      }
    }
  }
  for (int i5 = 84; i5 <= 97; i5+=1) {
    for (int i4 = 28; i4 <= 103; i4+=1) {
      for (int i1 = 21; i1 <= 24; i1+=1) {
          C[1 * i4 + 13] = 59 * A[1 * i4 - 13];
          E[2 * i4 + 5] = D[2 * i1 - 5] + A[2 * i1 - 5];
          D[1 * i4 + 5] = D[2 * i5 - 13] * D[2 * i5 + 5];
      }
    }
  }
  for (int i4 = 28; i4 <= 103; i4+=1) {
    for (int i2 = 31; i2 <= 88; i2+=1) {
      for (int i6 = 79; i6 <= 216; i6+=1) {
          D[1 * i6 + 5] = C[1 * i4 - 5] + 59;
          A[2 * i2 + 5] = E[2 * i2 + 5] * C[2 * i2 - 5];
          A[1 * i4 - 5] = B[2 * i4 + 5] - 20;
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

