#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 197], float B[restrict 245], float C[restrict 252], float D[restrict 233], float E[restrict 179]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i2 = 62; i2 <= 105; i2+=1) {
    for (int i3 = 86; i3 <= 104; i3+=1) {
      for (int i1 = 35; i1 <= 119; i1+=1) {
          A[2 * i3 - 12] = B[2 * i1 + 6] + C[2 * i2 - 12];
          B[2 * i2 + 12] = B[1 * i1 + 6] * 77;
          C[1 * i2 - 12] = D[1 * i1 - 13] * E[1 * i2 + 12];
      }
    }
  }
  for (int i2 = 62; i2 <= 105; i2+=1) {
    for (int i3 = 86; i3 <= 104; i3+=1) {
      for (int i1 = 35; i1 <= 119; i1+=1) {
          A[1 * i3 + 12] = D[1 * i1 + 6] + 77;
          B[2 * i3 - 6] = 43 * 77;
          E[1 * i3 + 6] = A[2 * i3 - 13] * C[1 * i1 - 12];
      }
    }
  }
  for (int i4 = 61; i4 <= 86; i4+=1) {
    for (int i1 = 35; i1 <= 119; i1+=1) {
      for (int i2 = 62; i2 <= 105; i2+=1) {
          E[2 * i4 + 6] = E[1 * i1 + 12] + C[1 * i2 + 12];
          C[2 * i4 + 12] = 13 + 77;
          C[1 * i1 - 6] = 77 + 43;
      }
    }
  }
  for (int i2 = 62; i2 <= 105; i2+=1) {
    for (int i5 = 24; i5 <= 88; i5+=1) {
      for (int i1 = 35; i1 <= 119; i1+=1) {
          B[2 * i5 - 6] = 13 - 77;
          C[2 * i1 + 12] = 13 * D[2 * i1 - 6];
          C[1 * i5 + 13] = C[2 * i1 + 13] + C[2 * i2 + 13];
      }
    }
  }
  for (int i1 = 35; i1 <= 119; i1+=1) {
    for (int i6 = 27; i6 <= 83; i6+=1) {
      for (int i5 = 24; i5 <= 88; i5+=1) {
          A[2 * i6 + 12] = D[1 * i5 + 12] * C[1 * i1 + 6];
          A[2 * i6 - 6] = 13 - E[2 * i5 - 12];
          A[1 * i6 + 13] = 13 * A[1 * i1 - 12];
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

