#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 212], float B[restrict 223], float C[restrict 223], float D[restrict 222], float E[restrict 223]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i2 = 31; i2 <= 92; i2+=1) {
    for (int i3 = 35; i3 <= 94; i3+=1) {
      for (int i1 = 61; i1 <= 108; i1+=1) {
          A[2 * i3 - 0] = B[2 * i1 - 5] * C[2 * i3 - 5];
          D[2 * i1 - 0] = 22 + D[2 * i2 - 0];
          A[2 * i1 - 5] = D[2 * i3 - 0] + C[2 * i2 + 0];
      }
    }
  }
  for (int i1 = 61; i1 <= 108; i1+=1) {
    for (int i4 = 39; i4 <= 100; i4+=1) {
      for (int i5 = 26; i5 <= 111; i5+=1) {
          D[2 * i4 + 0] = D[2 * i1 + 5] - 3;
          D[2 * i1 - 0] = 3 * B[2 * i4 - 5];
          B[2 * i1 + 5] = C[2 * i1 + 0] + 22;
      }
    }
  }
  for (int i4 = 39; i4 <= 100; i4+=1) {
    for (int i3 = 35; i3 <= 94; i3+=1) {
      for (int i2 = 31; i2 <= 92; i2+=1) {
          E[2 * i2 - 5] = 117 * 22;
          A[2 * i2 + 5] = 22 * 3;
          E[2 * i2 + 0] = 3 - 3;
      }
    }
  }
  for (int i1 = 61; i1 <= 108; i1+=1) {
    for (int i2 = 31; i2 <= 92; i2+=1) {
      for (int i5 = 26; i5 <= 111; i5+=1) {
          A[2 * i2 + 5] = 117 - C[2 * i5 + 0];
          B[2 * i2 + 0] = B[2 * i1 - 5] * 22;
          C[2 * i5 + 0] = D[2 * i1 + 0] - B[2 * i5 + 0];
      }
    }
  }
  for (int i6 = 18; i6 <= 57; i6+=1) {
    for (int i5 = 26; i5 <= 111; i5+=1) {
      for (int i3 = 35; i3 <= 94; i3+=1) {
          E[2 * i5 + 0] = 22 - C[2 * i5 - 0];
          C[2 * i5 + 0] = 22 + E[2 * i3 + 0];
          C[2 * i6 + 5] = 117 * E[2 * i6 + 0];
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

