#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 222], float B[restrict 229], float C[restrict 232], float D[restrict 242], float E[restrict 192]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i3 = 77; i3 <= 109; i3+=1) {
    for (int i2 = 16; i2 <= 88; i2+=1) {
      for (int i1 = 79; i1 <= 100; i1+=1) {
          A[1 * i2 + 5] = B[1 * i2 + 15] + C[1 * i3 - 15];
          B[2 * i3 + 10] = C[1 * i2 + 5] - A[1 * i1 + 10];
          D[1 * i2 - 5] = 41 + D[1 * i1 + 10];
      }
    }
  }
  for (int i3 = 77; i3 <= 109; i3+=1) {
    for (int i2 = 16; i2 <= 88; i2+=1) {
      for (int i1 = 79; i1 <= 100; i1+=1) {
          D[2 * i1 + 5] = B[1 * i2 + 15] - B[1 * i1 - 15];
          E[2 * i2 + 15] = E[1 * i1 + 10] - 30;
          B[2 * i1 + 15] = C[1 * i1 - 15] * 90;
      }
    }
  }
  for (int i1 = 79; i1 <= 100; i1+=1) {
    for (int i2 = 16; i2 <= 88; i2+=1) {
      for (int i4 = 21; i4 <= 113; i4+=1) {
          D[1 * i4 + 15] = E[1 * i2 - 10] - D[1 * i1 + 15];
          E[1 * i4 + 15] = 30 - B[2 * i2 + 15];
          D[1 * i2 + 10] = 41 - 90;
      }
    }
  }
  for (int i5 = 142; i5 <= 191; i5+=1) {
    for (int i4 = 21; i4 <= 113; i4+=1) {
      for (int i1 = 79; i1 <= 100; i1+=1) {
          C[2 * i4 + 5] = 41 * A[2 * i4 - 5];
          E[1 * i4 + 15] = D[1 * i1 - 15] + A[1 * i1 - 15];
          D[2 * i4 + 15] = D[1 * i5 - 5] * D[1 * i5 + 10];
      }
    }
  }
  for (int i4 = 21; i4 <= 113; i4+=1) {
    for (int i2 = 16; i2 <= 88; i2+=1) {
      for (int i6 = 22; i6 <= 53; i6+=1) {
          D[2 * i6 + 15] = C[2 * i4 - 10] + 41;
          A[1 * i2 + 15] = E[1 * i2 + 10] * C[1 * i2 - 10];
          A[2 * i4 - 15] = B[1 * i4 + 10] - 30;
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

