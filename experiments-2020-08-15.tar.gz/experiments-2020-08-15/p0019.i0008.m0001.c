#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 232], float B[restrict 242], float C[restrict 228], float D[restrict 251], float E[restrict 250]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i3 = 33; i3 <= 118; i3+=1) {
    for (int i2 = 39; i2 <= 45; i2+=1) {
      for (int i1 = 91; i1 <= 119; i1+=1) {
          A[2 * i2 + 5] = 38 - 38;
          B[1 * i3 - 11] = C[1 * i2 + 11] + A[1 * i2 - 11];
          D[2 * i1 - 11] = C[1 * i2 - 11] + A[2 * i3 - 12];
      }
    }
  }
  for (int i5 = 56; i5 <= 69; i5+=1) {
    for (int i1 = 91; i1 <= 119; i1+=1) {
      for (int i4 = 26; i4 <= 44; i4+=1) {
          D[1 * i5 + 12] = B[1 * i5 + 11] - D[2 * i1 + 12];
          D[1 * i5 + 11] = D[2 * i1 - 5] * E[2 * i1 + 11];
          D[1 * i4 - 5] = B[2 * i4 - 5] * 116;
      }
    }
  }
  for (int i3 = 33; i3 <= 118; i3+=1) {
    for (int i1 = 91; i1 <= 119; i1+=1) {
      for (int i5 = 56; i5 <= 69; i5+=1) {
          C[2 * i1 - 11] = A[2 * i3 - 5] * 38;
          E[2 * i5 + 11] = E[2 * i1 - 12] * 116;
          B[2 * i3 + 5] = D[2 * i1 - 5] * 116;
      }
    }
  }
  for (int i1 = 91; i1 <= 119; i1+=1) {
    for (int i2 = 39; i2 <= 45; i2+=1) {
      for (int i4 = 26; i4 <= 44; i4+=1) {
          E[2 * i2 - 5] = E[2 * i4 + 11] + 38;
          E[2 * i1 - 12] = A[1 * i4 - 11] + 116;
          E[2 * i4 - 11] = C[2 * i4 - 5] + A[2 * i1 - 11];
      }
    }
  }
  for (int i2 = 39; i2 <= 45; i2+=1) {
    for (int i3 = 33; i3 <= 118; i3+=1) {
      for (int i5 = 56; i5 <= 69; i5+=1) {
          A[2 * i2 + 11] = E[1 * i5 - 11] * E[1 * i2 - 12];
          A[2 * i5 + 5] = A[2 * i2 - 12] * A[2 * i2 + 12];
          B[2 * i5 + 12] = D[1 * i2 + 5] + A[2 * i5 + 11];
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

