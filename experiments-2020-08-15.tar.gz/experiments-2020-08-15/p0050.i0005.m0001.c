#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 205], float B[restrict 239], float C[restrict 205], float D[restrict 246], float E[restrict 204]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i1 = 47; i1 <= 118; i1+=1) {
    for (int i2 = 46; i2 <= 71; i2+=1) {
      for (int i3 = 37; i3 <= 103; i3+=1) {
          A[2 * i3 - 2] = B[2 * i1 - 2] * C[2 * i3 - 2];
          D[2 * i1 - 9] = 45 + D[2 * i2 - 9];
          A[1 * i1 - 2] = D[2 * i3 - 2] + C[1 * i2 + 9];
      }
    }
  }
  for (int i5 = 18; i5 <= 97; i5+=1) {
    for (int i4 = 33; i4 <= 77; i4+=1) {
      for (int i1 = 47; i1 <= 118; i1+=1) {
          D[2 * i4 + 9] = D[2 * i1 + 2] - 6;
          D[2 * i1 - 2] = 6 * B[2 * i4 - 2];
          B[2 * i1 + 2] = C[1 * i1 + 2] + 45;
      }
    }
  }
  for (int i2 = 46; i2 <= 71; i2+=1) {
    for (int i4 = 33; i4 <= 77; i4+=1) {
      for (int i3 = 37; i3 <= 103; i3+=1) {
          E[2 * i2 - 2] = 127 * 45;
          A[2 * i2 + 2] = 45 * 6;
          E[2 * i2 + 2] = 6 - 6;
      }
    }
  }
  for (int i5 = 18; i5 <= 97; i5+=1) {
    for (int i1 = 47; i1 <= 118; i1+=1) {
      for (int i2 = 46; i2 <= 71; i2+=1) {
          A[2 * i2 + 2] = 127 - C[1 * i5 + 2];
          B[2 * i2 + 9] = B[2 * i1 - 2] * 45;
          C[2 * i5 + 9] = D[2 * i1 + 9] - B[2 * i5 + 9];
      }
    }
  }
  for (int i3 = 37; i3 <= 103; i3+=1) {
    for (int i5 = 18; i5 <= 97; i5+=1) {
      for (int i6 = 13; i6 <= 69; i6+=1) {
          E[2 * i5 + 9] = 45 - C[1 * i5 - 2];
          C[1 * i5 + 9] = 45 + E[1 * i3 + 2];
          C[2 * i6 + 2] = 127 * E[2 * i6 + 2];
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

