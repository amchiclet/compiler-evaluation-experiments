#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 210], float B[restrict 234], float C[restrict 234], float D[restrict 191], float E[restrict 234]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i3 = 11; i3 <= 79; i3+=1) {
    for (int i1 = 50; i1 <= 92; i1+=1) {
      for (int i2 = 80; i2 <= 109; i2+=1) {
          A[2 * i3 - 15] = B[2 * i1 + 6] + C[2 * i2 - 15];
          B[2 * i2 + 15] = B[2 * i1 + 6] * 89;
          C[2 * i2 - 15] = D[2 * i1 - 8] * E[2 * i2 + 15];
      }
    }
  }
  for (int i3 = 11; i3 <= 79; i3+=1) {
    for (int i2 = 80; i2 <= 109; i2+=1) {
      for (int i1 = 50; i1 <= 92; i1+=1) {
          A[2 * i3 + 15] = D[2 * i1 + 6] + 89;
          B[2 * i3 - 6] = 81 * 89;
          E[2 * i3 + 6] = A[2 * i3 - 8] * C[2 * i1 - 15];
      }
    }
  }
  for (int i1 = 50; i1 <= 92; i1+=1) {
    for (int i4 = 44; i4 <= 79; i4+=1) {
      for (int i2 = 80; i2 <= 109; i2+=1) {
          E[2 * i4 + 6] = E[2 * i1 + 15] + C[2 * i2 + 15];
          C[2 * i4 + 15] = 8 + 89;
          C[2 * i1 - 6] = 89 + 81;
      }
    }
  }
  for (int i2 = 80; i2 <= 109; i2+=1) {
    for (int i5 = 29; i5 <= 53; i5+=1) {
      for (int i1 = 50; i1 <= 92; i1+=1) {
          B[2 * i5 - 6] = 8 - 89;
          C[2 * i1 + 15] = 8 * D[2 * i1 - 6];
          C[2 * i5 + 8] = C[2 * i1 + 8] + C[2 * i2 + 8];
      }
    }
  }
  for (int i6 = 78; i6 <= 97; i6+=1) {
    for (int i1 = 50; i1 <= 92; i1+=1) {
      for (int i5 = 29; i5 <= 53; i5+=1) {
          A[2 * i6 + 15] = D[2 * i5 + 15] * C[2 * i1 + 6];
          A[2 * i6 - 6] = 8 - E[2 * i5 - 15];
          A[2 * i6 + 8] = 8 * A[2 * i1 - 15];
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

