#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 191], float B[restrict 191], float C[restrict 245], float D[restrict 253], float E[restrict 184]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i2 = 63; i2 <= 90; i2+=1) {
    for (int i1 = 36; i1 <= 42; i1+=1) {
      for (int i3 = 30; i3 <= 127; i3+=1) {
          A[2 * i2 + 10] = B[1 * i2 + 10] + C[2 * i3 - 10];
          B[1 * i3 + 3] = C[1 * i2 + 10] - A[1 * i1 + 3];
          D[1 * i2 - 10] = 61 + D[2 * i1 + 3];
      }
    }
  }
  for (int i1 = 36; i1 <= 42; i1+=1) {
    for (int i3 = 30; i3 <= 127; i3+=1) {
      for (int i2 = 63; i2 <= 90; i2+=1) {
          D[1 * i1 + 10] = B[2 * i2 + 10] - B[1 * i1 - 10];
          E[1 * i2 + 10] = E[1 * i1 + 3] - 8;
          B[1 * i1 + 10] = C[2 * i1 - 10] * 41;
      }
    }
  }
  for (int i4 = 28; i4 <= 35; i4+=1) {
    for (int i2 = 63; i2 <= 90; i2+=1) {
      for (int i1 = 36; i1 <= 42; i1+=1) {
          D[2 * i4 + 10] = E[2 * i2 - 3] - D[1 * i1 + 10];
          E[1 * i4 + 10] = 8 - B[1 * i2 + 10];
          D[1 * i2 + 3] = 61 - 41;
      }
    }
  }
  for (int i4 = 28; i4 <= 35; i4+=1) {
    for (int i1 = 36; i1 <= 42; i1+=1) {
      for (int i5 = 118; i5 <= 131; i5+=1) {
          C[1 * i4 + 10] = 61 * A[1 * i4 - 10];
          E[2 * i4 + 10] = D[1 * i1 - 10] + A[2 * i1 - 10];
          D[1 * i4 + 10] = D[2 * i5 - 10] * D[1 * i5 + 3];
      }
    }
  }
  for (int i2 = 63; i2 <= 90; i2+=1) {
    for (int i4 = 28; i4 <= 35; i4+=1) {
      for (int i6 = 93; i6 <= 129; i6+=1) {
          D[1 * i6 + 10] = C[1 * i4 - 3] + 61;
          A[2 * i2 + 10] = E[2 * i2 + 3] * C[2 * i2 - 3];
          A[1 * i4 - 10] = B[2 * i4 + 3] - 8;
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

