#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 239], float B[restrict 219], float C[restrict 239], float D[restrict 249], float E[restrict 233]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i3 = 106; i3 <= 110; i3+=1) {
    for (int i1 = 28; i1 <= 113; i1+=1) {
      for (int i2 = 102; i2 <= 118; i2+=1) {
          A[1 * i2 + 12] = 29 - 29;
          B[2 * i3 - 2] = C[2 * i2 + 2] + A[2 * i2 - 2];
          D[1 * i1 - 2] = C[2 * i2 - 2] + A[1 * i3 - 16];
      }
    }
  }
  for (int i4 = 54; i4 <= 115; i4+=1) {
    for (int i1 = 28; i1 <= 113; i1+=1) {
      for (int i5 = 77; i5 <= 94; i5+=1) {
          D[2 * i5 + 16] = B[2 * i5 + 2] - D[1 * i1 + 16];
          D[2 * i5 + 2] = D[2 * i1 - 12] * E[1 * i1 + 2];
          D[2 * i4 - 12] = B[2 * i4 - 12] * 107;
      }
    }
  }
  for (int i1 = 28; i1 <= 113; i1+=1) {
    for (int i5 = 77; i5 <= 94; i5+=1) {
      for (int i3 = 106; i3 <= 110; i3+=1) {
          C[1 * i1 - 2] = A[2 * i3 - 12] * 43;
          E[1 * i5 + 2] = E[1 * i1 - 16] * 107;
          B[1 * i3 + 12] = D[1 * i1 - 12] * 107;
      }
    }
  }
  for (int i1 = 28; i1 <= 113; i1+=1) {
    for (int i4 = 54; i4 <= 115; i4+=1) {
      for (int i2 = 102; i2 <= 118; i2+=1) {
          E[2 * i2 - 12] = E[2 * i4 + 2] + 29;
          E[2 * i1 - 16] = A[2 * i4 - 2] + 107;
          E[2 * i4 - 2] = C[2 * i4 - 12] + A[1 * i1 - 2];
      }
    }
  }
  for (int i3 = 106; i3 <= 110; i3+=1) {
    for (int i2 = 102; i2 <= 118; i2+=1) {
      for (int i5 = 77; i5 <= 94; i5+=1) {
          A[2 * i2 + 2] = E[2 * i5 - 2] * E[2 * i2 - 16];
          A[1 * i5 + 12] = A[1 * i2 - 16] * A[1 * i2 + 16];
          B[1 * i5 + 16] = D[2 * i2 + 12] + A[1 * i5 + 2];
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

