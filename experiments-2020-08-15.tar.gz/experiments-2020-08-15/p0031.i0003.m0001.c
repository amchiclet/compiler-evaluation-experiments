#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <math.h>
#include <string.h>

unsigned long long core(float A[restrict 255], float B[restrict 113], float C[restrict 239], float D[restrict 233], float E[restrict 215]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i2 = 65; i2 <= 106; i2+=1) {
    for (int i1 = 43; i1 <= 51; i1+=1) {
      for (int i3 = 44; i3 <= 56; i3+=1) {
          A[1 * i3 - 2] = B[1 * i1 + 3] + C[1 * i2 - 2];
          B[1 * i2 + 2] = B[2 * i1 + 3] * 105;
          C[2 * i2 - 2] = D[2 * i1 - 8] * E[2 * i2 + 2];
      }
    }
  }
  for (int i2 = 65; i2 <= 106; i2+=1) {
    for (int i3 = 44; i3 <= 56; i3+=1) {
      for (int i1 = 43; i1 <= 51; i1+=1) {
          A[2 * i3 + 2] = D[2 * i1 + 3] + 105;
          B[1 * i3 - 3] = 58 * 105;
          E[2 * i3 + 3] = A[1 * i3 - 8] * C[2 * i1 - 2];
      }
    }
  }
  for (int i1 = 43; i1 <= 51; i1+=1) {
    for (int i2 = 65; i2 <= 106; i2+=1) {
      for (int i4 = 48; i4 <= 86; i4+=1) {
          E[1 * i4 + 3] = E[2 * i1 + 2] + C[2 * i2 + 2];
          C[1 * i4 + 2] = 123 + 105;
          C[2 * i1 - 3] = 105 + 58;
      }
    }
  }
  for (int i1 = 43; i1 <= 51; i1+=1) {
    for (int i5 = 88; i5 <= 115; i5+=1) {
      for (int i2 = 65; i2 <= 106; i2+=1) {
          B[1 * i5 - 3] = 123 - 105;
          C[1 * i1 + 2] = 123 * D[1 * i1 - 3];
          C[2 * i5 + 8] = C[1 * i1 + 8] + C[1 * i2 + 8];
      }
    }
  }
  for (int i1 = 43; i1 <= 51; i1+=1) {
    for (int i6 = 115; i6 <= 123; i6+=1) {
      for (int i5 = 88; i5 <= 115; i5+=1) {
          A[1 * i6 + 2] = D[2 * i5 + 2] * C[2 * i1 + 3];
          A[1 * i6 - 3] = 123 - E[1 * i5 - 2];
          A[2 * i6 + 8] = 123 * A[2 * i1 - 2];
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

