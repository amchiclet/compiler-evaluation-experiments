#include "hook.h"

void init_hook() {
}

void measure_start_hook() {
}
void measure_pause_hook() {
}

void measure_print_data_hook() {
}
void measure_stop_hook() {
}
