#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <string.h>

unsigned long long core(float A2[256][256], float B2[256][256], float C2[256][256]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i = 142; i <= 206; i+=1) {
    for (int j = 123; j <= 207; j+=1) {
        A2[j][i] = A2[j][i] - B2[0][i];
    }
  }
  for (int j = 123; j <= 207; j+=1) {
    for (int i = 142; i <= 206; i+=1) {
        A2[j][i] = A2[j][i] - B2[0][i];
    }
  }
  for (int i = 142; i <= 206; i+=1) {
    for (int j = 123; j <= 207; j+=1) {
        A2[i][j] = B2[j][i];
    }
  }
  for (int i = 142; i <= 206; i+=1) {
    for (int j = 123; j <= 207; j+=1) {
        A2[j][i] = B2[j][i];
    }
  }
  for (int j = 123; j <= 207; j+=1) {
    for (int k = 15; k <= 241; k+=1) {
      for (int i = 142; i <= 206; i+=1) {
          A2[i][j] = A2[i][j] + B2[j][k] * C2[i][k];
      }
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

