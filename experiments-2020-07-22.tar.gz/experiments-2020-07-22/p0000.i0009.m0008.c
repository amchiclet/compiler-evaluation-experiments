#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <string.h>

unsigned long long core(float A1[1], float A2[256][256], float B2[256][256], float C2[256][256], float D1[1]) {
  struct timespec before, after;
  clock_gettime(CLOCK_MONOTONIC, &before);
  for (int i = 4; i <= 130; i+=1) {
    for (int j = 9; j <= 46; j+=1) {
        A1[0] = B2[i][j] - C2[i][j];
        D1[0] = D1[0] + A1[0] * A1[0];
    }
  }
  for (int i = 4; i <= 130; i+=1) {
    for (int j = 9; j <= 46; j+=1) {
      for (int k = 126; k <= 155; k+=1) {
          A2[i][j] = A2[i][j] + B2[j][k] * C2[i][k];
      }
    }
  }
  for (int i = 4; i <= 130; i+=1) {
    for (int k = 126; k <= 155; k+=1) {
      for (int j = 9; j <= 46; j+=1) {
          A2[i][j] = A2[i][j] + B2[j][k] * C2[i][k];
      }
    }
  }
  for (int i = 4; i <= 130; i+=1) {
    for (int j = 9; j <= 46; j+=1) {
        A1[0] = A1[0] + B2[i][j] - C2[i][j];
    }
  }
  for (int i = 4; i <= 130; i+=1) {
    for (int j = 9; j <= 46; j+=1) {
        A2[i][j] = B2[j][i];
    }
  }
  clock_gettime(CLOCK_MONOTONIC, &after);
  unsigned long long duration = (after.tv_sec - before.tv_sec) * 1e9;
  duration += after.tv_nsec - before.tv_nsec;
  return duration;
}

