#include <x86intrin.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <limits.h>
#include <string.h>

unsigned long long core(float A1[1], float A2[256][256], float B2[256][256], float C2[256][256], float D1[1]);

struct Data {
  float (*A1)[1];
  float (*A2)[256][256];
  float (*B2)[256][256];
  float (*C2)[256][256];
  float (*D1)[1];
};

float frand(float min, float max) {
  float scale = rand() / (float) RAND_MAX;
  return min + scale * (max - min);
}

float irand(int min, int max) {
  return min + (rand() % (max - min));
}

void *allocate() {
  struct Data *data = malloc(sizeof(struct Data));
  data->A1 = malloc(sizeof(float) * 1);
  data->A2 = malloc(sizeof(float) * 256 * 256);
  data->B2 = malloc(sizeof(float) * 256 * 256);
  data->C2 = malloc(sizeof(float) * 256 * 256);
  data->D1 = malloc(sizeof(float) * 1);
  return (void*)data;
}

void init_inner(float A1[1], float A2[256][256], float B2[256][256], float C2[256][256], float D1[1]) {
  allocate();
  for (int i0 = 0; i0 <= 0; ++i0) {
    float v = frand(0.0, 1.0);
    A1[i0] = v;
  }
  for (int i0 = 0; i0 <= 255; ++i0) {
    for (int i1 = 0; i1 <= 255; ++i1) {
      float v = frand(0.0, 1.0);
      A2[i0][i1] = v;
    }
  }
  for (int i0 = 0; i0 <= 255; ++i0) {
    for (int i1 = 0; i1 <= 255; ++i1) {
      float v = frand(0.0, 1.0);
      B2[i0][i1] = v;
    }
  }
  for (int i0 = 0; i0 <= 255; ++i0) {
    for (int i1 = 0; i1 <= 255; ++i1) {
      float v = frand(0.0, 1.0);
      C2[i0][i1] = v;
    }
  }
  for (int i0 = 0; i0 <= 0; ++i0) {
    float v = frand(0.0, 1.0);
    D1[i0] = v;
  }
}

float checksum_inner(float A1[1], float A2[256][256], float B2[256][256], float C2[256][256], float D1[1]) {
  float total = 0.0;
  for (int i0 = 0; i0 <= 0; ++i0) {
    total += A1[i0];
  }
  for (int i0 = 0; i0 <= 255; ++i0) {
    for (int i1 = 0; i1 <= 255; ++i1) {
      total += B2[i0][i1];
    }
  }
  for (int i0 = 0; i0 <= 255; ++i0) {
    for (int i1 = 0; i1 <= 255; ++i1) {
      total += C2[i0][i1];
    }
  }
  for (int i0 = 0; i0 <= 0; ++i0) {
    total += D1[i0];
  }
  for (int i0 = 0; i0 <= 255; ++i0) {
    for (int i1 = 0; i1 <= 255; ++i1) {
      total += A2[i0][i1];
    }
  }
  return total;
}

void init(void *void_ptr) {
  struct Data *data = (struct Data*)void_ptr;
  return init_inner(*data->A1, *data->A2, *data->B2, *data->C2, *data->D1);
};

float checksum(void *void_ptr) {
  struct Data *data = (struct Data*)void_ptr;
  return checksum_inner(*data->A1, *data->A2, *data->B2, *data->C2, *data->D1);
};

unsigned long long kernel(void *void_ptr) {
  struct Data *data = (struct Data*)void_ptr;
  return core(*data->A1, *data->A2, *data->B2, *data->C2, *data->D1);
};

